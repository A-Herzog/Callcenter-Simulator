import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import CallcenterDataModel.CallCenterModel;
import CallcenterDataModel.CallCenterModelAgent;
import CallcenterDataModel.CallCenterModelCallCenter;
import CallcenterDataModel.CallCenterModelCaller;
import CallcenterDataModel.Tools.Distribution;
import CallcenterDataModel.Tools.Language;

public class CallCenterModelTest {
	private static final String defaultFolder=
			System.getProperty("user.home")+"/Desktop/";

	private static CallCenterModel createSimpleModel(int[] freshCalls,
			int agentHalfHours, int meanWorking, int sdWorking,
			int meanPostProcessing, int sdPostProcessing, String modelName,
			String clientsName, String callCenterName, String skillLevelName) {
		/* Create model / Modell anlegen */
		CallCenterModel model=new CallCenterModel(modelName);

		/* Add client type / Kundengruppe hinzuf�gen */
		CallCenterModelCaller caller=model.addCaller(clientsName);
		caller.freshCallsDist=Distribution.getData(freshCalls);
		caller.freshCallsCountMean=Distribution.sum(freshCalls);

		/* Add call center / Callcenter hinzuf�gen */
		CallCenterModelCallCenter callcenter=model.addCallcenter(callCenterName);

		/* Add an agents group in the call center / In dem Callcenter eine
		 * Agentengruppe hinzuf�gen */
		CallCenterModelAgent agents=callcenter.addAgents(skillLevelName);
		agents.setAgentsByFreshCalls(agentHalfHours,clientsName);

		/* Add skill level / Skill-Level hinzuf�gen */
		model.addSkillLevel(skillLevelName).addSkill(
				clientsName,
				Distribution.getDistributionLogNormal(meanWorking,sdWorking),
				Distribution.getDistributionLogNormal(meanPostProcessing,
						sdPostProcessing));

		return model;
	}

	private static void createAndStoreSimpleModel(String modelName,
			String clientsName, String callCenterName, String skillLevelName) {
		/* Setup parameters / Parameter konfigurieren */
		int[] freshCalls=new int[]{
				0,0,0,0,1,2,1,4,
				5,5,3,3,5,7,10,10,
				15,17,25,50,60,65,65,62,
				50,45,50,60,62,62,60,55,
				50,45,40,35,35,40,40,37,
				35,30,25,15,10,8,5,2
		};
		int agentHalfHours=400;
		int meanWorking=480;
		int sdWorking=30;
		int meanPostProcessing=90;
		int sdPostProcessing=30;

		/* Create model / Modell erstellen */
		CallCenterModel model=createSimpleModel(
				freshCalls,
				agentHalfHours,
				meanWorking,sdWorking,
				meanPostProcessing,sdPostProcessing,
				modelName,clientsName,callCenterName,skillLevelName);

		/* Save model / Modell speichern */
		File file=new File(defaultFolder+"Import.xml");
		String s=model.saveXML(file);
		if (s==null) s=Language.get(Language.XML_Written);
		System.out.println(s);
	}

	@SuppressWarnings("unused")
	private static void createDemoSQLiteDB(String modelName,
			String clientsName, String callCenterName, String skillLevelName) {
		int[] freshCalls=new int[]{
				0,0,0,0,1,2,1,4,
				5,5,3,3,5,7,10,10,
				15,17,25,50,60,65,65,62,
				50,45,50,60,62,62,60,55,
				50,45,40,35,35,40,40,37,
				35,30,25,15,10,8,5,2
		};
		try {
			try (Connection con=DriverManager.getConnection("jdbc:sqlite:test.db")) {
				try (Statement query=con.createStatement()) {
					query.execute("CREATE TABLE Daten (RowA INT,RowB INT)");
					for (int i=0;i<freshCalls.length;i++)
						query.execute("INSERT INTO Data (RowA,RowB) VALUES ("+i+
								","+freshCalls[i]+")");
				}
			}
		} catch (SQLException e1) {
			System.out.println(Language.get(Language.XML_DBWriteError));
		}
	}

	@SuppressWarnings("unused")
	private static void createAndStoreSimpleModelWithDataFromSQLite(
			String modelName, String clientsName, String callCenterName,
			String skillLevelName) {
		/* Read fresh calls from data base / Erstanrufer aus Datenbank laden */
		int [] freshCalls;
		try {
			try (Connection con=DriverManager.getConnection("jdbc:sqlite:test.db")) {
				try (Statement query=con.createStatement()) {
					try (ResultSet result=query.executeQuery("SELECT RowB FROM Data")) {
						List<Integer> freshCallsList=new ArrayList<Integer>();
						while (result.next()) {
							freshCallsList.add(result.getInt(1));
						}

						freshCalls=new int[freshCallsList.size()];
						for (int i=0;i<freshCallsList.size();i++)
							freshCalls[i]=freshCallsList.get(i);
					}
				}
			}
		} catch (SQLException e1) {
			System.out.println(Language.get(Language.XML_DBReadError)); return;
		}


		/* Configure parameters / Parameter konfigurieren */
		int agentHalfHours=400;
		int meanWorking=480;
		int sdWorking=30;
		int meanPostProcessing=90;
		int sdPostProcessing=30;

		/* Create model / Modell erstellen */
		CallCenterModel model=createSimpleModel(
				freshCalls,
				agentHalfHours,
				meanWorking,sdWorking,
				meanPostProcessing,sdPostProcessing,
				modelName,clientsName,callCenterName,skillLevelName);

		/* Save model / Modell speichern */
		File file=new File(defaultFolder+"Import.xml");
		String s=model.saveXML(file);
		if (s==null) s=Language.get(Language.XML_Written);
		System.out.println(s);
	}

	public static void main(String[] args) {
		// English:
		Language.select(Language.LANGUAGE_ENGLISH);
		createAndStoreSimpleModel(
				"Simple model","Clients","Call center","Skill level");

		// German:
		/*
		Language.select(Language.LANGUAGE_GERMAN);
		createAndStoreSimpleModel(
				"Einfaches Modell","Kunden","Callcenter","Skill-Level");
		 */

		// Other things to try:
		/*
		Language.select(Language.LANGUAGE_ENGLISH);
		createDemoSQLiteDB();
		createAndStoreSimpleModelWithDataFromSQLite(
				"Simple model","Clients","Call center","Skill level");
		 */
	}
}
