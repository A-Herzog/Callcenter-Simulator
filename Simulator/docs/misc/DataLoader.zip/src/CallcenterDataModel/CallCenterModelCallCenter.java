package CallcenterDataModel;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import CallcenterDataModel.Tools.Language;
import CallcenterDataModel.Tools.Numbers;

/**
 * EN: Encapsulates the XML data of a call center<br>
 * DE: Kapselt die XML-Daten eines Callcenters
 * @author Alexander Herzog
 */
public final class CallCenterModelCallCenter implements Cloneable {
	/**
	 * EN: Name of the call center<br>
	 * DE: Name des Callcenters
	 */
	public String name;

	/**
	 * EN: Call center active?<br>
	 * DE: Callcenter aktiv?
	 */
	public boolean active;

	/**
	 * EN: List of agents groups in this call center<br>
	 * DE: Liste der Agentengruppen innerhalb des Callcenters
	 */
	private final List<CallCenterModelAgent> agents;

	/**
	 * EN: Required connection time before a conversation begins<br>
	 * DE: Ben�tigte Vermittlungszeit, bevor ein Gespr�ch beginnt
	 */
	public int technicalFreeTime;

	/**
	 * EN: Global score of the call center for getting calls<br>
	 * DE: Globale Score des Callcenters f�r die Vermittlung von Anrufen
	 */
	public int score;

	/**
	 * EN: Factor to respect the idle time since the last call for the agent score<br>
	 * DE: Faktor f�r die Agentenscore zur Ber�cksichtigung der freien Zeit seit dem letzten Anruf */
	public double agentScoreFreeTimeSinceLastCall;
	/**
	 * EN: Factor to respect the idle time part for the agent score<br>
	 * DE: Faktor f�r die Agentenscore zur Ber�cksichtigung des Leerlaufanteils
	 */
	public double agentScoreFreeTimePart;

	/**
	 * EN: List of the names for the client type specific minimum waiting times<br>
	 * DE: Liste der Namen f�r die kundenspezifischen Mindestwartezeiten
	 */
	private final List<String> callerMinWaitingTimeName;
	/**
	 * EN: List of the client type specific minimum waiting times<br>
	 * DE: Liste der kundenspezifischen Mindestwartezeiten
	 */
	private final List<Integer> callerMinWaitingTime;

	/**
	 * EN: Productivity<bt>
	 * DE: Produktivit�t
	 */
	public String efficiency;

	/**
	 * EN: Disease-related surcharge<br>
	 * DE: Krankheitsbedingter Zuschlag
	 */
	public String surcharge;

	/**
	 * EN: Constructor of the class <code>CallCenterModelCallCenter</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModelCallCenter</code>
	 * @param	name	<br>
	 * EN: Name of the call center (<code>null</code> will be interpreted as an empty string)<br>
	 * DE: Name des Callcenters (<code>null</code> wird als leere Zeichenkette interpretiert)
	 * @param	active	<br>
	 * EN: Is the call center to be marked as active?<br>
	 * DE: Soll das Callcenter als aktiv gekennzeichnet werden?
	 */
	public CallCenterModelCallCenter(final String name, final boolean active) {
		if (name==null) this.name=""; else this.name=name;
		this.active=active;

		agents=new ArrayList<CallCenterModelAgent>();
		technicalFreeTime=0;
		score=1;
		agentScoreFreeTimeSinceLastCall=1;
		agentScoreFreeTimePart=0;

		callerMinWaitingTimeName=new ArrayList<String>();
		callerMinWaitingTime=new ArrayList<Integer>();
		efficiency="";
		surcharge="";
	}

	/**
	 * EN: Create a copy of the call center<br>
	 * DE: Erstellt eine Kopie des Callcenters
	 * @param	name	<br>
	 * EN: Name of the new call center (If <code>null</code> is given, the name of the original call center is used.)<br>
	 * DE: Name des neuen Callcenters (Wird <code>null</code> �bergeben, so wird der Name des Ausgangscallcenters verwendet.)
	 * @param	active	<br>
	 * EN: Is the call center to be marked as active?<br>
	 * DE: Soll das Callcenter als aktiv gekennzeichnet werden?
	 * @return
	 * EN: New call center object<br>
	 * DE: Neues Callcenter-Objekt
	 */
	public final CallCenterModelCallCenter clone(final String name, final boolean active) {
		CallCenterModelCallCenter callcenter=new CallCenterModelCallCenter(name,active);
		if (name==null) callcenter.name=this.name;

		for (CallCenterModelAgent agent : agents) callcenter.agents.add(agent.clone(agent.skillLevel,agent.active));

		callcenter.technicalFreeTime=technicalFreeTime;
		callcenter.score=score;
		callcenter.agentScoreFreeTimeSinceLastCall=agentScoreFreeTimeSinceLastCall;
		callcenter.agentScoreFreeTimePart=agentScoreFreeTimePart;

		callcenter.callerMinWaitingTimeName.addAll(callerMinWaitingTimeName);
		callcenter.callerMinWaitingTime.addAll(callerMinWaitingTime);

		callcenter.efficiency=efficiency;
		callcenter.surcharge=surcharge;

		return callcenter;
	}

	/**
	 * EN: Create a copy of the call center<br>
	 * DE: Erstellt eine Kopie des Callcenters
	 * @return
	 * EN: New call center object<br>
	 * DE: Neues Callcenter-Objekt
	 */
	@Override
	public Object clone() {
		return clone(null,active);
	}

	/**
	 * EN: Returns the number of agents groups in this call center<br>
	 * DE: Liefert die Anzahl an Agentengruppen in diesem Callcenter
	 * @return
	 * EN: Number of agents groups<br>
	 * DE: Anzahl an Agentengruppen
	 */
	public final int getAgentsCount() {
		return agents.size();
	}

	/**
	 * EN: Return some specific agents group<br>
	 * DE: Liefert eine bestimmte Agentengruppe zur�ck
	 * @param index	<br>
	 * EN: Number (0-based) of the agents group<br>
	 * DE: Nummer (0-basierend) der Agentengruppe
	 * @return
	 * EN: Returns in case of success the agents group object; if the index is out of range, <code>null</code> will be returned.<br>
	 * DE: Liefert im Erfolgsfall das Agentengruppen-Objekt zur�ck; liegt der angegebene Index au�erhalb des g�ltigen Bereichs wird <code>null</code> zur�ckgegeben.
	 */
	public final CallCenterModelAgent getAgents(final int index) {
		if (index<0 || index>=agents.size()) return null; else return agents.get(index);
	}

	/**
	 * EN: Create a new agents group and adds the group to the list of all agents groups.<br>
	 * DE: Legt eine neue Agentengruppe an und f�gt diese zu der Liste der Agentengruppen hinzu.
	 * @param	skillLevel	<br>
	 * EN: Skill level of the new agents group<br>
	 * DE: Skill-Level der neuen Agentengruppe
	 * @param	active	<br>
	 * EN: Is the new agents group to be marked as active?
	 * DE: Soll die neue Agentengruppe als aktiv gekennzeichnet werden?
	 * @return
	 * EN: Object of the new agents group<br>
	 * DE: Objekt der neuen Agentengruppe
	 */
	public final CallCenterModelAgent addAgents(final String skillLevel, final boolean active) {
		CallCenterModelAgent agent=new CallCenterModelAgent(skillLevel,active);
		agents.add(agent);
		return agent;
	}

	/**
	 * EN: Create a new agents group and adds the group to the list of all agents groups.<br>
	 * DE: Legt eine neue Agentengruppe an und f�gt diese zu der Liste der Agentengruppen hinzu.
	 * @param	skillLevel	<br>
	 * EN: Skill level of the new agents group<br>
	 * DE: Skill-Level der neuen Agentengruppe
	 * @return
	 * EN: Object of the new agents group<br>
	 * DE: Objekt der neuen Agentengruppe
	 */
	public final CallCenterModelAgent addAgents(final String skillLevel) {
		return addAgents(skillLevel,true);
	}

	/**
	 * EN: Adds an existing agents group to the list of all agents groups.<br>
	 * DE: F�gt ein bestehendes Agentengruppen-Objekt zu der Liste der Agentengruppen hinzu.
	 * @param agent	<br>
	 * EN: Existing agents group object<br>
	 * DE: Bestehendes Agentengruppen-Objekt
	 */
	public final void addAgents(final CallCenterModelAgent agent) {
		agents.add(agent);
	}

	/**
	 * EN: Sets a minimum waiting time for some client type for this call center.<br>
	 * DE: Stellt f�r einen bestimmten Kundentyp eine Mindestwartezeit f�r dieses Callcenter ein.
	 * @param caller	<br>
	 * EN: Client type of which the clients need to have waited an specific amount of time before they can enter this call center.<br>
	 * DE: Kundentyp, deren Kunden eine gewisse Zeit gewartet haben m�ssen, bevor sie in dieses Callcenter weitergeleitet werden d�rfen.
	 * @param time	<br>
	 * EN: Minimum waiting time for the clients of the specified type before entering this call center.<br>
	 * DE: Mindestwartzeit, bevor ein Kunde des angegebenen Typs in dieses Callcenter geleitet werden darf.
	 */
	public final void addMinWaitingTime(final String caller, final int time) {
		callerMinWaitingTimeName.add(caller);
		callerMinWaitingTime.add(time);
	}

	/**
	 * EN: Creates a new child node in the given XML parent node containing the complete call center data.<br>
	 * DE: Erstellt unterhalb des �bergebenen XML-Knotens einen neuen Knoten, der die gesamten Callcenter-Daten enth�lt.
	 * @param parent	<br>
	 * EN: Parent XML node<br>
	 * DE: Eltern-XML-Knoten
	 */
	final void saveToXML(final Element parent) {
		Document doc=parent.getOwnerDocument();
		Element node=doc.createElement(Language.get(Language.Model_CallCenter)); parent.appendChild(node);
		if (!active) node.setAttribute(Language.get(Language.Model_General_Attribute_Active),"0");
		node.setAttribute(Language.get(Language.Model_General_Attribute_Name),name);
		Element e,e2;

		for (int i=0;i<agents.size();i++) agents.get(i).saveToXML(node);
		node.appendChild(e=doc.createElement(Language.get(Language.Model_CallCenter_TechnicalFreeTime))); e.setTextContent(""+technicalFreeTime);
		node.appendChild(e=doc.createElement(Language.get(Language.Model_CallCenter_CallCenterScore))); e.setTextContent(""+score);
		node.appendChild(e=doc.createElement(Language.get(Language.Model_CallCenter_AgentsScore)));
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_CallCenter_AgentsScore_LastCall))); e2.setTextContent(Numbers.formatSystemNumber(agentScoreFreeTimeSinceLastCall));
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_CallCenter_AgentsScore_Part))); e2.setTextContent(Numbers.formatSystemNumber(agentScoreFreeTimePart));
		if (callerMinWaitingTimeName.size()>0 && callerMinWaitingTime.size()>0) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_CallCenter_MinimumWaitingTime)));
			for (int i=0;i<Math.min(callerMinWaitingTimeName.size(),callerMinWaitingTime.size());i++) {
				if (callerMinWaitingTimeName.get(i)==null || callerMinWaitingTime.get(i)==null) continue;
				e.appendChild(e2=doc.createElement(Language.get(Language.Model_CallCenter_MinimumWaitingTime_ClientType)));
				e2.setAttribute(Language.get(Language.Model_General_Attribute_Name),callerMinWaitingTimeName.get(i));
				e2.setTextContent(""+callerMinWaitingTime.get(i));
			}
		}
		if (efficiency!=null && !efficiency.isEmpty()) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_General_Efficiency))); e.setTextContent(efficiency);
		}
		if (surcharge!=null && !surcharge.isEmpty()) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_General_Surcharge))); e.setTextContent(surcharge);
		}
	}

	/**
	 * EN: Trys to load a cll center from the given XML node<br>
	 * DE: Versucht ein Callcenter aus dem �bergebenen XML-Node zu laden
	 * @param node	<br>
	 * EN: XML node containing the call center data<br>
	 * DE: XML-Knoten, der die Callcenter-Daten enth�lt
	 * @return
	 * EN: If an error occurs, an error message will be returned as a string. In case of success <code>null</code> will be returned.<br>
	 * DE: Tritt ein Fehler auf, so wird die Fehlermeldung als String zur�ckgegeben. Im Erfolgsfall wird <code>null</code> zur�ckgegeben.
	 */
	final String loadFromXML(final Element node) {
		String b=node.getAttribute(Language.get(Language.Model_General_Attribute_Active));
		if (b!=null && (b.equals("0") || b.equalsIgnoreCase(Language.get(Language.Model_General_Bool_False)) || b.equalsIgnoreCase(Language.get(Language.Model_General_Bool_Off)) || b.equalsIgnoreCase(Language.get(Language.Model_General_Bool_No)))) active=false;

		name=node.getAttribute(Language.get(Language.Model_General_Attribute_Name));

		agents.clear();
		technicalFreeTime=0;
		score=1;
		agentScoreFreeTimeSinceLastCall=1;
		agentScoreFreeTimePart=0;
		callerMinWaitingTimeName.clear();
		callerMinWaitingTime.clear();
		efficiency="";
		surcharge="";

		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			String s=e.getNodeName();

			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents))) {
				CallCenterModelAgent a=new CallCenterModelAgent("",true);
				String t=a.loadFromXML(e); if (t!=null) return t+"("+String.format(Language.get(Language.Model_Agents_Error),agents.size()+1);
				agents.add(a); continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_CallCenter_TechnicalFreeTime))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null) return Language.get(Language.Model_CallCenter_TechnicalFreeTime_Error);
				technicalFreeTime=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_CallCenter_CallCenterScore))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null) return Language.get(Language.Model_CallCenter_CallCenterScore_Error);
				score=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_CallCenter_AgentsScore))) {
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);
					String t=e2.getNodeName();
					if (t.equalsIgnoreCase(Language.get(Language.Model_CallCenter_AgentsScore_LastCall))) {
						Double D=Numbers.getNotNegativeSystemDouble(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_CallCenter_AgentsScore_LastCall_Error);
						agentScoreFreeTimeSinceLastCall=D; continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_CallCenter_AgentsScore_Part))) {
						Double D=Numbers.getNotNegativeSystemDouble(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_CallCenter_AgentsScore_Part_Error);
						agentScoreFreeTimePart=D; continue;
					}
				}
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_CallCenter_MinimumWaitingTime))) {
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);
					if (!e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_CallCenter_MinimumWaitingTime_ClientType))) continue;
					Integer K=Numbers.getNotNegativeInteger(e2.getTextContent());
					if (K==null) return Language.get(Language.Model_CallCenter_MinimumWaitingTime_ClientType_Error);
					callerMinWaitingTimeName.add(e2.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
					callerMinWaitingTime.add(K);
				}
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Efficiency))) {
				efficiency=e.getTextContent();
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Surcharge))) {
				surcharge=e.getTextContent();
				continue;
			}
		}
		return null;
	}
}