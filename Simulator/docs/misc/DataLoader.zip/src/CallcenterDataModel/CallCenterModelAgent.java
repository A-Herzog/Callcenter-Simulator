package CallcenterDataModel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import CallcenterDataModel.Tools.Distribution;
import CallcenterDataModel.Tools.Language;
import CallcenterDataModel.Tools.Numbers;

/**
 * EN: Encapsulates the XML data of an agents group<br>
 * DE: Kapselt die XML-Daten einer Agentrgruppe
 * @author Alexander Herzog
 */
public final class CallCenterModelAgent implements Cloneable {
	/**
	 * EN: Number of agents in this group (if =-1 use number of agents per half-hour interval; if =-2 use client arrivals)<br>
	 * DE: Anzahl der Angenten in dieser Gruppe (wenn =-1, aus Anzahl pro Halbstundenintervall aufbauen; wenn =-2, gem�� Kundenank�nften)
	 */
	private int count;

	/**
	 * EN: Agents group active?<br>
	 * DE: Agentengruppe aktiv?
	 */
	public boolean active;

	/** *** count==-1 *** */
	/**
	 * EN: Number of agents per half-hour interval<br>
	 * DE: Anzahl pro Halbstundenintervall */
	private String countPerInterval;
	/**
	 * EN: Shift up to 0:00 am is open end<br>
	 * DE: Schicht bis 24 Uhr bis open end verl�ngern
	 */
	private boolean lastShiftIsOpenEnd;

	/** *** count==-2 *** */
	/**
	 * EN: Available agents man hours<br>
	 * DE: Verf�gbare Mann-Halbstunden
	 */
	private int byCallersAvailableHalfhours;
	/**
	 * EN: Client types distirbutions from which the agents distribution is to be calculated<br>
	 * DE: Kundentypenverteilungen aus denen die Agentenverteilung berechnet werden soll
	 */
	private List<String> byCallers;
	/**
	 * EN: Weights of the individual client types for the calucation of the agents distribution<br>
	 * DE: Gewichtung der einzelnen Kundentypen bei der Bestimmung der Agentenverteilung
	 */
	private List<Double> byCallersRate;

	/** *** count>=0 *** */
	/**
	 * EN: Start working time (if count>=0)<br>
	 * DE: Beginn der Arbeitszeit (wenn count>=0)
	 */
	private int workingTimeStart;
	/**
	 * EN: Stop working time (conversations in progress are being finished) (if count>=0)<br>
	 * DE: Ende der Arbeitszeit (laufende Gespr�che werden �ber das Arbeitszeitende hinaus zu Ende gef�hrt) (wenn count>=0)
	 */
	private int workingTimeEnd;
	/**
	 * EN: Respect the specified working time end (<code>workingTimeEnd</code>)? (if count>=0)<br>
	 * DE: Arbeitszeitende (<code>workingTimeEnd</code>) ber�cksichtigen ? (wenn count>=0)
	 */
	private boolean workingNoEndTime;

	/**
	 * EN: Name of the <code>CallcenterModellSkillLevel</code> object<br>
	 * DE: Name des <code>CallcenterModellSkillLevel</code>-Objektes
	 */
	public String skillLevel;

	/**
	 * EN: Cost per working hour (independent of the work load)<br>
	 * DE: Kosten pro Arbeitsstunde (unabh�ngig von der Auslastung)
	 */
	public double costPerWorkingHour;

	/**
	 * EN: Names of the client types for calculating the costs<br>
	 * DE: Namen der Kundentypen zur Bestimmung der Kosten
	 */
	private final List<String> costCallerTypes;
	/**
	 * EN: Costs per call<br>
	 * DE: Kosten pro Anruf
	 */
	private final List<Double> costPerCall;
	/**
	 * EN: Costs per conversation minute<br>
	 * DE: Kosten pro Gespr�chsminute
	 */
	private final List<Double> costPerCallMinute;

	/**
	 * EN: Preferred shift length (in half-hour intervals) if the agents are planned from a distribution (if =-1 the global preference is used)<br>
	 * DE: Bevorzugte Schichtl�nge (in Halbstundenintervallen) wenn die Agenten aus Verteilungen aufgebaut werden (=-1, wenn die globale Vorgabe verwendet werden soll)
	 */
	private int preferredShiftLength;

	/**
	 * EN: Productivity (on count<0)<br>
	 * DE: Produktivit�t (bei count<0)
	 */
	public String efficiency;

	/**
	 * EN: Disease-related surcharge  (on count<0)<br>
	 * DE: Krankheitsbedingter Zuschlag (bei count<0)
	 */
	public String surcharge;

	/**
	 * EN: Constructor of the class <code>CallCenterModelAgent</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModelAgent</code>
	 * @param	skillLevel	<br>
	 * EN: Skill level of the agents group<br>
	 * DE: Skill-Level der Agentengruppe
	 * @param	active	<br>
	 * EN: Is the agents group to be marked as active?<br>
	 * DE: Soll die Agentengruppe als aktiv gekennzeichnet werden?
	 */
	public CallCenterModelAgent(final String skillLevel, final boolean active) {
		count=0;
		this.active=active;
		countPerInterval=Distribution.getData(0,48);
		lastShiftIsOpenEnd=false;
		byCallersAvailableHalfhours=0;
		byCallers=new ArrayList<String>();
		byCallersRate=new ArrayList<Double>();
		workingTimeStart=0;
		workingTimeEnd=86400;
		workingNoEndTime=false;
		this.skillLevel=skillLevel;
		costPerWorkingHour=0;
		costCallerTypes=new ArrayList<String>();
		costPerCall=new ArrayList<Double>();
		costPerCallMinute=new ArrayList<Double>();
		preferredShiftLength=-1;
		efficiency="";
		surcharge="";
	}

	/**
	 * EN: Creates a copy of the agents group<br>
	 * DE: Erstellt eine Kopie der Agentengruppe
	 * @param	skillLevel	<br>
	 * EN: Skill level of the new agents group<br>
	 * DE: Skill-Level der neuen Agentengruppe
	 * @param	active	<br>
	 * EN: Is the new agents group to be marked as active?<br>
	 * DE: Soll die Agentengruppe als aktiv gekennzeichnet werden?
	 * @return
	 * EN: New agents group object<br>
	 * DE: Neues Agentengruppen-Objekt
	 */
	public final CallCenterModelAgent clone(final String skillLevel, final boolean active) {
		CallCenterModelAgent agent=new CallCenterModelAgent(skillLevel,active);

		agent.count=count;
		agent.countPerInterval=countPerInterval;
		agent.lastShiftIsOpenEnd=lastShiftIsOpenEnd;
		agent.byCallersAvailableHalfhours=byCallersAvailableHalfhours;
		agent.byCallers.addAll(byCallers);
		agent.byCallersRate.addAll(byCallersRate);
		agent.workingTimeStart=workingTimeStart;
		agent.workingTimeEnd=workingTimeEnd;
		agent.workingNoEndTime=workingNoEndTime;
		agent.costPerWorkingHour=costPerWorkingHour;
		agent.costCallerTypes.addAll(costCallerTypes);
		agent.costPerCall.addAll(costPerCall);
		agent.costPerCallMinute.addAll(costPerCallMinute);
		agent.preferredShiftLength=preferredShiftLength;
		agent.efficiency=efficiency;
		agent.surcharge=surcharge;

		return agent;
	}

	/**
	 * EN: Creates a copy of the agents group<br>
	 * DE: Erstellt eine Kopie der Agentengruppe
	 * @return
	 * EN: New agents group object<br>
	 * DE: Neues Agentengruppen-Objekt
	 */
	@Override
	public Object clone() {
		return clone(skillLevel,active);
	}

	/**
	 * EN: Sets up fixed working times for the agents group.<br>
	 * DE: Stellt ein, dass die Agentengruppe feste Arbeitszeiten besitzt.
	 * @param count	<br>
	 * EN: Number of agents in this group<br>
	 * DE: Anzahl an Agenten in dieser Gruppe
	 * @param workingTimeStart	<br>
	 * EN: Begin of the working time (in seconds since midnight)<br>
	 * DE: Beginn der Dienstzeit (in Sek. seit Mitternacht)
	 * @param workingTimeEnd	<br>
	 * EN: Working time end (in seconds since midnight)<br>
	 * DE: Ende der Dienstzeit (in Sek. seit Mitternacht)
	 */
	public final void setFixedWorkingTime(final int count, final int workingTimeStart, final int workingTimeEnd) {
		this.count=count;
		this.workingTimeStart=workingTimeStart;
		this.workingTimeEnd=workingTimeEnd;
		workingNoEndTime=false;
	}

	/**
	 * EN: Sets up fixed working times for the agents group. The working time begin is configurable; the agents will work until there are no more clients in the system (and also no more will arrive)<br>
	 * DE: Stellt ein, dass die Agentengruppe feste Arbeitszeiten besitzt. Der Dienstzeitbeginn ist einstellbar; die Agenten arbeiten, bis keine Kunden mehr im System sind (und auch keine mehr ankommen werden)
	 * @param count	<br>
	 * EN: Number of agents in this group<br>
	 * DE: Anzahl an Agenten in dieser Gruppe
	 * @param workingTimeStart	<br>
	 * EN: Begin of the working time (in seconds since midnight)<br>
	 * DE: Beginn der Dienstzeit (in Sek. seit Mitternacht)
	 */
	public final void setFixedWorkingTimeOpenEnd(final int count, final int workingTimeStart) {
		this.count=count;
		this.workingTimeStart=workingTimeStart;
		this.workingTimeEnd=86400;
		workingNoEndTime=true;
		preferredShiftLength=-1;
	}

	/**
	 * EN: Sets up that the agents in this group are defined be a number of agents per half-hour interval.<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe als Anzahl pro halber Stunde vorgegeben werden.
	 * @param countPerInterval	<br>
	 * EN: Array of 48 entries defining how many are working per half-hour interval.<br>
	 * DE: Array mit 48 Eintr�ge, welches angibt, in welchem Intervall wie viele Agenten arbeiten soll.
	 * @param lastShiftIsOpenEnd	<br>
	 * EN: Defines if the last 11:30pm-00:00am shift should stop working at 00:00am or if these agents should continue working until there are no remaining clients anymore.<br>
	 * DE: Gibt an, ob die letzte 23:30-00:00 Schicht die Arbeit im 00:00 beenden soll oder ob die Agenten in dieser Schicht alle verbleibenden Kunden abarbeiten sollen.
	 * @param preferredShiftLength	<br>
	 * EN: Defined the preferred maximum shift length in half-hour intervals.<br>
	 * DE: Gibt die bevorzugte maximale Schichtl�nge gemessen in Halbstundenintervallen an.
	 */
	public final void setAgentsPerInterval(final int[] countPerInterval, final boolean lastShiftIsOpenEnd, final int preferredShiftLength) {
		count=-1;
		this.countPerInterval=Distribution.getData(countPerInterval);
		this.lastShiftIsOpenEnd=lastShiftIsOpenEnd;
		this.preferredShiftLength=preferredShiftLength;
	}

	/**
	 * EN: Sets up that the agents in this group are defined be a number of agents per half-hour interval. (As preferred maximum shift length the global value for the model is used.)<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe als Anzahl pro halber Stunde vorgegeben werden. (Als bevorzugte maximale Schichtl�nge wird der globale Wert, der im Modell hinterlegt ist, verwendet.)
	 * @param countPerInterval	<br>
	 * EN: Array of 48 entries defining how many are working per half-hour interval.<br>
	 * DE: Array mit 48 Eintr�ge, welches angibt, in welchem Intervall wie viele Agenten arbeiten soll.
	 * @param lastShiftIsOpenEnd	<br>
	 * EN: Defines if the last 11:30pm-00:00am shift should stop working at 00:00am or if these agents should continue working until there are no remaining clients anymore.<br>
	 * DE: Gibt an, ob die letzte 23:30-00:00 Schicht die Arbeit im 00:00 beenden soll oder ob die Agenten in dieser Schicht alle verbleibenden Kunden abarbeiten sollen.
	 */
	public final void setAgentsPerInterval(final int[] countPerInterval, final boolean lastShiftIsOpenEnd) {
		setAgentsPerInterval(countPerInterval,lastShiftIsOpenEnd,-1);
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals.<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll.
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerTypes	<br>
	 * EN: Client types whos arrival distributions are to be used for calculating the agents distribution.<br>
	 * DE: Kundentypen, deren Ankunftsverteilung die bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param callerRates	<br>
	 * EN: Rates at which the different client types are to be used for calculating the agents distribution.<br>
	 * DE: Raten, mit denen die Ankunftsverteilungen der Kundentypen bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param preferredShiftLength	<br>
	 * EN: Defined the preferred maximum shift length in half-hour intervals.<br>
	 * DE: Gibt die bevorzugte maximale Schichtl�nge gemessen in Halbstundenintervallen an.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final List<String> callerTypes, final List<Double> callerRates, final int preferredShiftLength) {
		count=-2;
		byCallersAvailableHalfhours=availableHalfhours;
		byCallers.addAll(callerTypes);
		byCallersRate.addAll(callerRates);
		this.preferredShiftLength=preferredShiftLength;
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals. (As preferred maximum shift length the global value for the model is used.)<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll. (Als bevorzugte maximale Schichtl�nge wird der globale Wert, der im Modell hinterlegt ist, verwendet.)
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerTypes	<br>
	 * EN: Client types whos arrival distributions are to be used for calculating the agents distribution.<br>
	 * DE: Kundentypen, deren Ankunftsverteilung die bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param callerRates	<br>
	 * EN: Rates at which the different client types are to be used for calculating the agents distribution.<br>
	 * DE: Raten, mit denen die Ankunftsverteilungen der Kundentypen bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final List<String> callerTypes, final List<Double> callerRates) {
		setAgentsByFreshCalls(availableHalfhours,callerTypes,callerRates,-1);
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals.<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll.
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerTypes	<br>
	 * EN: Client types whos arrival distributions are to be used for calculating the agents distribution.<br>
	 * DE: Kundentypen, deren Ankunftsverteilung die bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param callerRates	<br>
	 * EN: Rates at which the different client types are to be used for calculating the agents distribution.<br>
	 * DE: Raten, mit denen die Ankunftsverteilungen der Kundentypen bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param preferredShiftLength	<br>
	 * EN: Defined the preferred maximum shift length in half-hour intervals.<br>
	 * DE: Gibt die bevorzugte maximale Schichtl�nge gemessen in Halbstundenintervallen an.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final String[] callerTypes, final double[] callerRates, final int preferredShiftLength) {
		Double[] callerRatesObj=new Double[callerRates.length];
		for (int i=0;i<callerRates.length;i++) callerRatesObj[i]=callerRates[i];
		setAgentsByFreshCalls(availableHalfhours,new ArrayList<String>(Arrays.asList(callerTypes)),new ArrayList<Double>(Arrays.asList(callerRatesObj)),preferredShiftLength);
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals. (As preferred maximum shift length the global value for the model is used.)<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll. (Als bevorzugte maximale Schichtl�nge wird der globale Wert, der im Modell hinterlegt ist, verwendet.)
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerTypes	<br>
	 * EN: Client types whos arrival distributions are to be used for calculating the agents distribution.<br>
	 * DE: Kundentypen, deren Ankunftsverteilung die bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 * @param callerRates	<br>
	 * EN: Rates at which the different client types are to be used for calculating the agents distribution.<br>
	 * DE: Raten, mit denen die Ankunftsverteilungen der Kundentypen bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final String[] callerTypes, final double[] callerRates) {
		setAgentsByFreshCalls(availableHalfhours,callerTypes,callerRates,-1);
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals. (As preferred maximum shift length the global value for the model is used.)<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll. (Als bevorzugte maximale Schichtl�nge wird der globale Wert, der im Modell hinterlegt ist, verwendet.)
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerTypes	<br>
	 * EN: Client types whos arrival distributions are to be used for calculating the agents distribution.<br>
	 * DE: Kundentypen, deren Ankunftsverteilung die bei der Berechnung der Verteilung der Agenten ber�cksichtigt werden sollen.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final String[] callerTypes) {
		final double[] callerRates=new double[callerTypes.length];
		Arrays.fill(callerRates,1);
		setAgentsByFreshCalls(availableHalfhours,callerTypes,callerRates,-1);
	}

	/**
	 * EN: Sets up to distribute the working agents over the day by the client arrivals. (As preferred maximum shift length the global value for the model is used.)<br>
	 * DE: Stellt ein, dass die Anzahl an arbeitenden Agenten in dieser Gruppe pro Halbstundenintervall der Kundenankunftsverteilung nachmodelliert werden soll. (Als bevorzugte maximale Schichtl�nge wird der globale Wert, der im Modell hinterlegt ist, verwendet.)
	 * @param availableHalfhours	<br>
	 * EN: Number of available agents work force measured in half-hour intervals.<br>
	 * DE: Anzahl an verf�gbaren Arbeitsleistung gemessen in Agentenhalbstunden.
	 * @param callerType	<br>
	 * EN: Client type whos arrival distribution is to be used for calculating the agents distribution.<br>
	 * DE: Kundentype, dessen Ankunftsverteilung f�r die Erstellung der Verteilung der Agenten verwendet werden sollen.
	 */
	public final void setAgentsByFreshCalls(final int availableHalfhours, final String callerType) {
		setAgentsByFreshCalls(availableHalfhours,new String[]{callerType});
	}

	/**
	 * EN: Creates a new costs record for serving client of some client type by agents of the current group.<br>
	 * DE: Legt einen Kostendatensatz f�r die Bedienung von Kunden eine bestimmten Typs durch diese Agentengruppe an.
	 * @param callerTyp	<br>
	 * EN: Customer type, to which the cost record should refer.<br>
	 * DE: Kundentyp, auf den sich der Kostendatensatz beziehen soll.
	 * @param costPerCall	<br>
	 * EN: Costs for serving an client of this type by and agent of this group.<br>
	 * DE: Kosten f�r die Bedienung eines Anrufs eines Kunden des gew�hlten Typs durch diese Agentengruppe.
	 * @param costPerMinute	<br>
	 * EN: Costs per conversation minute when serving an client of this type by and agent of this group.<br>
	 * DE: Kosten pro Gespr�chsminute bei Bedienung eines Anrufs eines Kunden des gew�hlten Typs durch diese Agentengruppe.
	 */
	public final void addCostsByCaller(final String callerTyp, final double costPerCall, final double costPerMinute) {
		costCallerTypes.add(callerTyp);
		this.costPerCall.add(costPerCall);
		costPerCallMinute.add(costPerMinute);
	}

	/**
	 * EN: Create a new child node in the giving parent XML node containing the agents group data.<br>
	 * DE: Erstellt unterhalb des �bergebenen XML-Knotens einen neuen Knoten, der die gesamten Agenten-Daten enth�lt.
	 * @param parent	<br>
	 * EN: Parent XML node<br>
	 * DE: Eltern-XML-Knoten
	 */
	final void saveToXML(final Element parent) {
		Document doc=parent.getOwnerDocument();
		Element node=doc.createElement(Language.get(Language.Model_Agents)); parent.appendChild(node);
		if (!active) node.setAttribute(Language.get(Language.Model_General_Attribute_Active),"0");

		Element e,e2;

		if (count>=0) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_Count))); e.setTextContent(""+count);
			node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_WorkingStart))); e.setTextContent(Numbers.formatTime(workingTimeStart));
			if (!workingNoEndTime) node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_WorkingEnd))); e.setTextContent(Numbers.formatTime(workingTimeEnd));
		} else {
			if (count==-1) {
				node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_Distribution))); e.setTextContent(countPerInterval);
				if (lastShiftIsOpenEnd)	e.setAttribute(Language.get(Language.Model_Agents_Distribution_LastShiftOpenEnd),"1");			}
			if (count==-2) {
				node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_ByClients)));
				e.setAttribute(Language.get(Language.Model_Agents_ByClients_WorkingHalfHours),""+byCallersAvailableHalfhours);
				for (int i=0;i<Math.min(byCallers.size(),byCallersRate.size());i++) {
					if (byCallersRate.get(i)==null || byCallers.get(i)==null) continue;
					e.appendChild(e2=doc.createElement(Language.get(Language.Model_Agents_ByClients_ClientType)));
					e2.setAttribute(Language.get(Language.Model_Agents_ByClients_ClientType_Rate),Numbers.formatSystemNumber(byCallersRate.get(i)));
					e2.setTextContent(byCallers.get(i));
				}
			}
		}
		node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_SkillLevel))); e.setTextContent(skillLevel);
		node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_CostsPerHour))); e.setTextContent(Numbers.formatSystemNumber(costPerWorkingHour));
		for (int i=0;i<Math.min(Math.min(costCallerTypes.size(),costPerCall.size()),costPerCallMinute.size());i++) {
			if (costCallerTypes.get(i)==null || costPerCall.get(i)==null || costPerCallMinute.get(i)==null) continue;
			node.appendChild(e=doc.createElement(Language.get(Language.Model_Agents_CostsPerClientType)));
			e.setAttribute(Language.get(Language.Model_Agents_CostsPerClientType_ClientType),costCallerTypes.get(i));
			e.setAttribute(Language.get(Language.Model_Agents_CostsPerClientType_PerCall),Numbers.formatSystemNumber(costPerCall.get(i)));
			e.setAttribute(Language.get(Language.Model_Agents_CostsPerClientType_PerMinute),Numbers.formatSystemNumber(costPerCallMinute.get(i)));
		}

		if (preferredShiftLength>=0) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_General_PreferredShiftLength))); e.setTextContent(""+preferredShiftLength);
		}
		if (efficiency!=null && !efficiency.isEmpty()) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_General_Efficiency))); e.setTextContent(efficiency);
		}
		if (surcharge!=null && !efficiency.isEmpty()) {
			node.appendChild(e=doc.createElement(Language.get(Language.Model_General_Surcharge))); e.setTextContent(surcharge);
		}
	}

	/**
	 * EN: Trys to load the skill level data from the given XML node<br>
	 * DE: Versucht einen Agenten-Datensatz aus dem �bergebenen XML-Node zu laden
	 * @param node	<br>
	 * EN: XML node containing the agents data<br>
	 * DE: XML-Knoten, der die Agenten-Daten enth�lt
	 * @return
	 * EN: If an error occurs, the error message will be returned as a string. In case of success <code>null</code> will be returned.<br>
	 * DE: Tritt ein Fehler auf, so wird die Fehlermeldung als String zur�ckgegeben. Im Erfolgsfall wird <code>null</code> zur�ckgegeben.
	 */
	final String loadFromXML(final Element node) {
		count=-1;
		active=true;
		String newCountPerInterval=null;
		List<String> newByCaller=null;
		List<Double> newByCallerRate=null;

		workingTimeStart=0;
		workingTimeEnd=86400;
		workingNoEndTime=true;
		skillLevel="";

		efficiency="";
		surcharge="";

		String a=node.getAttribute(Language.get(Language.Model_General_Attribute_Active));
		if (a!=null && (a.equals("0") || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_False)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_Off)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_No)))) active=false;

		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			String s=e.getNodeName();

			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_Count))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null) return Language.get(Language.Model_Agents_Count_Error);
				count=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_WorkingStart))) {
				Integer J=Numbers.getTime(e.getTextContent());
				if (J==null) return Language.get(Language.Model_Agents_WorkingStart_Error);
				workingTimeStart=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_WorkingEnd))) {
				Integer J=Numbers.getTime(e.getTextContent());
				if (J==null) return Language.get(Language.Model_Agents_WorkingEnd_Error);
				workingTimeEnd=J; workingNoEndTime=false; continue;
			}
			if ( s.equalsIgnoreCase(Language.get(Language.Model_Agents_Distribution))) {
				newCountPerInterval=e.getTextContent();
				if (newCountPerInterval==null) return Language.get(Language.Model_Agents_Distribution_Error);
				String o=e.getAttribute(Language.get(Language.Model_Agents_Distribution_LastShiftOpenEnd));
				lastShiftIsOpenEnd=(o!=null && !o.isEmpty() && (o.equals("1") || o.equalsIgnoreCase(Language.get(Language.Model_General_Bool_True)) || o.equalsIgnoreCase(Language.get(Language.Model_General_Bool_On)) || o.equalsIgnoreCase(Language.get(Language.Model_General_Bool_Yes))));
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_ByClients))) {
				Integer I=Numbers.getNotNegativeInteger(e.getAttribute(Language.get(Language.Model_Agents_ByClients_WorkingHalfHours)));
				if (I==null) return Language.get(Language.Model_Agents_ByClients_WorkingHalfHours_Error);
				byCallersAvailableHalfhours=I;
				newByCaller=new ArrayList<String>();
				newByCallerRate=new ArrayList<Double>();
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);
					String t=e2.getNodeName();
					if (!t.equalsIgnoreCase(Language.get(Language.Model_Agents_ByClients_ClientType))) continue;
					Double D=Numbers.getNotNegativeSystemDouble(e2.getAttribute(Language.get(Language.Model_Agents_ByClients_ClientType_Rate)));
					if (D==null) return Language.get(Language.Model_Agents_ByClients_ClientType_Rate_Error);
					newByCallerRate.add(D);
					newByCaller.add(e2.getTextContent());
				}
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_SkillLevel))) {
				skillLevel=e.getTextContent();
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_CostsPerHour))) {
				Double D=Numbers.getNotNegativeSystemDouble(e.getTextContent());
				if (D==null) return Language.get(Language.Model_Agents_CostsPerHour_Error);
				costPerWorkingHour=D;
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_Agents_CostsPerClientType))) {
				String s1=e.getAttribute(Language.get(Language.Model_Agents_CostsPerClientType_ClientType));
				if (s1==null || s1.isEmpty()) return Language.get(Language.Model_Agents_CostsPerClientType_ClientType_NoData);
				String s2=e.getAttribute(Language.get(Language.Model_Agents_CostsPerClientType_PerCall));
				if (s2==null || s2.isEmpty()) return Language.get(Language.Model_Agents_CostsPerClientType_PerCall_NoData);
				String s3=e.getAttribute(Language.get(Language.Model_Agents_CostsPerClientType_PerMinute));
				if (s3==null || s3.isEmpty()) return Language.get(Language.Model_Agents_CostsPerClientType_PerMinute_NoData);
				Double D2=Numbers.getNotNegativeSystemDouble(s2);
				Double D3=Numbers.getNotNegativeSystemDouble(s3);
				if (D2==null) return Language.get(Language.Model_Agents_CostsPerClientType_PerCall_Error);
				if (D3==null) return Language.get(Language.Model_Agents_CostsPerClientType_PerMinute_Error);
				costCallerTypes.add(s1);
				costPerCall.add(D2);
				costPerCallMinute.add(D3);
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_PreferredShiftLength))) {
				Integer J=Numbers.getInteger(e.getTextContent());
				if (J==null || J==0) return Language.get(Language.Model_General_PreferredShiftLength_Error);
				if (J<0) J=-1;
				preferredShiftLength=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Efficiency))) {
				efficiency=e.getTextContent();
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Surcharge))) {
				surcharge=e.getTextContent();
				continue;
			}
		}

		if (count==-1 && newCountPerInterval==null && newByCaller==null) return Language.get(Language.Model_Agents_ModeError);
		if (newCountPerInterval!=null) {count=-1; countPerInterval=newCountPerInterval;}
		if (newByCaller!=null) {count=-2; byCallers=newByCaller; byCallersRate=newByCallerRate;}

		return null;
	}
}