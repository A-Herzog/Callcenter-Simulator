package CallcenterDataModel;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import CallcenterDataModel.Tools.Distribution;
import CallcenterDataModel.Tools.Language;
import CallcenterDataModel.Tools.Numbers;

/**
 * EN: Encapsulates the XML data of a client type<br>
 * DE: Kapselt die XML-Daten eines Kundentyps
 * @author Alexander Herzog
 */
public final class CallCenterModelCaller implements Cloneable {
	/**
	 * EN: Name of the client type<br>
	 * DE: Name des Kundentyps
	 */
	public String name;

	/**
	 * EN: Client type active?<br>
	 * DE: Kundentyp aktiv?
	 */
	public boolean active;

	/**
	 * EN: Mean of the number of frsh calls of this type per day<br>
	 * DE: Mittelwert der Anzahl an Kunden dieses Typs pro Tag
	 */
	public int freshCallsCountMean;
	/**
	 * EN: Standard deviation of the number of frsh calls of this type per day<br>
	 * DE: Standardabweichung der Anzahl an Kunden dieses Typs pro Tag
	 */
	public double freshCallsCountSD;
	/**
	 * EN: Distribution of the fresh calls over the day<br>
	 * DE: Verteilung der Kundenank�nfte �ber den Tag
	 */
	public String freshCallsDist;

	/**
	 * EN: Base score for this client type<br>
	 * DE: Score-Basis f�r diesen Kundentyp
	 */
	public double scoreBase;
	/**
	 * EN: Score increasement per waiting second<br>
	 * DE: Erh�hung des Scores pro Wartesekunde
	 */
	public double scoreSecond;
	/**
	 * EN: Score increasement on forwarding<br>
	 * DE: Erh�hung des Scores, wenn es sich um weitergeleitete Kunden handelt
	 */
	public double scoreContinued;

	/**
	 * EN: Does a client of this type blocks a phone line?<br>
	 * DE: Belegt ein Kunde dieses Typs eine Telefonleitung?
	 */
	public boolean blocksLine;

	/**
	 * EN: Number of seconds to be used for calculating the service level (or -1 for model.serviceLevelSeconds)<br>
	 * DE: Zuverwendende Anzahl an Sekunden f�r den Service-Level (oder -1 f�r model.serviceLevelSeconds)
	 */
	public int serviceLevelSeconds;

	/**
	 * EN: Clients are willing to wait for an infinite time.<br>
	 * DE: Kunden sind bereit, beliebig lange zu warten.
	 * @see waitingTimeMode
	 */
	private static final int WAITING_TIME_MODE_OFF=0;

	/**
	 * EN: Waiting time tolerance as defined in <code>waitingTimeDist</code><br>
	 * DE: Wartezeittoleranzverteilung gem�� <code>waitingTimeDist</code>
	 * @see waitingTimeMode
	 * @see waitingTimeDist
	 */
	private static final int WAITING_TIME_MODE_SHORT=1;

	/**
	 * EN: Waiting time tolerance as defined in <code>waitingTimeDistLong</code><br>
	 * DE: Wartezeittoleranzverteilung gem�� <code>waitingTimeDistLong</code>
	 * @see waitingTimeMode
	 * @see waitingTimeDistLong
	 */
	private static final int WAITING_TIME_MODE_LONG=2;

	/**
	 * EN: Do not load waiting time tolerance from some distribution, but estimate it from the average waiting time and the cancelation rate<br>
	 * DE: Wartezeittoleranz nicht per Verteilung vorgeben, sondern aus mittlerer Wartezeit und Abbruchwahrscheinlichkeit sch�tzen
	 * @see waitingTimeMode
	 * @see waitingTimeCalcMeanWaitingTime
	 * @see waitingTimeCalcCancelProbability
	 * @see waitingTimeCalcAdd
	 */
	private static final int WAITING_TIME_MODE_CALC=3;

	/**
	 * EN: Is the waiting tolerance active or are the clients willing to wait for any length of time?<br>
	 * DE: Ist die Wartezeittoleranz aktiv oder warten die Kunden beliebig lang?
	 */
	private int waitingTimeMode;

	/**
	 * EN: Waiting time tolerance distribution (short waiting time tolerance)<br>
	 * DE: Wartezeittoleranzverteilung (kurze Wartezeittoleranz)
	 */
	private String waitingTimeDist;

	/**
	 * EN: Waiting time tolerance distribution (long waiting time tolerance)<br>
	 * DE: Wartezeittoleranzverteilung (lange Wartezeittoleranz)
	 */
	private String waitingTimeDistLong;

	/**
	 * EN: Measured average waiting time for waiting time tolerance estimation<br>
	 * DE: Gemessene mittlere Wartezeit zur Sch�tzung der Wartezeittoleranz
	 */
	private double waitingTimeCalcMeanWaitingTime;
	/**
	 * EN: Measured cancelation rate for waiting time tolerance estimation<br>
	 * DE: Gemessene Abbruchwahrscheinlichkeit zur Sch�tzung der Wartezeittoleranz
	 */
	private double waitingTimeCalcCancelProbability;
	/**
	 * EN: Correction value for the estimation of the waitng time tolerance<br>
	 * DE: Korrekturterm bei der Sch�tzung der Wartezeittoleranz
	 */
	private double waitingTimeCalcAdd;

	/**
	 * EN: Retry interval distribution<br>
	 * DE: Wiederholabst�ndeverteilung
	 */
	public String retryTimeDist;

	/**
	 * EN: Retry rate after being blocked - first retry<br>
	 * DE: Wiederholrate nach "besetzt" - erster Versuch
	 */
	public double retryProbabiltyAfterBlockedFirstRetry;
	/**
	 * EN: Retry rate after being blocked - from the second retry on<br>
	 * DE: Wiederholrate nach "besetzt" - ab dem zweiten Versuch
	 */
	public double retryProbabiltyAfterBlocked;
	/**
	 * EN: Retry rate after waiting cancelation - first retry<br>
	 * DE: Wiederholrate nach Warteabbruch - erster Versuch
	 */
	public double retryProbabiltyAfterGiveUpFirstRetry;
	/**
	 * EN: Retry rate after waiting cancelation - from the second retry on<br>
	 * DE: Wiederholrate nach Warteabbruch - ab dem zweiten Versuch
	 */
	public double retryProbabiltyAfterGiveUp;

	/**
	 * EN: Client type change after begin blocked - first retry (new client type)<br>
	 * DE: Kundentypenwechsel nach "besetzt" - erster Versuch (neuer Kundentyp)
	 */
	public final List<String> retryCallerTypeAfterBlockedFirstRetry;
	/**
	 * EN: Client type change after begin blocked - first retry (change rate)<br>
	 * DE: Kundentypenwechsel nach "besetzt" - erster Versuch (Wechselrate)
	 */
	public final List<Double> retryCallerTypeRateAfterBlockedFirstRetry;
	/**
	 * EN: Client type change after begin blocked - from the second retry on (new client type)<br>
	 * DE: Kundentypenwechsel nach "besetzt" - ab dem zweiten Versuch (neuer Kundentyp)
	 */
	public final List<String> retryCallerTypeAfterBlocked;
	/**
	 * EN: Client type change after begin blocked - from the second retry on (change rate)<br>
	 * DE: Kundentypenwechsel nach "besetzt" - ab dem zweiten Versuch (Wechselrate)
	 */
	public final List<Double> retryCallerTypeRateAfterBlocked;
	/**
	 * EN: Client type change after waiting cancelation - first retry (new client type)<br>
	 * DE: Kundentypenwechsel nach Warteabbruch - erster Versuch (neuer Kundentyp)
	 */
	public final List<String> retryCallerTypeAfterGiveUpFirstRetry;
	/**
	 * EN: Client type change after waiting cancelation - first retry (change rate)<br>
	 * DE: Kundentypenwechsel nach Warteabbruch - erster Versuch (Wechselrate)
	 */
	public final List<Double> retryCallerTypeRateAfterGiveUpFirstRetry;
	/**
	 * EN: Client type change after waiting cancelation - from the second retry on (new client type)<br>
	 * DE: Kundentypenwechsel nach Warteabbruch - ab dem zweiten Versuch (neuer Kundentyp)
	 */
	public final List<String> retryCallerTypeAfterGiveUp;
	/**
	 * EN: Client type change after waiting cancelation - from the second retry on (change rate)<br>
	 * DE: Kundentypenwechsel nach Warteabbruch - ab dem zweiten Versuch (Wechselrate)
	 */
	public final List<Double> retryCallerTypeRateAfterGiveUp;

	/**
	 * EN: Forwarding probability<br>
	 * DE: Weiterleitungswahrscheinlichkeit
	 */
	public double continueProbability;

	/**
	 * EN: List of the names of possible new client types on forwarding<br>
	 * DE: Liste der Namen der m�glichen neuen Kundentypen bei einer Weiterleitung
	 */
	public final List<String> continueTypeName;
	/**
	 * EN: List of the rates as which the client type change on forwarding</br>
	 * DE: Liste der Raten, mit denen Weiterleitungen zu den bestimmten Kundentypen erfolgen
	 */
	public final List<Double> continueTypeRate;

	/**
	 * EN: Special forwarding options depending on the skill level of the agent who served the client<br>
	 * DE: Spezielle Weiterleitungsm�glichkeiten in Abh�ngigkeit vom Skill-Level des bedienenden Agenten */
	public final List<String> continueTypeSkillType;
	/**
	 * EN: Forwarding probabilities depending on the skill level of the agent who served the client<br>
	 * DE: Weiterleitungswahrscheinlichkeit in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<Double> continueTypeSkillTypeProbability;
	/**
	 * EN: List of the names of possible new client types on forwarding depending on the skill level of the agent who served the client<br>
	 * DE: Liste der Namen der m�glichen neuen Kundentypen bei einer Weiterleitung in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<List<String>> continueTypeSkillTypeName;
	/**
	 * EN: List of the rates as which the client type change on forwarding depending on the skill level of the agent who served the client</br>
	 * DE: Liste der Raten, mit denen Weiterleitungen zu den bestimmten Kundentypen erfolgen in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<List<Double>> continueTypeSkillTypeRate;

	/**
	 * EN: Recall probability<br>
	 * DE: Wiederanrufswahrscheinlichkeit
	 */
	public double recallProbability;

	/**
	 * EN: Recall interval distribution<br>
	 * DE: Wiederanrufsabst�ndeverteilung
	 */
	public String recallTimeDist;

	/**
	 * EN: List of the names of possible new client types on recalling<br>
	 * DE: Liste der Namen der m�glichen neuen Kundentypen bei einem Wiederanruf
	 */
	public final List<String> recallTypeName;
	/**
	 * EN: List of the rates as which the client type change on recalling</br>
	 * DE: Liste der Raten, mit bei einem Wiederanruf �nderungen des Typs zu den bestimmten Kundentypen erfolgen
	 */
	public final List<Double> recallTypeRate;

	/**
	 * EN: Special recalling options depending on the skill level of the agent who served the client<br>
	 * DE: Spezielle Wiederanrufsm�glichkeiten in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<String> recallTypeSkillType;
	/**
	 * EN: Recalling probabilities depending on the skill level of the agent who served the client<br>
	 * DE: Wiederanrufwahrscheinlichkeit in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<Double> recallTypeSkillTypeProbability;
	/**
	 * EN: List of the names of possible new client types on recalling depending on the skill level of the agent who served the client<br>
	 * DE: Liste der Namen der m�glichen neuen Kundentypen bei einem Wiederanruf in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<List<String>> recallTypeSkillTypeName;
	/**
	 * EN: List of the rates as which the client type change on recalling depending on the skill level of the agent who served the client</br>
	 * DE: Liste der Raten, mit denen sich der Typ bei einem Wiederanruf zu den bestimmten Kundentypen �ndert in Abh�ngigkeit vom Skill-Level des bedienenden Agenten
	 */
	public final List<List<Double>> recallTypeSkillTypeRate;

	/**
	 * EN: Yield per successful client<br>
	 * DE: Ertrag pro erfolgreich bedientem Kunden
	 */
	public double revenuePerClient;
	/**
	 * EN: Virtual cost per canceled call<br>
	 * DE: Virtuelle Kosten pro Warteabbruch
	 */
	public double costPerCancel;
	/**
	 * EN: Virtual cost per waiting second<br>
	 * DE: Virtuelle Kosten pro Wartesekunde
	 */
	public double costPerWaitingSec;

	/**
	 * EN: Constructor of the class <code>CallCenterModelCaller</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModelCaller</code>
	 * @param	name	<br>
	 * EN: Name of the client type (<code>null</code> will be interpreted as an empty string)<br>
	 * DE: Name der Kundengruppe (<code>null</code> wird als leerer String interpretiert)
	 */
	public CallCenterModelCaller(final String name) {
		this(name,true);
	}

	/**
	 * EN: Constructor of the class <code>CallCenterModelCaller</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModelCaller</code>
	 * @param	name	<br>
	 * EN: Name of the client type (<code>null</code> will be interpreted as an empty string)<br>
	 * DE: Name der Kundengruppe (<code>null</code> wird als leerer String interpretiert)
	 * @param	active	<br>
	 * EN: Is the new client type to be marked as active?<br>
	 * DE: Soll die Kundengruppe als aktiv gekennzeichnet werden?
	 */
	public CallCenterModelCaller(final String name, final boolean active) {
		if (name==null) this.name=""; else this.name=name;
		this.active=active;

		freshCallsCountMean=1;
		freshCallsCountSD=0;
		freshCallsDist=Distribution.getData(0,48);

		scoreBase=1;
		scoreSecond=0;
		scoreContinued=0;

		blocksLine=true;

		serviceLevelSeconds=-1;

		waitingTimeMode=WAITING_TIME_MODE_SHORT;
		waitingTimeDist=Language.get(Language.Distribution_LogNormal)+" (300;200)";
		waitingTimeDistLong=Language.get(Language.Distribution_Exp)+" (172800)";
		waitingTimeCalcMeanWaitingTime=15;
		waitingTimeCalcCancelProbability=0.05;
		waitingTimeCalcAdd=0;

		retryTimeDist=Language.get(Language.Distribution_Exp)+" (1200)";

		retryProbabiltyAfterBlockedFirstRetry=0.9;
		retryProbabiltyAfterBlocked=0.8;
		retryProbabiltyAfterGiveUpFirstRetry=0.9;
		retryProbabiltyAfterGiveUp=0.8;

		retryCallerTypeAfterBlockedFirstRetry=new ArrayList<String>();
		retryCallerTypeRateAfterBlockedFirstRetry=new ArrayList<Double>();
		retryCallerTypeAfterBlocked=new ArrayList<String>();
		retryCallerTypeRateAfterBlocked=new ArrayList<Double>();
		retryCallerTypeAfterGiveUpFirstRetry=new ArrayList<String>();
		retryCallerTypeRateAfterGiveUpFirstRetry=new ArrayList<Double>();
		retryCallerTypeAfterGiveUp=new ArrayList<String>();
		retryCallerTypeRateAfterGiveUp=new ArrayList<Double>();

		continueProbability=0;

		continueTypeName=new ArrayList<String>();
		continueTypeRate=new ArrayList<Double>();

		continueTypeSkillType=new ArrayList<String>();
		continueTypeSkillTypeProbability=new ArrayList<Double>();
		continueTypeSkillTypeName=new ArrayList<List<String>>();
		continueTypeSkillTypeRate=new ArrayList<List<Double>>();

		recallProbability=0;

		recallTimeDist=Language.get(Language.Distribution_Exp)+" (1200)";

		recallTypeName=new ArrayList<String>();
		recallTypeRate=new ArrayList<Double>();

		recallTypeSkillType=new ArrayList<String>();
		recallTypeSkillTypeProbability=new ArrayList<Double>();
		recallTypeSkillTypeName=new ArrayList<List<String>>();
		recallTypeSkillTypeRate=new ArrayList<List<Double>>();

		revenuePerClient=0;
		costPerCancel=0;
		costPerWaitingSec=0;
	}

	/**
	 * EN: Creates a copy of the client type
	 * DE: Erstellt eine Kopie des Kundentyps
	 * @param	name	<br>
	 * EN: Name of the new client type /If <code>null</code> is passed, the name of the original client type will be used.)<br>
	 * DE: Name der neuen Kundengruppe (Wird <code>null</code> �bergeben, so wird der Name der Ausgangskundengruppe verwendet.)
	 * @param	active	<br>
	 * EN: If the new client type to be marked as avtive?<br>
	 * DE: Soll die Kundengruppe als aktiv gekennzeichnet werden?
	 * @return
	 * EN: New client type object<br>
	 * DE: Neues Kundentyp-Objekt
	 */
	public final CallCenterModelCaller clone(final String Name, final boolean active) {
		CallCenterModelCaller caller=new CallCenterModelCaller(Name,active);
		if (name==null) caller.name=this.name;

		caller.freshCallsCountMean=freshCallsCountMean;
		caller.freshCallsCountSD=freshCallsCountSD;
		caller.freshCallsDist=freshCallsDist;

		caller.scoreBase=scoreBase;
		caller.scoreSecond=scoreSecond;
		caller.scoreContinued=scoreContinued;

		caller.blocksLine=blocksLine;

		caller.serviceLevelSeconds=serviceLevelSeconds;

		caller.waitingTimeMode=waitingTimeMode;
		caller.waitingTimeDist=waitingTimeDist;
		caller.waitingTimeDistLong=waitingTimeDistLong;
		caller.waitingTimeCalcMeanWaitingTime=waitingTimeCalcMeanWaitingTime;
		caller.waitingTimeCalcCancelProbability=waitingTimeCalcCancelProbability;
		caller.waitingTimeCalcAdd=waitingTimeCalcAdd;

		caller.retryTimeDist=retryTimeDist;

		caller.retryProbabiltyAfterBlockedFirstRetry=retryProbabiltyAfterBlockedFirstRetry;
		caller.retryProbabiltyAfterBlocked=retryProbabiltyAfterBlocked;
		caller.retryProbabiltyAfterGiveUpFirstRetry=retryProbabiltyAfterGiveUpFirstRetry;
		caller.retryProbabiltyAfterGiveUp=retryProbabiltyAfterGiveUp;

		caller.retryCallerTypeAfterBlockedFirstRetry.addAll(retryCallerTypeAfterBlockedFirstRetry);
		caller.retryCallerTypeRateAfterBlockedFirstRetry.addAll(retryCallerTypeRateAfterBlockedFirstRetry);
		caller.retryCallerTypeAfterBlocked.addAll(retryCallerTypeAfterBlocked);
		caller.retryCallerTypeRateAfterBlocked.addAll(retryCallerTypeRateAfterBlocked);
		caller.retryCallerTypeAfterGiveUpFirstRetry.addAll(retryCallerTypeAfterGiveUpFirstRetry);
		caller.retryCallerTypeRateAfterGiveUpFirstRetry.addAll(retryCallerTypeRateAfterGiveUpFirstRetry);
		caller.retryCallerTypeAfterGiveUp.addAll(retryCallerTypeAfterGiveUp);
		caller.retryCallerTypeRateAfterGiveUp.addAll(retryCallerTypeRateAfterGiveUp);

		caller.continueProbability=continueProbability;

		caller.continueTypeName.addAll(continueTypeName);
		caller.continueTypeRate.addAll(continueTypeRate);

		caller.continueTypeSkillType.addAll(continueTypeSkillType);
		caller.continueTypeSkillTypeProbability.addAll(continueTypeSkillTypeProbability);
		caller.continueTypeSkillTypeName.addAll(continueTypeSkillTypeName);
		caller.continueTypeSkillTypeRate.addAll(continueTypeSkillTypeRate);

		caller.recallProbability=recallProbability;

		caller.recallTimeDist=recallTimeDist;

		caller.recallTypeName.addAll(recallTypeName);
		caller.recallTypeRate.addAll(recallTypeRate);

		caller.recallTypeSkillType.addAll(recallTypeSkillType);
		caller.recallTypeSkillTypeProbability.addAll(recallTypeSkillTypeProbability);
		caller.recallTypeSkillTypeName.addAll(recallTypeSkillTypeName);
		caller.recallTypeSkillTypeRate.addAll(recallTypeSkillTypeRate);

		caller.revenuePerClient=revenuePerClient;
		caller.costPerCancel=costPerCancel;
		caller.costPerWaitingSec=costPerWaitingSec;

		return caller;
	}

	/**
	 * EN: Creates a copy of the client type
	 * DE: Erstellt eine Kopie des Kundentyps
	 * @return
	 * EN: New client type object<br>
	 * DE: Neues Kundentyp-Objekt
	 */
	@Override
	public Object clone() {
		return clone(null,active);
	}

	/**
	 * EN: Sets that the clients of this type are willing to wait as long as desired.<br>
	 * DE: Stellt ein, dass die Kunden dieses Typs bereit sind, beliebig lange zu warten.
	 */
	public final void setWaitingTimeInfinite() {
		waitingTimeMode=WAITING_TIME_MODE_OFF;
	}

	/**
	 * EN: Sets that the waiting time tolerance of the clients of this typs is in the range of 0..3600 seconds.<br>
	 * DE: Stellt ein, dass die Wartezeittoleranz der Kunden im Bereich 0..3600 Sekunden liegt.
	 * @param waitingTimeDist	<br>
	 * EN: Distribution of the waiting time tolerance<br>
	 * DE: Verteilung der Wartezeittoleranz
	 */
	public final void setWaitingTimeShort(final String waitingTimeDist) {
		waitingTimeMode=WAITING_TIME_MODE_SHORT;
		this.waitingTimeDist=waitingTimeDist;
	}

	/**
	 * EN: Sets that the waiting time tolerance of the clients of this typs is in the range of 0..10 days.<br>
	 * DE: Stellt ein, dass die Wartezeittoleranz der Kunden im Bereich 0..10 Tage liegt.
	 * @param waitingTimeDist	<br>
	 * EN: Distribution of the waiting time tolerance<br>
	 * DE: Verteilung der Wartezeittoleranz
	 */
	public final void setWaitingTimeLong(final String waitingTimeDistLong) {
		waitingTimeMode=WAITING_TIME_MODE_LONG;
		this.waitingTimeDistLong=waitingTimeDistLong;
	}

	/**
	 * EN: Sets that the waiting time tolerance is to be estimated from the measured waiting time and cancelation rate.<br>
	 * DE: Gibt an, dass die Wartezeittoleranz aus gemessener Wartezeit und Abbrecheranzahl hochgerechnet werden soll.
	 * @param meanWaitingTime	<br>
	 * EN: Measured mean waiting time.<br>
	 * DE: Gemessene mittlere Wartezeit.
	 * @param cancelProbability	<br>
	 * EN: Measured cancelation rate.<br>
	 * DE: Gemessene Abbruchrate.
	 * @param timeAdd
	 * EN: Correction value in seconds for the estimated waiting time tolerance.<br>
	 * DE: Zeit in Sekunden, um die die gesch�tzte Wartezeittolerenz korrigiert werden soll.
	 */
	public final void setWaitingTimeCalc(final double meanWaitingTime, final double cancelProbability, final double timeAdd) {
		waitingTimeMode=WAITING_TIME_MODE_CALC;
		waitingTimeCalcMeanWaitingTime=meanWaitingTime;
		waitingTimeCalcCancelProbability=cancelProbability;
		waitingTimeCalcAdd=timeAdd;
	}

	/**
	 * EN: Create an XML child node to the given parent node and will store all client data in this child node.<br>
	 * DE: Erstellt unterhalb des �bergebenen XML-Knotens einen neuen Knoten, der die gesamten Kundentyp-Daten enth�lt.
	 * @param parent	<br>
	 * EN: Parent XML node<br>
	 * DE: Eltern-XML-Knoten
	 */
	final void saveToXML(final Element parent) {
		Document doc=parent.getOwnerDocument();
		Element node=doc.createElement(Language.get(Language.Model_ClientType)); parent.appendChild(node);
		if (!active) node.setAttribute(Language.get(Language.Model_General_Attribute_Active),"0");
		node.setAttribute(Language.get(Language.Model_General_Attribute_Name),name);
		if (!blocksLine) node.setAttribute(Language.get(Language.Model_ClientType_BlocksLine),"0");
		if (serviceLevelSeconds>0) node.setAttribute(Language.get(Language.Model_ClientType_ServiceLevel),""+serviceLevelSeconds);

		Element e,e2,e3;

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_FreshCalls)));
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_FreshCallsCount))); e2.setTextContent(""+freshCallsCountMean);
		if (freshCallsCountSD>0) e2.setAttribute(Language.get(Language.Model_ClientType_FreshCallsStandardDeviation),Numbers.formatSystemNumber(freshCallsCountSD));
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_FreshCallsDistribution))); e2.setTextContent(freshCallsDist);

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_ClientsScore)));
		e.setAttribute(Language.get(Language.Model_ClientType_ClientsScore_Base),Numbers.formatSystemNumber(scoreBase));
		e.setAttribute(Language.get(Language.Model_ClientType_ClientsScore_PerWaitingSecond),Numbers.formatSystemNumber(scoreSecond));
		e.setAttribute(Language.get(Language.Model_ClientType_ClientsScore_Forwarding),Numbers.formatSystemNumber(scoreContinued));

		switch (waitingTimeMode) {
		case WAITING_TIME_MODE_SHORT:
			node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Short)));
			e.setTextContent(waitingTimeDist);
			break;
		case WAITING_TIME_MODE_LONG:
			node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Long)));
			e.setTextContent(waitingTimeDistLong);
			break;
		case WAITING_TIME_MODE_CALC:
			node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation)));
			e.setAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime),Numbers.formatExactSystemTime(waitingTimeCalcMeanWaitingTime));
			e.setAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate),Numbers.formatSystemNumber(waitingTimeCalcCancelProbability*100)+"%");
			e.setAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue),Numbers.formatExactSystemTime(waitingTimeCalcAdd));
			break;
		}

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_Retry)));
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_Interval))); e2.setTextContent(retryTimeDist);
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_BlockedFirst))); e2.setTextContent(Numbers.formatSystemNumber(retryProbabiltyAfterBlockedFirstRetry*100)+"%");
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_BlockedSecond))); e2.setTextContent(Numbers.formatSystemNumber(retryProbabiltyAfterBlocked*100)+"%");
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_WaitingFirst))); e2.setTextContent(Numbers.formatSystemNumber(retryProbabiltyAfterGiveUpFirstRetry*100)+"%");
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_WaitingSecond))); e2.setTextContent(Numbers.formatSystemNumber(retryProbabiltyAfterGiveUp*100)+"%");

		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_BlockedFirst_ClientType)));
		for (int i=0;i<Math.min(retryCallerTypeAfterBlockedFirstRetry.size(),retryCallerTypeRateAfterBlockedFirstRetry.size());i++) {
			if (retryCallerTypeAfterBlockedFirstRetry.get(i)==null || retryCallerTypeRateAfterBlockedFirstRetry.get(i)==null) continue;
			e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Retry_NewClientType)));
			e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),retryCallerTypeAfterBlockedFirstRetry.get(i));
			e3.setTextContent(Numbers.formatSystemNumber(retryCallerTypeRateAfterBlockedFirstRetry.get(i)));
		}
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_BlockedSecond_ClientType)));
		for (int i=0;i<Math.min(retryCallerTypeAfterBlocked.size(),retryCallerTypeRateAfterBlocked.size());i++) {
			if (retryCallerTypeAfterBlocked.get(i)==null || retryCallerTypeRateAfterBlocked.get(i)==null) continue;
			e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Retry_NewClientType)));
			e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),retryCallerTypeAfterBlocked.get(i));
			e3.setTextContent(Numbers.formatSystemNumber(retryCallerTypeRateAfterBlocked.get(i)));
		}
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_WaitingFirst_ClientType)));
		for (int i=0;i<Math.min(retryCallerTypeAfterGiveUpFirstRetry.size(),retryCallerTypeRateAfterGiveUpFirstRetry.size());i++) {
			if (retryCallerTypeAfterGiveUpFirstRetry.get(i)==null || retryCallerTypeRateAfterGiveUpFirstRetry.get(i)==null) continue;
			e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Retry_NewClientType)));
			e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),retryCallerTypeAfterGiveUpFirstRetry.get(i));
			e3.setTextContent(Numbers.formatSystemNumber(retryCallerTypeRateAfterGiveUpFirstRetry.get(i)));
		}
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Retry_WaitingSecond_ClientType)));
		for (int i=0;i<Math.min(retryCallerTypeAfterGiveUp.size(),retryCallerTypeRateAfterGiveUp.size());i++) {
			if (retryCallerTypeAfterGiveUp.get(i)==null || retryCallerTypeRateAfterGiveUp.get(i)==null) continue;
			e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Retry_NewClientType)));
			e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),retryCallerTypeAfterGiveUp.get(i));
			e3.setTextContent(Numbers.formatSystemNumber(retryCallerTypeRateAfterGiveUp.get(i)));
		}

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_Forwarding)));
		e.setAttribute(Language.get(Language.Model_General_Attribute_Probability),Numbers.formatSystemNumber(continueProbability*100)+"%");
		for (int i=0;i<Math.min(continueTypeName.size(),continueTypeRate.size());i++) {
			if (continueTypeName.get(i)==null || continueTypeRate.get(i)==null) continue;
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Forwarding_NewClientType)));
			e2.setAttribute(Language.get(Language.Model_General_Attribute_Name),continueTypeName.get(i));
			e2.setTextContent(Numbers.formatSystemNumber(continueTypeRate.get(i)));
		}
		for (int i=0;i<Math.min(Math.min(Math.min(continueTypeSkillType.size(),continueTypeSkillTypeProbability.size()),continueTypeSkillTypeName.size()),continueTypeSkillTypeRate.size());i++) {
			if (continueTypeSkillType.get(i)==null || continueTypeSkillTypeProbability.get(i)==null || continueTypeSkillTypeName.get(i)==null || continueTypeSkillTypeRate.get(i)==null) continue;
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Forwarding_Special)));
			e2.setAttribute(Language.get(Language.Model_ClientType_Forwarding_Special_SkillLevel),continueTypeSkillType.get(i));
			e2.setAttribute(Language.get(Language.Model_General_Attribute_Probability),Numbers.formatSystemNumber(continueTypeSkillTypeProbability.get(i)*100)+"%");
			List<String> names=continueTypeSkillTypeName.get(i);
			List<Double> rates=continueTypeSkillTypeRate.get(i);
			for (int j=0;j<Math.min(names.size(),rates.size());j++) {
				if (names.get(j)==null || rates.get(j)==null) continue;
				e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Forwarding_Special_NewClientType)));
				e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),names.get(j));
				e3.setTextContent(Numbers.formatSystemNumber(rates.get(j)));
			}
		}

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_Recall)));
		e.setAttribute(Language.get(Language.Model_General_Attribute_Probability),Numbers.formatSystemNumber(recallProbability*100)+"%");
		e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Recall_Interval))); e2.setTextContent(recallTimeDist);
		for (int i=0;i<Math.min(recallTypeName.size(),recallTypeRate.size());i++) {
			if (recallTypeName.get(i)==null || recallTypeRate.get(i)==null) continue;
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Recall_NewClientType)));
			e2.setAttribute(Language.get(Language.Model_General_Attribute_Name),recallTypeName.get(i));
			e2.setTextContent(Numbers.formatSystemNumber(recallTypeRate.get(i)));
		}
		for (int i=0;i<Math.min(Math.min(Math.min(recallTypeSkillType.size(),recallTypeSkillTypeProbability.size()),recallTypeSkillTypeName.size()),recallTypeSkillTypeRate.size());i++) {
			if (recallTypeSkillType.get(i)==null || recallTypeSkillTypeProbability.get(i)==null || recallTypeSkillTypeName.get(i)==null || recallTypeSkillTypeRate.get(i)==null) continue;
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_ClientType_Recall_Special)));
			e2.setAttribute(Language.get(Language.Model_ClientType_Recall_Special_SkillLevel),recallTypeSkillType.get(i));
			e2.setAttribute(Language.get(Language.Model_General_Attribute_Probability),Numbers.formatSystemNumber(recallTypeSkillTypeProbability.get(i)*100)+"%");
			List<String> names=recallTypeSkillTypeName.get(i);
			List<Double> rates=recallTypeSkillTypeRate.get(i);
			for (int j=0;j<Math.min(names.size(),rates.size());j++) {
				if (names.get(j)==null || rates.get(j)==null) continue;
				e2.appendChild(e3=doc.createElement(Language.get(Language.Model_ClientType_Recall_Special_NewClientType)));
				e3.setAttribute(Language.get(Language.Model_General_Attribute_Name),names.get(j));
				e3.setTextContent(Numbers.formatSystemNumber(rates.get(j)));
			}
		}

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_Yield)));
		e.setTextContent(Numbers.formatSystemNumber(revenuePerClient));

		node.appendChild(e=doc.createElement(Language.get(Language.Model_ClientType_Costs)));
		e.setAttribute(Language.get(Language.Model_ClientType_Costs_Cancel),Numbers.formatSystemNumber(costPerCancel));
		e.setAttribute(Language.get(Language.Model_ClientType_Costs_Waiting),Numbers.formatSystemNumber(costPerWaitingSec));
	}

	private final String loadRetryCallerTypChaneData(final Element node, final List<String> names, final List<Double> rates) {
		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			if (!e.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_NewClientType))) continue;
			Double D=Numbers.getNotNegativeSystemDouble(e.getTextContent());
			if (D==null) return String.format(Language.get(Language.Model_ClientType_Retry_NewClientType_Error),e.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
			names.add(e.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
			rates.add(D);
		}
		return null;
	}

	/**
	 * EN: Trys to load a client type from the given XML node<br>
	 * DE: Versucht einen Kundentyp aus dem �bergebenen XML-Node zu laden
	 * @param node	<br>
	 * EN: XML node containing the client type data<br>
	 * DE: XML-Knoten, der die Kundentyp-Daten enth�lt
	 * @return
	 * EN: If an error occurs, the error message is returned. In case of success <code>null</code> is returned.<br>
	 * DE: Tritt ein Fehler auf, so wird die Fehlermeldung als String zur�ckgegeben. Im Erfolgsfall wird <code>null</code> zur�ckgegeben.
	 */
	final String loadFromXML(final Element node) {
		active=true;
		blocksLine=true;
		serviceLevelSeconds=-1;

		name=node.getAttribute(Language.get(Language.Model_General_Attribute_Name));

		String a=node.getAttribute(Language.get(Language.Model_General_Attribute_Active));
		if (a!=null && (a.equals("0") || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_False)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_Off)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_No)))) active=false;

		a=node.getAttribute(Language.get(Language.Model_ClientType_BlocksLine));
		if (a!=null && (a.equals("0") || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_False)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_Off)) || a.equalsIgnoreCase(Language.get(Language.Model_General_Bool_No)))) blocksLine=false;

		a=node.getAttribute(Language.get(Language.Model_ClientType_ServiceLevel));
		if (a!=null && !a.isEmpty())  {
			Integer I=Numbers.getInteger(a);
			if (I==null || I<=0) return Language.get(Language.Model_ClientType_ServiceLevel_Error);
			serviceLevelSeconds=I;
		}

		freshCallsCountMean=1;
		freshCallsCountSD=0;
		freshCallsDist=Distribution.getData(0,48);
		scoreBase=1;
		scoreSecond=0;
		scoreContinued=0;
		waitingTimeMode=WAITING_TIME_MODE_OFF; /* En: No impatience, if there is no waiting time tolerance XML node. DE: Keine Ungeduld, falls kein XML-Node dazu existiert. */
		waitingTimeDist=Language.get(Language.Distribution_LogNormal)+" (300;200)";
		waitingTimeDistLong=Language.get(Language.Distribution_Exp)+" (172800)";
		waitingTimeCalcMeanWaitingTime=15;
		waitingTimeCalcCancelProbability=0.05;
		waitingTimeCalcAdd=0;
		retryTimeDist=Language.get(Language.Distribution_Exp)+" (1200)";
		retryProbabiltyAfterBlockedFirstRetry=0.9;
		retryProbabiltyAfterBlocked=0.8;
		retryProbabiltyAfterGiveUpFirstRetry=0.9;
		retryProbabiltyAfterGiveUp=0.8;
		retryCallerTypeAfterBlockedFirstRetry.clear();
		retryCallerTypeRateAfterBlockedFirstRetry.clear();
		retryCallerTypeAfterBlocked.clear();
		retryCallerTypeRateAfterBlocked.clear();
		retryCallerTypeAfterGiveUpFirstRetry.clear();
		retryCallerTypeRateAfterGiveUpFirstRetry.clear();
		retryCallerTypeAfterGiveUp.clear();
		retryCallerTypeRateAfterGiveUp.clear();
		continueProbability=0.2;
		continueTypeName.clear();
		continueTypeRate.clear();
		continueTypeSkillType.clear();
		continueTypeSkillTypeProbability.clear();
		continueTypeSkillTypeName.clear();
		continueTypeSkillTypeRate.clear();
		recallProbability=0;
		recallTimeDist=Language.get(Language.Distribution_Exp)+" (1200)";
		recallTypeName.clear();
		recallTypeRate.clear();
		recallTypeSkillType.clear();
		recallTypeSkillTypeProbability.clear();
		recallTypeSkillTypeName.clear();
		recallTypeSkillTypeRate.clear();
		revenuePerClient=0;
		costPerCancel=0;
		costPerWaitingSec=0;

		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			String s=e.getNodeName();

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_FreshCalls))) {
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);
					String t=e2.getNodeName();

					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_FreshCallsCount))) {
						Integer K=Numbers.getNotNegativeInteger(e2.getTextContent());
						if (K==null) return Language.get(Language.Model_ClientType_FreshCallsCount_Error);
						freshCallsCountMean=K;

						String u=e2.getAttribute(Language.get(Language.Model_ClientType_FreshCallsStandardDeviation));
						if (!u.isEmpty()) {
							Double L=Numbers.getNotNegativeSystemDouble(u);
							if (L==null) return Language.get(Language.Model_ClientType_FreshCallsStandardDeviation_Error);
							freshCallsCountSD=L;
						}

						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_FreshCallsDistribution))) {
						freshCallsDist=e2.getTextContent();
						if (freshCallsDist==null) return Language.get(Language.Model_ClientType_FreshCallsDistribution_Error);
						continue;
					}
				}
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_ClientsScore))) {
				String u;
				u=e.getAttribute(Language.get(Language.Model_ClientType_ClientsScore_Base)); if (!u.isEmpty()) {
					Integer K=Numbers.getNotNegativeInteger(u);
					if (K==null) return Language.get(Language.Model_ClientType_ClientsScore_Base_Error); else scoreBase=K;
				}
				u=e.getAttribute(Language.get(Language.Model_ClientType_ClientsScore_PerWaitingSecond)); if (!u.isEmpty()) {
					Integer K=Numbers.getNotNegativeInteger(u);
					if (K==null) return Language.get(Language.Model_ClientType_ClientsScore_PerWaitingSecond_Error); else scoreSecond=K;
				}
				u=e.getAttribute(Language.get(Language.Model_ClientType_ClientsScore_Forwarding)); if (!u.isEmpty()) {
					Integer K=Numbers.getNotNegativeInteger(u);
					if (K==null) return Language.get(Language.Model_ClientType_ClientsScore_Forwarding_Error); else scoreContinued=K;
				}
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Short))) {
				waitingTimeMode=WAITING_TIME_MODE_SHORT;
				waitingTimeDist=e.getTextContent();
				if (waitingTimeDist==null) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Short_Error);
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Long))) {
				waitingTimeMode=WAITING_TIME_MODE_LONG;
				waitingTimeDistLong=e.getTextContent();
				if (waitingTimeDistLong==null) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Long_Error);
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation))) {
				waitingTimeMode=WAITING_TIME_MODE_CALC;
				String t=e.getAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime)); if (t==null || t.isEmpty()) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime_Missing);
				Double d=Numbers.getExactTime(t); if (d==null || d<0) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_WaitingTime_Error);
				waitingTimeCalcMeanWaitingTime=d;
				t=e.getAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate)); if (t==null || t.isEmpty()) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Missing);
				d=Numbers.getSystemProbability(t); if (d==null) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Error);
				waitingTimeCalcCancelProbability=d;
				t=e.getAttribute(Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue)); if (t==null || t.isEmpty()) waitingTimeCalcAdd=0; {
					d=Numbers.getExactTime(t); if (d==null) return Language.get(Language.Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue_Error);
					waitingTimeCalcAdd=d;
				}
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry))) {
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);
					String t=e2.getNodeName();

					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_Interval))) {
						retryTimeDist=e2.getTextContent();
						if (retryTimeDist==null) return Language.get(Language.Model_ClientType_Retry_Interval_Error);
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_BlockedFirst))) {
						Double D=Numbers.getSystemProbability(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_ClientType_Retry_BlockedFirst_Error);
						retryProbabiltyAfterBlockedFirstRetry=D;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_BlockedSecond))) {
						Double D=Numbers.getSystemProbability(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_ClientType_Retry_BlockedSecond_Error);
						retryProbabiltyAfterBlocked=D;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_WaitingFirst))) {
						Double D=Numbers.getSystemProbability(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_ClientType_Retry_WaitingFirst_Error);
						retryProbabiltyAfterGiveUpFirstRetry=D;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_WaitingSecond))) {
						Double D=Numbers.getSystemProbability(e2.getTextContent());
						if (D==null) return Language.get(Language.Model_ClientType_Retry_WaitingSecond_Error);
						retryProbabiltyAfterGiveUp=D;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_BlockedFirst_ClientType))) {
						String u=loadRetryCallerTypChaneData(e2,retryCallerTypeAfterBlockedFirstRetry,retryCallerTypeRateAfterBlockedFirstRetry);
						if (u!=null) return s;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_BlockedSecond_ClientType))) {
						String u=loadRetryCallerTypChaneData(e2,retryCallerTypeAfterBlocked,retryCallerTypeRateAfterBlocked);
						if (u!=null) return s;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_WaitingFirst_ClientType))) {
						String u=loadRetryCallerTypChaneData(e2,retryCallerTypeAfterGiveUpFirstRetry,retryCallerTypeRateAfterGiveUpFirstRetry);
						if (u!=null) return s;
						continue;
					}
					if (t.equalsIgnoreCase(Language.get(Language.Model_ClientType_Retry_WaitingSecond_ClientType))) {
						String u=loadRetryCallerTypChaneData(e2,retryCallerTypeAfterGiveUp,retryCallerTypeRateAfterGiveUp);
						if (u!=null) return s;
						continue;
					}
				}
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_Forwarding))) {
				String u=e.getAttribute(Language.get(Language.Model_General_Attribute_Probability));
				if (!u.isEmpty()) {
					Double D=Numbers.getSystemProbability(u);
					if (D==null) return Language.get(Language.Model_ClientType_Forwarding_Error); else continueProbability=D;
				}
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);

					if (e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Forwarding_NewClientType))) {
						Double D=Numbers.getNotNegativeSystemDouble(e2.getTextContent());
						if (D==null) return String.format(Language.get(Language.Model_ClientType_Forwarding_NewClientType_Error),e2.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
						continueTypeName.add(e2.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
						continueTypeRate.add(D);
						continue;
					}

					if (e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Forwarding_Special))) {
						u=e2.getAttribute(Language.get(Language.Model_ClientType_Forwarding_Special_SkillLevel)); if (u.isEmpty()) continue;
						continueTypeSkillType.add(u);

						u=e2.getAttribute(Language.get(Language.Model_General_Attribute_Probability));
						if (!u.isEmpty()) {
							Double D=Numbers.getSystemProbability(u);
							if (D==null) return Language.get(Language.Model_ClientType_Forwarding_Special_Error); else continueTypeSkillTypeProbability.add(D);
						}

						List<String> names=new ArrayList<String>(); continueTypeSkillTypeName.add(names);
						List<Double> rates=new ArrayList<Double>(); continueTypeSkillTypeRate.add(rates);
						NodeList l3=e2.getChildNodes();
						for (int k=0; k<l3.getLength();k++) {
							if (!(l3.item(k) instanceof Element)) continue;
							Element e3=(Element)l3.item(k);
							if (!e3.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Forwarding_Special_NewClientType))) continue;
							Double D=Numbers.getNotNegativeSystemDouble(e3.getTextContent());
							if (D==null) return String.format(Language.get(Language.Model_ClientType_Forwarding_Special_NewClientType_Error),e3.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
							names.add(e3.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
							rates.add(D);
							continue;
						}
						continue;
					}
				}
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_Recall))) {
				String u=e.getAttribute(Language.get(Language.Model_General_Attribute_Probability));
				if (!u.isEmpty()) {
					Double D=Numbers.getSystemProbability(u);
					if (D==null) return Language.get(Language.Model_ClientType_Recall_Error); else recallProbability=D;
				}
				NodeList l2=e.getChildNodes();
				for (int j=0; j<l2.getLength();j++) {
					if (!(l2.item(j) instanceof Element)) continue;
					Element e2=(Element)l2.item(j);

					if (e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Recall_Interval))) {
						recallTimeDist=e2.getTextContent();
						if (recallTimeDist==null) return Language.get(Language.Model_ClientType_Recall_Interval_Error);
						continue;
					}

					if (e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Recall_NewClientType))) {
						Double D=Numbers.getNotNegativeSystemDouble(e2.getTextContent());
						if (D==null) return String.format(Language.get(Language.Model_ClientType_Recall_NewClientType_Error),e2.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
						recallTypeName.add(e2.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
						recallTypeRate.add(D);
						continue;
					}

					if (e2.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Recall_Special))) {
						u=e2.getAttribute(Language.get(Language.Model_ClientType_Recall_Special_SkillLevel)); if (u.isEmpty()) continue;
						recallTypeSkillType.add(u);

						u=e2.getAttribute(Language.get(Language.Model_General_Attribute_Probability));
						if (!u.isEmpty()) {
							Double D=Numbers.getSystemProbability(u);
							if (D==null) return Language.get(Language.Model_ClientType_Recall_Special_Error); else recallTypeSkillTypeProbability.add(D);
						}

						List<String> names=new ArrayList<String>(); recallTypeSkillTypeName.add(names);
						List<Double> rates=new ArrayList<Double>(); recallTypeSkillTypeRate.add(rates);
						NodeList l3=e2.getChildNodes();
						for (int k=0; k<l3.getLength();k++) {
							if (!(l3.item(k) instanceof Element)) continue;
							Element e3=(Element)l3.item(k);
							if (!e3.getNodeName().equalsIgnoreCase(Language.get(Language.Model_ClientType_Recall_Special_NewClientType))) continue;
							Double D=Numbers.getNotNegativeSystemDouble(e3.getTextContent());
							if (D==null) return String.format(Language.get(Language.Model_ClientType_Recall_Special_NewClientType_Error),e3.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
							names.add(e3.getAttribute(Language.get(Language.Model_General_Attribute_Name)));
							rates.add(D);
							continue;
						}
						continue;
					}
				}
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_Yield))) {
				Double D=Numbers.getNotNegativeSystemDouble(e.getTextContent());
				if (D==null) return Language.get(Language.Model_ClientType_Yield_Error);
				revenuePerClient=D;
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType_Costs))) {
				Double D=Numbers.getNotNegativeSystemDouble(e.getAttribute(Language.get(Language.Model_ClientType_Costs_Cancel)));
				if (D==null) return Language.get(Language.Model_ClientType_Costs_Cancel_Error);
				costPerCancel=D;
				D=Numbers.getNotNegativeSystemDouble(e.getAttribute(Language.get(Language.Model_ClientType_Costs_Waiting)));
				if (D==null) return Language.get(Language.Model_ClientType_Costs_Waiting_Error);
				costPerWaitingSec=D;
				continue;
			}
		}
		return null;
	}
}