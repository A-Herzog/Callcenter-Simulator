package CallcenterDataModel;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import CallcenterDataModel.Tools.Distribution;
import CallcenterDataModel.Tools.Language;
import CallcenterDataModel.Tools.Numbers;
import CallcenterDataModel.Tools.XML;

/**
 * EN: Encapsulates the XML data of a call center<br>
 * DE: Kapselt die XML-Daten eines Callcenter-Modells
 * @author Alexander Herzog
 */
public final class CallCenterModel implements Cloneable {
	/**
	 * EN: Model name<br>
	 * DE: Modellname
	 */
	public String name;

	/**
	 * EN: Version of the simulator to be written in the XML file. (Can be <code>null</code>, in this case no version number is written.)<br>
	 * DE: Simulatorversion, die in die XML-Datei geschrieben wird. (Kann <code>null</code> sein, dann wird keine Versionsangabe geschrieben.)
	 */
	public String simulatorVersion=null;

	/**
	 * EN: Description of the model<br>
	 * DE: Modellbeschreibung
	 */
	public String description;

	/**
	 * EN: Date of the day the model stands for. (Can be <code>null</code>, in this case no model date is written.)<br>
	 * DE: Datum des Tages, f�r den das Modell stehen soll. (Kann <code>null</code> sein, dann wird kein Modelldatum geschrieben.)
	 */
	public String date=null;

	/**
	 * EN: Client types<br>
	 * DE: Kundentypen
	 */
	private final List<CallCenterModelCaller> caller;

	/**
	 * EN: Call centers<br>
	 * DE: Callcenter
	 */
	private final List<CallCenterModelCallCenter> callcenter;

	/**
	 * EN: Skill levels<br>
	 * DE: Skill-Level
	 */
	private final List<CallCenterModelSkillLevel> skillLevel;

	/**
	 * EN: Maximum queue length (If there are no free places in the queue, new callers will get a busy sign.)<br>
	 * DE: Maximale Warteschlangenl�nge (Ist die Warteschlange voll, erhalten Anrufer das Besetztzeichen.)
	 */
	public String maxQueueLength;

	/**
	 * EN: Number of days to be simulated<br>
	 * DE: Anzahl der zu simulierenden Tage
	 */
	public int days;

	/**
	 * EN: Preferred shift length (in half-hour intervals), if the agents are planned from distributions.<br>
	 * DE: Bevorzugte Schichtl�nge (in Halbstundenintervallen), wenn die Agenten aus Verteilungen aufgebaut werden.
	 */
	public int preferredShiftLength;

	/**
	 * EN: Number of seconds to be used for the service level<br>
	 * DE: Zu verwendende Anzahl an Sekunden f�r den Service-Level
	 */
	public int serviceLevelSeconds;

	/**
	 * EN: Productivity<bt>
	 * DE: Produktivit�t
	 */
	public String efficiency;

	/**
	 * EN: Disease-related surcharge<bt>
	 * DE: Krankheitsbedingter Zuschlag
	 */
	public String surcharge;

	/**
	 * EN: Constructor of the class <code>CallCenterModel</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModel</code>
	 * @param	name	<br>
	 * EN: Name of the model (<code>null</code> will be interpreted as an empty string)<br>
	 * DE: Name des Modells (<code>null</code> wird als leerer String interpretiert)
	 */
	public CallCenterModel(final String name) {
		caller=new ArrayList<CallCenterModelCaller>();
		callcenter=new ArrayList<CallCenterModelCallCenter>();
		skillLevel=new ArrayList<CallCenterModelSkillLevel>();
		clear(name);
	}

	/**
	 * EN: Create a copy of the call center modell<br>
	 * DE: Erstellt eine Kopie des Callcenter-Modells
	 * @param	name	<br>
	 * EN: Name of the new model (If <code>null</code> is given, the name of the original model will be used.)<br>
	 * DE: Name des neuen Modells (Wird <code>null</code> �bergeben, so wird der Name des Ausgangsmodells verwendet.)
	 * @return
	 * EN: New call center model object<br>
	 * DE: Neues Callcenter-Modell-Objekt
	 */
	public final CallCenterModel clone(final String name) {
		CallCenterModel model=new CallCenterModel(name);
		if (name==null) model.name=this.name;

		model.description=description;
		model.date=date;
		model.simulatorVersion=simulatorVersion;
		model.maxQueueLength=maxQueueLength;
		model.days=days;
		model.preferredShiftLength=preferredShiftLength;
		model.serviceLevelSeconds=serviceLevelSeconds;
		model.efficiency=efficiency;
		model.surcharge=surcharge;

		for (CallCenterModelCaller c : caller) model.caller.add(c.clone(c.name,c.active));
		for (CallCenterModelCallCenter c : callcenter) model.callcenter.add(c.clone(c.name,c.active));
		for (CallCenterModelSkillLevel s : skillLevel) model.skillLevel.add(s.clone(s.name));

		return model;
	}

	/**
	 * EN: Create a copy of the call center modell<br>
	 * DE: Erstellt eine Kopie des Callcenter-Modells
	 * @return
	 * EN: New call center model object<br>
	 * DE: Neues Callcenter-Modell-Objekt
	 */
	@Override
	public Object clone() {
		return clone(null);
	}

	/**
	 * EN: Resets the model<br>
	 * DE: Setzt das Modell zur�ck
	 * @param	name	<br>
	 * EN: Name of the model (<code>null</code> will be interpreted as an empty string)<br>
	 * DE: Name des Modells (<code>null</code> wird als leerer String interpretiert)
	 */
	private void clear(final String name) {
		if (name==null) this.name=""; else this.name=name;
		description="";
		date=null;
		simulatorVersion=null;
		maxQueueLength="200";
		days=100;
		preferredShiftLength=16;
		serviceLevelSeconds=20;
		efficiency=Distribution.getData(1,48);
		surcharge=Distribution.getData(1,48);
		caller.clear();
		callcenter.clear();
		skillLevel.clear();
	}

	/**
	 * EN: Returns the number of client types in this model<br>
	 * DE: Liefert die Anzahl an Kundengruppen in diesem Modell
	 * @return
	 * EN: Number of client types<br>
	 * DE: Anzahl an Kundengruppen
	 */
	public final int getCallerCount() {
		return caller.size();
	}

	/**
	 * EN: Returns the number of call centers in this model<br>
	 * DE: Liefert die Anzahl an Callcentern in diesem Modell
	 * @return
	 * EN: Number of call centers<br>
	 * DE: Anzahl an Callcentern
	 */
	public final int getCallcenterCount() {
		return callcenter.size();
	}

	/**
	 * EN: Returns the number of skill levels in this model<br>
	 * DE: Liefert die Anzahl an Skill-Levels in diesem Modell
	 * @return
	 * EN: Number of skill levels<br>
	 * DE: Anzahl an Skill-Levels
	 */
	public final int getSkillLevelCount() {
		return skillLevel.size();
	}

	/**
	 * EN: Returns a specific client type<br>
	 * DE: Liefert eine bestimmte Kundengruppe zur�ck
	 * @param index	<br>
	 * EN: Number (0-based) of the client group<br>
	 * DE: Nummer (0-basierend) der Kundengruppe
	 * @return
	 * EN: Returns in case of success a client type object; if the specified index is out of range, <code>null</code> will be returned.<br>
	 * DE: Liefert im Erfolgsfall das Kundengruppen-Objekt zur�ck; liegt der angegebene Index au�erhalb des g�ltigen Bereichs wird <code>null</code> zur�ckgegeben.
	 */
	public final CallCenterModelCaller getCaller(final int index) {
		if (index<0 || index>=caller.size()) return null; else return caller.get(index);
	}

	/**
	 * EN: Returns a specific call center<br>
	 * DE: Liefert ein bestimmtes Callcenter zur�ck
	 * @param index	<br>
	 * EN: Number (0-based) of the call center<br>
	 * DE: Nummer (0-basierend) des Callcenters
	 * @return
	 * EN: Returns in case of success a call center object; if the specified index is out of range, <code>null</code> will be returned.<br>
	 * DE: Liefert im Erfolgsfall das Callcenter-Objekt zur�ck; liegt der angegebene Index au�erhalb des g�ltigen Bereichs wird <code>null</code> zur�ckgegeben.
	 */
	public final CallCenterModelCallCenter getCallcenter(final int index) {
		if (index<0 || index>=callcenter.size()) return null; else return callcenter.get(index);
	}

	/**
	 * EN: Returns a specific skill level<br>
	 * DE: Liefert ein bestimmtes Skill-Level zur�ck
	 * @param index	<br>
	 * EN: Number (0-based) of the skill level<br>
	 * DE: Nummer (0-basierend) des Skill-Levels
	 * @return
	 * EN: Returns in case of success a skill level object; if the specified index is out of range, <code>null</code> will be returned.<br>
	 * DE: Liefert im Erfolgsfall das Skill-Level-Objekt zur�ck; liegt der angegebene Index au�erhalb des g�ltigen Bereichs wird <code>null</code> zur�ckgegeben.
	 */
	public final CallCenterModelSkillLevel getSkillLevel(final int index) {
		if (index<0 || index>=callcenter.size()) return null; else return skillLevel.get(index);
	}

	/**
	 * EN: Create a new client type and adds it to the list of the client types.<br>
	 * DE: Legt eine neue Anrufergruppe an und f�gt diese zu der Liste der Anrufergruppen hinzu.
	 * @param	name	<br>
	 * EN: Name of the new client type<br>
	 * DE: Name der neuen Kundengruppe
	 * @param	active	<br>
	 * EN: Is the new client type to be marked as active?<br>
	 * DE: Soll die neue Kundengruppe als aktiv gekennzeichnet werden?
	 * @return
	 * EN: Object of the new cient type<br>
	 * DE: Objekt der neuen Anrufergruppe
	 */
	public final CallCenterModelCaller addCaller(final String name, final boolean active) {
		CallCenterModelCaller caller=new CallCenterModelCaller(name,active);
		this.caller.add(caller);
		return caller;
	}

	/**
	 * EN: Create a new client type and adds it to the list of the client types.<br>
	 * DE: Legt eine neue Anrufergruppe an und f�gt diese zu der Liste der Anrufergruppen hinzu.
	 * @param	name	<br>
	 * EN: Name of the new client type<br>
	 * DE: Name der neuen Kundengruppe
	 * @return
	 * EN: Object of the new cient type<br>
	 * DE: Objekt der neuen Anrufergruppe

	 */
	public final CallCenterModelCaller addCaller(final String name) {
		return addCaller(name,true);
	}

	/**
	 * EN: Add an existing client type object to the list of client types.<br>
	 * DE: F�gt ein bestehendes Anrufergruppen-Objekt zu der Liste der Anrufergruppen hinzu.
	 * @param caller	<br>
	 * EN: Existing client type object<br>
	 * DE: Bestehendes Anrufergruppen-Objekt
	 */
	public final void addCaller(final CallCenterModelCaller caller) {
		this.caller.add(caller);
	}

	/**
	 * EN: Create a new call center and adds it to the list for call centers.<br>
	 * DE: Legt ein neues Callcenter an und f�gt dieses zu der Liste der Callcenter hinzu.
	 * @param	name	<br>
	 * EN: Name of the new call center<br>
	 * DE: Name des neuen Callcenters
	 * @param	active	<br>
	 * EN: Is the new call center to be marked as active?<br>
	 * DE: Soll das neue Callcenter als aktiv gekennzeichnet werden?
	 * @return
	 * EN: Object of the new call center<br>
	 * DE: Objekt des neuen Callcenters
	 */
	public final CallCenterModelCallCenter addCallcenter(final String name, final boolean active) {
		CallCenterModelCallCenter callcenter=new CallCenterModelCallCenter(name,active);
		this.callcenter.add(callcenter);
		return callcenter;
	}

	/**
	 * EN: Create a new call center and adds it to the list for call centers.<br>
	 * DE: Legt ein neues Callcenter an und f�gt dieses zu der Liste der Callcenter hinzu.
	 * @param	name	<br>
	 * EN: Name of the new call center<br>
	 * DE: Name des neuen Callcenters
	 * @return
	 * EN: Object of the new call center<br>
	 * DE: Objekt des neuen Callcenters
	 */
	public final CallCenterModelCallCenter addCallcenter(final String name) {
		return addCallcenter(name,true);
	}

	/**
	 * EN: Adds an existing call center object to the list of call centers.<br>
	 * DE: F�gt ein bestehendes Callcenter-Objekt zu der Liste der Callcenter hinzu.
	 * @param callcenter	<br>
	 * EN: Existing call center object<br>
	 * DE: Bestehendes Callcenter-Objekt
	 */
	public final void addCallcenter(final CallCenterModelCallCenter callcenter) {
		this.callcenter.add(callcenter);
	}

	/**
	 * EN: Create a new skill level and adds it to the list of skill levels.<br>
	 * DE: Legt einen neuen Skill-Level an und f�gt diesen zu der Liste der Skill-Level hinzu.
	 * @param	name	<br>
	 * EN: Name of hte new skill level<br>
	 * DE: Name des neuen Skill-Levels
	 * @return
	 * EN: Object of the new skill level<br>
	 * DE: Objekt des neuen Skill-Levels
	 */
	public final CallCenterModelSkillLevel addSkillLevel(final String name) {
		CallCenterModelSkillLevel skill=new CallCenterModelSkillLevel(name);
		skillLevel.add(skill);
		return skill;
	}

	/**
	 * EN: Adds an existing skill level object to the list of the skill levels.
	 * DE: F�gt eine bestehendes Skill-Level-Objekt zu der Liste der Skill-Level hinzu.
	 * @param skill
	 * EN: Existing skill level object<br>
	 * DE: Bestehendes Skill-Level-Objekt
	 */
	public final void addSkillLevel(final CallCenterModelSkillLevel skill) {
		skillLevel.add(skill);
	}

	/**
	 * EN: Return the call center model as XML document.<br>
	 * DE: Liefert das Callcenter-Modell als XML-Dokument zur�ck.
	 * @return
	 * EN: XML document containing the whole model. In case of an error <code>null</code> is returned.
	 * DE: XML-Dokument, welches das gesamte Modell enth�lt. Im Fehlerfall wird <code>null</code> zur�ckgegeben.
	 */
	public final Document saveXML() {
		Document doc=XML.getNewXMLDocument(); if (doc==null) return null;

		Element root,e;
		doc.appendChild(root=doc.createElement(Language.get(Language.Model_Root)));

		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Name))); e.setTextContent(name);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Description))); e.setTextContent(description);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Version))); e.setTextContent((simulatorVersion==null)?"":simulatorVersion);
		if (date!=null && !date.isEmpty()) {root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Date))); e.setTextContent(date);}
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_MaxQueueLength))); e.setTextContent(maxQueueLength);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Days))); e.setTextContent(""+days);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_PreferredShiftLength))); e.setTextContent(""+preferredShiftLength);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_ServiceLevel))); e.setTextContent(""+serviceLevelSeconds);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Efficiency))); e.setTextContent(efficiency);
		root.appendChild(e=doc.createElement(Language.get(Language.Model_General_Surcharge))); e.setTextContent(surcharge);

		for (int i=0;i<caller.size();i++) if (caller.get(i)!=null) caller.get(i).saveToXML(root);
		for (int i=0;i<callcenter.size();i++) if (callcenter.get(i)!=null)  callcenter.get(i).saveToXML(root);
		for (int i=0;i<skillLevel.size();i++) if (skillLevel.get(i)!=null) skillLevel.get(i).saveToXML(root);

		return doc;
	}

	/**
	 * EN: Saves the call center model to an XML file.<br>
	 * DE: Speichert das Callcenter-Modell in einer XML-Datei.
	 * @param file	<br>
	 * EN: File name of the XML file to which the model is to be saved.<br>
	 * DE: Dateiname der XML-Datei, in der das Modell gespeichert werden soll.
	 * @return
	 * EN: Returns <code>null</code> on success, otherwise the error message as a string.<br>
	 * DE: Gibt im Erfolgsfall <code>null</code> zur�ck, sonst die Fehlermeldung als Zeichenkette.
	 */
	public final String saveXML(final File file) {
		return XML.saveXMLDataToFile(this,file);
	}

	/**
	 * EN: Saves the call center model to a <code>OutputStream</code>.<br>
	 * DE: Speichert das Callcenter-Modell in einem <code>OutputStream</code>.
	 * @param stream	<br>
	 * EN: <code>OutputStream</code> to which the model is to be saved.<br>
	 * DE: <code>OutputStream</code>, in dem das Modell gespeichert werden soll.
	 * @return
	 * EN: Returns <code>null</code> on success, otherwise the error message as a string.<br>
	 * DE: Gibt im Erfolgsfall <code>null</code> zur�ck, sonst die Fehlermeldung als Zeichenkette.
	 */
	public final String saveXML(final OutputStream stream) {
		return XML.saveXMLDataToStream(this,stream);
	}

	/**
	 * EN: Trys to load a call center model from the given XML node<br>
	 * DE: Versucht ein Callcenter-Modell aus dem �bergebenen XML-Node zu laden
	 * @param node	<br>
	 * EN: XML node containgn the call center model<br>
	 * DE: XML-Knoten, der das Callcenter-Modell enth�lt
	 * @return
	 * EN: Returns <code>null</code> on success, otherwise the error message as a string.<br>
	 * DE: Gibt im Erfolgsfall <code>null</code> zur�ck, sonst die Fehlermeldung als Zeichenkette.
	 */
	public final String loadXML(final Element node) {
		if (!node.getNodeName().equalsIgnoreCase(Language.get(Language.Model_Root))) return Language.get(Language.Model_Root_Error);

		clear("");

		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			String s=e.getNodeName();

			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Name))) {name=e.getTextContent(); continue;}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Description))) {description=e.getTextContent(); continue;}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Date))) {date=e.getTextContent(); continue;}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Version))) {simulatorVersion=e.getTextContent(); continue;}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_MaxQueueLength))) {maxQueueLength=e.getTextContent(); continue;}

			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Days))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null || J==0) return Language.get(Language.Model_General_Days_Error);
				days=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_PreferredShiftLength))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null || J==0) return Language.get(Language.Model_General_PreferredShiftLength_Error);
				preferredShiftLength=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_ServiceLevel))) {
				Integer J=Numbers.getNotNegativeInteger(e.getTextContent());
				if (J==null || J==0) return Language.get(Language.Model_General_ServiceLevel_Error);
				serviceLevelSeconds=J; continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Efficiency))) {
				efficiency=e.getTextContent();
				continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_General_Surcharge))) {
				surcharge=e.getTextContent();
				continue;
			}

			if (s.equalsIgnoreCase(Language.get(Language.Model_ClientType))) {
				CallCenterModelCaller c=new CallCenterModelCaller("",true);
				String t=c.loadFromXML(e); if (t!=null) return t+" "+String.format(Language.get(Language.Model_ClientType_Error),caller.size()+1);
				caller.add(c); continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_CallCenter))) {
				CallCenterModelCallCenter c=new CallCenterModelCallCenter("",true);
				String t=c.loadFromXML(e); if (t!=null) return t+" "+String.format(Language.get(Language.Model_CallCenter_Error),callcenter.size()+1);
				callcenter.add(c); continue;
			}
			if (s.equalsIgnoreCase(Language.get(Language.Model_SkillLevel))) {
				CallCenterModelSkillLevel c=new CallCenterModelSkillLevel("");
				String t=c.loadFromXML(e); if (t!=null) return t+" "+String.format(Language.get(Language.Model_SkillLevel_Error),skillLevel.size()+1);
				skillLevel.add(c); continue;
			}
		}

		return null;
	}

	/**
	 * EN: Trys to load a call center model from the given file<br>
	 * DE: Versucht ein Callcenter-Modell aus der angegebenen Datei zu laden
	 * @param file	<br>
	 * EN: File from which the model is to be loaded<br>
	 * DE: Datei, aus der das Modell geladen werden soll
	 * @return
	 * EN: Returns <code>null</code> on success, otherwise the error message as a string.<br>
	 * DE: Gibt im Erfolgsfall <code>null</code> zur�ck, sonst die Fehlermeldung als Zeichenkette.
	 */
	public final String loadXML(final File file) {
		Element root=XML.loadXMLDataFromFile(file);
		if (root==null) return String.format(Language.get(Language.XML_LoadErrorFile),file.toString());
		return loadXML(root);
	}

	/**
	 * EN: Trys to load a call center model from the given stream<br>
	 * DE: Versucht ein Callcenter-Modell aus einem Stream zu laden
	 * @param stream	<br>
	 * EN: <code>InputStream</code> from which the call center is to be loaded<br>
	 * DE: <code>InputStream</code>, aus dem das Modell geladen werden soll
	 * @return
	 * EN: Returns <code>null</code> on success, otherwise the error message as a string.<br>
	 * DE: Gibt im Erfolgsfall <code>null</code> zur�ck, sonst die Fehlermeldung als Zeichenkette.
	 */
	public final String loadXML(InputStream stream) {
		Element root=XML.loadXMLDataFromStream(stream);
		if (root==null) return Language.get(Language.XML_LoadErrorStream);
		return loadXML(root);
	}
}