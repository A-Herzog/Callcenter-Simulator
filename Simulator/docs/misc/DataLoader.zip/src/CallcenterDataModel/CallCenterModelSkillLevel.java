package CallcenterDataModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import CallcenterDataModel.Tools.Language;
import CallcenterDataModel.Tools.Numbers;

/**
 * EN: Encapsulates the XML data of a skill level<br>
 * DE: Kapselt die XML-Daten eines Skill-Levels
 * @author Alexander Herzog
 */
public final class CallCenterModelSkillLevel implements Cloneable {
	/**
	 * EN: Name of the skill level<br>
	 * DE: Name des Skill-Levels
	 */
	public String name;

	/**
	 * EN: List of the client type names for the client type specific data<br>
	 * DE: Liste der Kundentypnamen f�r Kundentyp spezifische Daten
	 */
	private final List<String> callerTypeName;
	/**
	 * EN: List of the client type specific holding times<br>
	 * DE: Liste der Kundentyp spezifischen Bedienzeitverteilungen
	 */
	private final List<String> callerTypeWorkingTime;
	/**
	 * EN: List of the client type specific holding times (depending on the time of day)<br>
	 * DE: Liste der Kundentyp spezifischen Bedienzeitverteilungen (in Abh�ngigkeit von dem Zeitintervall)
	 */
	private final List<String[]> callerTypeIntervalWorkingTime;
	/**
	 * EN: List of the client type specific post processing times<br>
	 * DE: Liste der Kundentyp spezifischen Nachbearbeitungszeitverteilung
	 */
	private final List<String> callerTypePostProcessingTime;
	/**
	 * EN: List of the client type specific post processing times (depending on the time of day)<br>
	 * DE: Liste der Kundentyp spezifischen Nachbearbeitungszeitverteilung (in Abh�ngigkeit von dem Zeitintervall)
	 */
	private final List<String[]> callerTypeIntervalPostProcessingTime;
	/**
	 * EN: List of the client type specific priorities<br>
	 * DE: Liste der Kundentyp spezifischen Priorit�ten
	 */
	private final List<Integer> callerTypeScore;

	/**
	 * EN: Constrcutor of the class <code>CallCenterModelSkillLevel</code><br>
	 * DE: Konstruktor der Klasse <code>CallCenterModelSkillLevel</code>
	 * @param	name	<br>
	 * EN: Name of the skill level<br>
	 * DE: Name des Skill-Levels
	 */
	public CallCenterModelSkillLevel(final String name) {
		this.name=name;
		callerTypeName=new ArrayList<String>();
		callerTypeWorkingTime=new ArrayList<String>();
		callerTypeIntervalWorkingTime=new ArrayList<String[]>();
		callerTypePostProcessingTime=new ArrayList<String>();
		callerTypeIntervalPostProcessingTime=new ArrayList<String[]>();
		callerTypeScore=new ArrayList<Integer>();
	}

	/**
	 * EN: Creates a copy of the skill level<br>
	 * DE: Erstellt eine Kopie des Skill-Levels
	 * @param	name	<br>
	 * EN: Name of the new skill level<br>
	 * DE: Name des neuen Skill-Levels
	 * @return
	 * EN: New skill level object<br>
	 * DE: Neues Skill-Level-Objekt
	 */
	public final CallCenterModelSkillLevel clone(final String name) {
		CallCenterModelSkillLevel skill=new CallCenterModelSkillLevel(name);

		skill.callerTypeName.addAll(callerTypeName);
		skill.callerTypeWorkingTime.addAll(callerTypeWorkingTime);
		for (int i=0;i<callerTypeIntervalWorkingTime.size();i++) skill.callerTypeIntervalWorkingTime.add(Arrays.copyOf(callerTypeIntervalWorkingTime.get(i),48));
		skill.callerTypePostProcessingTime.addAll(callerTypePostProcessingTime);
		for (int i=0;i<callerTypeIntervalPostProcessingTime.size();i++) skill.callerTypeIntervalPostProcessingTime.add(Arrays.copyOf(callerTypeIntervalPostProcessingTime.get(i),48));
		skill.callerTypeScore.addAll(callerTypeScore);

		return skill;
	}

	/**
	 * EN: Creates a copy of the skill level<br>
	 * DE: Erstellt eine Kopie des Skill-Levels
	 * @return
	 * EN: New skill level object<br>
	 * DE: Neues Skill-Level-Objekt
	 */
	@Override
	public Object clone() {
		return clone(name);
	}

	/**
	 * EN: Adds the skill to serve a specific client type to the skill level.<br>
	 * DE: F�gt dem Skill-Level die Bef�higung einen bestimmten Kundentyp bedienen zu k�nnen, hinzu.
	 * @param callerType	<br>
	 * EN: Client type which agents of this skill level should be able to serve.<br>
	 * DE: Kundentyp, der durch Agenten dieses Skill-Levels bedient werden k�nnen.
	 * @param workingTimeDistribution	<br>
	 * EN: Holding time distribution for this client type<br>
	 * DE: Bedienzeitverteilung f�r Kunden dieses Typs
	 * @param postProcessingTimeDistribution	<br>
	 * EN: Post processing time distribution for this client type<br>
	 * DE: Nachbearbeitungszeitverteilung f�r Kunden dieses Typs
	 * @param workingTimeIntervalDistribution	<br>
	 * EN: Array of 48 strings containing optional holding time distributions for this client type on interval basis<br>
	 * DE: Array aus 48 Strings, die die optionalen intervallabh�ngigen Bedienzeitverteilungen f�r Kunden dieses Typs angeben
	 * @param postProcessingTimeIntervalDistribution	<br>
	 * EN: Array of 48 strings containing optional post processing time distributions for this client type on interval basis<br>
	 * DE: Array aus 48 Strings, die die optionalen intervallabh�ngigen Nachbearbeitungszeitverteilung f�r Kunden dieses Typs angeben
	 * @param score	<br>
	 * EN: Score for the agents of this skill level for this client type<br>
	 * DE: Score der Agenten dieses Skill-Levels f�r Kunden dieses Typs
	 */
	public final void addSkill(final String callerType, final String workingTimeDistribution, final String postProcessingTimeDistribution, final String[] workingTimeIntervalDistribution, final String[] postProcessingTimeIntervalDistribution, final int score) {
		callerTypeName.add(callerType);
		callerTypeWorkingTime.add(workingTimeDistribution);
		if (workingTimeIntervalDistribution==null) callerTypeIntervalWorkingTime.add(new String[48]); else callerTypeIntervalWorkingTime.add(Arrays.copyOf(workingTimeIntervalDistribution,48));
		callerTypePostProcessingTime.add(postProcessingTimeDistribution);
		if (postProcessingTimeIntervalDistribution==null) callerTypeIntervalPostProcessingTime.add(new String[48]); else callerTypeIntervalPostProcessingTime.add(Arrays.copyOf(postProcessingTimeIntervalDistribution,48));
		callerTypeScore.add(score);
	}

	/**
	 * EN: Adds the skill to serve a specific client type to the skill level.<br>
	 * DE: F�gt dem Skill-Level die Bef�higung einen bestimmten Kundentyp bedienen zu k�nnen, hinzu.
	 * @param callerType	<br>
	 * EN: Client type which agents of this skill level should be able to serve.<br>
	 * DE: Kundentyp, der durch Agenten dieses Skill-Levels bedient werden k�nnen.
	 * @param workingTimeDistribution	<br>
	 * EN: Holding time distribution for this client type<br>
	 * DE: Bedienzeitverteilung f�r Kunden dieses Typs
	 * @param postProcessingTimeDistribution	<br>
	 * EN: Post processing time distribution for this client type<br>
	 * DE: Nachbearbeitungszeitverteilung f�r Kunden dieses Typs
	 * @param score	<br>
	 * EN: Score for the agents of this skill level for this client type<br>
	 * DE: Score der Agenten dieses Skill-Levels f�r Kunden dieses Typs
	 */
	public final void addSkill(final String callerType, final String workingTimeDistribution, final String postProcessingTimeDistribution, final int score) {
		addSkill(callerType,workingTimeDistribution,postProcessingTimeDistribution,null,null,score);
	}

	/**
	 * EN: Adds the skill to serve a specific client type to the skill level.<br>
	 * DE: F�gt dem Skill-Level die Bef�higung einen bestimmten Kundentyp bedienen zu k�nnen, hinzu.
	 * @param callerType	<br>
	 * EN: Client type which agents of this skill level should be able to serve.<br>
	 * DE: Kundentyp, der durch Agenten dieses Skill-Levels bedient werden k�nnen.
	 * @param workingTimeDistribution	<br>
	 * EN: Holding time distribution for this client type<br>
	 * DE: Bedienzeitverteilung f�r Kunden dieses Typs
	 * @param postProcessingTimeDistribution	<br>
	 * EN: Post processing time distribution for this client type<br>
	 * DE: Nachbearbeitungszeitverteilung f�r Kunden dieses Typs
	 */
	public final void addSkill(final String callerType, final String workingTimeDistribution, final String postProcessingTimeDistribution) {
		addSkill(callerType,workingTimeDistribution,postProcessingTimeDistribution,1);
	}

	/**
	 * EN: Returns a list containing the names of the client types agents of this skill level can serve.<br>
	 * DE: Liefert eine Liste mit den Namen der Kundentypen, die durch Agenten dieses Skill-Levels bedient werden k�nnen.
	 * @return
	 * EN: List containing the client types<br>
	 * DE: Liste mit Kundentypen
	 */
	public final List<String> getSkills() {
		return new ArrayList<String>(callerTypeName);
	}

	/**
	 * EN: Create a new child node in the giving parent XML node containing all skill level data.<br>
	 * DE: Erstellt unterhalb des �bergebenen XML-Knotens einen neuen Knoten, der die gesamten Skill-Level-Daten enth�lt.
	 * @param parent	<br>
	 * EN: Parent XML node<br>
	 * DE: Eltern-XML-Knoten
	 */
	final void saveToXML(final Element parent) {
		Document doc=parent.getOwnerDocument();
		Element node=doc.createElement(Language.get(Language.Model_SkillLevel)); parent.appendChild(node);
		node.setAttribute(Language.get(Language.Model_General_Attribute_Name),name);
		Element e,e2;

		for (int i=0;i<Math.min(Math.min(Math.min(callerTypeName.size(),callerTypeWorkingTime.size()),callerTypePostProcessingTime.size()),callerTypeScore.size());i++) {
			if (callerTypeName.get(i)==null || callerTypeWorkingTime.get(i)==null || callerTypePostProcessingTime.get(i)==null || callerTypeScore.get(i)==null) continue;
			node.appendChild(e=doc.createElement(Language.get(Language.Model_SkillLevel_ClientType))); e.setAttribute(Language.get(Language.Model_General_Attribute_Name),callerTypeName.get(i));
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_SkillLevel_HoldingTime))); e2.setTextContent(callerTypeWorkingTime.get(i));
			String[] times=callerTypeIntervalWorkingTime.get(i);
			if (times!=null) for (int j=0;j<times.length;j++) if (times[j]!=null && !times[j].isEmpty()) {
				e.appendChild(e2=doc.createElement(Language.get(Language.Model_SkillLevel_HoldingTime))); e2.setTextContent(times[j]);
				e2.setAttribute(Language.get(Language.Model_SkillLevel_HoldingTime_Interval),""+(j+1));
			}
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_SkillLevel_PostProcessingTime))); e2.setTextContent(callerTypePostProcessingTime.get(i));
			times=callerTypeIntervalPostProcessingTime.get(i);
			if (times!=null) for (int j=0;j<times.length;j++) if (times[j]!=null && !times[j].isEmpty()) {
				e.appendChild(e2=doc.createElement(Language.get(Language.Model_SkillLevel_PostProcessingTime))); e2.setTextContent(times[j]);
				e2.setAttribute(Language.get(Language.Model_SkillLevel_PostProcessingTime_Interval),""+(j+1));
			}
			e.appendChild(e2=doc.createElement(Language.get(Language.Model_SkillLevel_Score))); e2.setTextContent(""+callerTypeScore.get(i));
		}
	}

	/**
	 * EN: Trys to load the skill level data from the given XML node<br>
	 * DE: Versucht einen Skill-Level aus dem �bergebenen XML-Node zu laden
	 * @param node	<br>
	 * EN: XML node from which the skill level data is to be loaded<br>
	 * DE: XML-Knoten, der die Skill-Level-Daten enth�lt
	 * @return
	 * EN: If an error occurs, the error message will be returned as a string. In case of success <code>null</code> will be returned.<br>
	 * DE: Tritt ein Fehler auf, so wird die Fehlermeldung als String zur�ckgegeben. Im Erfolgsfall wird <code>null</code> zur�ckgegeben.
	 */
	final String loadFromXML(final Element node) {
		name=node.getAttribute(Language.get(Language.Model_General_Attribute_Name));

		callerTypeName.clear();
		callerTypeWorkingTime.clear();
		callerTypeIntervalWorkingTime.clear();
		callerTypePostProcessingTime.clear();
		callerTypeIntervalPostProcessingTime.clear();
		callerTypeScore.clear();

		NodeList l=node.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			if (!e.getNodeName().equalsIgnoreCase(Language.get(Language.Model_SkillLevel_ClientType))) continue;

			String typeName=e.getAttribute(Language.get(Language.Model_General_Attribute_Name));
			String typeWorking="";
			String[] typeIntervalWorking=new String[48];
			for (int j=0;j<48;j++) typeIntervalWorking[j]="";
			String typePostProcessing="";
			String[] typeIntervalPostProcessing=new String[48];
			for (int j=0;j<48;j++) typeIntervalPostProcessing[j]="";
			int typeScore=1;

			NodeList l2=e.getChildNodes();
			for (int j=0; j<l2.getLength();j++) {
				if (!(l2.item(j) instanceof Element)) continue;
				Element e2=(Element)l2.item(j);
				String t=e2.getNodeName();

				if (t.equalsIgnoreCase(Language.get(Language.Model_SkillLevel_HoldingTime))) {
					Integer I=Numbers.getInteger(e2.getAttribute(Language.get(Language.Model_SkillLevel_HoldingTime_Interval)));
					if (I==null || I<1 || I>48)	typeWorking=e2.getTextContent(); else typeIntervalWorking[I]=e2.getTextContent();
					continue;
				}
				if (t.equalsIgnoreCase(Language.get(Language.Model_SkillLevel_PostProcessingTime))) {
					Integer I=Numbers.getInteger(e2.getAttribute(Language.get(Language.Model_SkillLevel_PostProcessingTime_Interval)));
					if (I==null || I<1 || I>48)	typePostProcessing=e2.getTextContent(); else typeIntervalPostProcessing[I]=e2.getTextContent();
					continue;
				}
				if (t.equalsIgnoreCase(Language.get(Language.Model_SkillLevel_Score))) {
					Integer K=Numbers.getNotNegativeInteger(e2.getTextContent());
					if (K==null) return String.format(Language.get(Language.Model_SkillLevel_Score_Error),callerTypeName.size()+1);
					typeScore=K; continue;
				}
			}
			if (typeWorking==null || typePostProcessing==null) return String.format(Language.get(Language.Model_SkillLevel_NoDataError),callerTypeName.size()+1);
			callerTypeName.add(typeName);
			callerTypeWorkingTime.add(typeWorking);
			callerTypePostProcessingTime.add(typePostProcessing);
			callerTypeScore.add(typeScore);
		}
		return null;
	}
}
