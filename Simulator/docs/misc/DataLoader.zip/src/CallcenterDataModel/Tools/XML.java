package CallcenterDataModel.Tools;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import CallcenterDataModel.CallCenterModel;

/**
 * EN: Tools for creating XML call center models<br>
 * DE: Hilfsmittel zum Anlegen von XML-Callcenter-Modellen
 * @author Alexander Herzog
 */
public final class XML {
	private XML() {}

	private static final String dtdBaseURL="https://cs.highfives.io";
	private static final String dtdMediaURL=dtdBaseURL+"/Media/";

	/**
	 * EN: Defines if links to the dtd and xsd file should be added in the file header of the xml files.<br>
	 * DE: Gibt an, ob Verweise auf dtd- und xsd-Dateien beim Speichern in den Dateikopf der xml-Datei eingef�gt werden sollen.
	 */
	public static boolean writeDocType=true;

	/**
	 * EN: Creates a new, empty xml document.<br>
	 * DE: Legt ein neues, leeres XML-Dokument an.
	 * @return
	 * EN: Returns on success the document object or <code>null</code> in case of an error.<br>
	 * DE: Liefert im Erfolgsfall das Dokumenten-Objekt zur�ck; im Fehlerfall <code>null</code>.
	 */
	public static final Document getNewXMLDocument() {
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {db=dbf.newDocumentBuilder();} catch (ParserConfigurationException e) {return null;}
		return db.newDocument();
	}

	/**
	 * EN: Writes the xml document to an <code>OutputStream</code>.<br>
	 * DE: Schreibt ein XML-Dokument in einen <code>OutputStream</code>.
	 * @param xml	<br>
	 * EN: XML document to be saved<br>
	 * DE: Zu speicherndes XML-Dokument
	 * @param stream	<br>
	 * EN: Stream object in which the data is to be written<br>
	 * DE: Stream-Objekt, in das die Daten geschrieben werden sollen
	 * @return
	 * EN: Gives <code>null</code> if the data was saved successfully, otherwise a string containing the error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Daten gespeichert werden konnten, sonst eine Zeichenkette mit der Fehlermeldung.
	 */
	public static final String saveXMLDataToStream(final Document xml, final OutputStream stream) {
		if (writeDocType) {
			Element root=xml.getDocumentElement();
			root.setAttribute("xmlns",dtdBaseURL);
			root.setAttribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance");
			root.setAttribute("xsi:schemaLocation",dtdBaseURL+" "+dtdMediaURL+Language.get(Language.XML_XSD));
		}

		Transformer transformer;
		try {
			transformer=TransformerFactory.newInstance().newTransformer();
		} catch (TransformerConfigurationException | TransformerFactoryConfigurationError e1) {return Language.get(Language.XML_WritingFailed);}
		transformer.setOutputProperty(OutputKeys.INDENT,"yes");
		if (writeDocType) transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM,dtdMediaURL+Language.get(Language.XML_DTD));
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","2");
		try {
			transformer.transform(new DOMSource(xml),new StreamResult(stream));
		} catch (TransformerException e1) {return Language.get(Language.XML_WritingFailed);}

		return null;
	}

	/**
	 * EN: Writes a call center model to an <code>OutputStream</code>.<br>
	 * DE: Schreibt ein Callcenter-Modell in einen <code>OutputStream</code>.
	 * @param model	<br>
	 * EN: Call center model to be saved<br>
	 * DE: Zu speicherndes Callcenter-Modell
	 * @param stream	<br>
	 * EN: Stream object in which the data is to be written<br>
	 * DE: Stream-Objekt, in das die Daten geschrieben werden sollen
	 * @return
	 * EN: Gives <code>null</code> if the data was saved successfully, otherwise a string containing the error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Daten gespeichert werden konnten, sonst eine Zeichenkette mit der Fehlermeldung.
	 */
	public static final String saveXMLDataToStream(final CallCenterModel model, final OutputStream stream) {
		return saveXMLDataToStream(model.saveXML(),stream);
	}

	/**
	 * EN: Saves an XML document to a file.<br>
	 * DE: Speichert ein XML-Dokument in einer Datei.<br>
	 * @param xml	<br>
	 * EN: XML document to be saved<br>
	 * DE: Zu speicherndes XML-Dokument
	 * @param file	<br>
	 * EN: File in which the xml data is to be stored. Existing files are overwritten.<br>
	 * DE: Datei, in der die XML-Daten gespeichert werden sollen. Existierende Dateien werden �berschrieben.
	 * @return
	 * EN: Gives <code>null</code> if the data was saved successfully, otherwise a string containing the error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Daten gespeichert werden konnten, sonst eine Zeichenkette mit der Fehlermeldung.
	 */
	public static final String saveXMLDataToFile(final Document xml, final File file) {
		if (xml==null) return Language.get(Language.XML_ErrorCreatingXMLData);

		if (file==null) return Language.get(Language.XML_NoOutputFileSpecified);

		try (FileOutputStream fileOutput=new FileOutputStream(file);) {
			String s=file.toString().toUpperCase();
			if (s.endsWith(".ZIP") || s.endsWith(".XMZ")) {
				try (ZipOutputStream zipOutput=new ZipOutputStream(fileOutput)) {
					try {zipOutput.putNextEntry(new ZipEntry("data.xml"));} catch (IOException e1) {return Language.get(Language.XML_WritingFailed);}
					return saveXMLDataToStream(xml,zipOutput);
				} catch (IOException e) {return Language.get(Language.XML_WritingFailed);}
			} else {
				return saveXMLDataToStream(xml,fileOutput);
			}
		} catch (IOException e) {return Language.get(Language.XML_WritingFailed);}
	}

	/**
	 * EN: Writes a call center model to a file.<br>
	 * DE: Speichert ein Callcenter-Modell in einer XML-Datei.
	 * @param model	<br>
	 * EN: Call center model to be saved<br>
	 * DE: Zu speicherndes Callcenter-Modell
	 * @param file	<br>
	 * EN: File in which the xml data is to be stored. Existing files are overwritten.<br>
	 * DE: Datei, in der die XML-Daten gespeichert werden sollen. Existierende Dateien werden �berschrieben.
	 * @return
	 * EN: Gives <code>null</code> if the data was saved successfully, otherwise a string containing the error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Daten gespeichert werden konnten, sonst eine Zeichenkette mit der Fehlermeldung.
	 */
	public static final String saveXMLDataToFile(final CallCenterModel model, final File file) {
		return saveXMLDataToFile(model.saveXML(),file);
	}

	/**
	 * EN: Trys to load XML data from a steam into an <code>Element</code> object<br>
	 * DE: Versucht XML-Daten aus einem Stream in ein <code>Element</code>-Objekt zu laden
	 * @param stream	<br>
	 * EN: <code>InputStream</code> from which the XML data is to be loaded<br>
	 * DE: <code>InputStream</code> aus dem die XML-Daten geladen werden sollen
	 * @return
	 * EN: If an error occurs, <code>null</code> will be returned; otherwise the root element will be returned.<br>
	 * DE: Tritt ein Fehler auf, so wird <code>null</code> zur�ckgegeben; andernfalls wird das root-Element zur�ckgegeben.
	 */
	public static final Element loadXMLDataFromStream(InputStream stream) {
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {
			dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
			db=dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e) {return null;}
		db.setErrorHandler(null);
		Element root=null;
		try {root=db.parse(stream,"").getDocumentElement();} catch (SAXException e) {return null;} catch (IOException e) {return null;}

		return root;
	}

	/**
	 * EN: Trys to load an XML or a ZIP file into an <code>Element</code> object<br>
	 * DE: Versucht eine XML- oder ZIP-Datei in ein <code>Element</code>-Objekt zu laden
	 * @param file	<br>
	 * EN: File name of the XML file to be loaded<br>
	 * DE: Dateiname der XML-Datei, die geladen werden soll
	 * @return
	 * EN: If an error occurs, <code>null</code> will be returned; otherwise the root element will be returned.<br>
	 * DE: Tritt ein Fehler auf, so wird <code>null</code> zur�ckgegeben; andernfalls wird das root-Element zur�ckgegeben.
	 */
	public static final Element loadXMLDataFromFile(final File file) {
		if (file==null || !file.exists()) return null;

		try (FileInputStream fileInput=new FileInputStream(file);) {
			String s=file.toString().toUpperCase();
			if (s.endsWith(".ZIP") || s.endsWith(".XMZ")) {
				try (ZipInputStream zipInput=new ZipInputStream(fileInput)) {
					try {zipInput.getNextEntry();} catch (IOException e) {return null;}
					return loadXMLDataFromStream(zipInput);
				} catch (IOException e) {return null;}
			} else {
				return loadXMLDataFromStream(fileInput);
			}
		} catch (IOException e) {return null;}
	}

	/**
	 * EN: Converts a system floating point number (always with "." as decimal separator) given as a string in a local floating point number (in the English locale also with ".").<br>
	 * DE: Wandelt eine als Zeichenkette �bergebene System-Flie�kommazahl (d.h. mit "." als Dezimaltrenner) in eine lokale Flie�kommazahl um (in der deutschen Variante mit ",") um.
	 * @param number	<br>
	 * EN: Floating point number to be converted as a string (with "." as decimal separator)<br>
	 * DE: Umzuwandelnde Flie�kommazahl als Zeichenkette mit "." als Dezimaltrenner
	 * @return
	 * EN: Floating point number as a string again with "." as decimal separator<br>
	 * DE: Flie�kommazahl als String mit "," als Dezimaltrenner
	 */
	final static String systemNumberToLocalNumber(final String number) {
		try {
			double d=Double.valueOf(number);
			String s=String.format(Language.getLocale(),"%.18f",d);
			while (((s.contains(",")) || (s.contains("."))) && (s.endsWith("0"))) {s=s.substring(0,s.length()-1);}
			if ((s.endsWith(".")) || (s.endsWith(","))) s=s.substring(0,s.length()-1);
			return s;
		} catch (NumberFormatException e) {return number;}
	}
}
