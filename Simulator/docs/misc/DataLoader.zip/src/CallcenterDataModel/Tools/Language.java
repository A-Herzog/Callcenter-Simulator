package CallcenterDataModel.Tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * EN: Simple language class for the XML model writer<br>
 * Just select a language by calling <code>select</code> and then get strings by calling <code>get</code>.<br>
 * DE: Einfache Sprach-Klasse f�r den XML-Modell-Ersteller<br>
 * Einfach per <code>select</code> eine Sprache ausw�hlen und dann per <code>get</code> Zeichenketten abrufen.
 * @author Alexander Herzog
 * @see select
 * @see get
 */
public class Language {
	/**
	 * EN: Language ID for English<br>
	 * DE: Sprach-ID f�r Englisch
	 * @see select
	 */
	public static final int LANGUAGE_ENGLISH=0;

	/**
	 * EN: Language ID for German<br>
	 * DE: Sprach-ID f�r Deutsch
	 * @see select
	 */
	public static final int LANGUAGE_GERMAN=1;

	/*
	EN: IDs for the language keys (see "get")
	DE: IDs f�r die Sprach-IDs (siehe "get")
	 */
	public static final int File_InputFileDoesNotExist=0;
	public static final int File_InputFileIsADirectory=1;
	public static final int File_LoadError=2;

	public static final int XML_DTD=20;
	public static final int XML_XSD=21;
	public static final int XML_WritingFailed=22;
	public static final int XML_ErrorCreatingXMLData=23;
	public static final int XML_NoOutputFileSpecified=24;
	public static final int XML_LoadErrorFile=25;
	public static final int XML_LoadErrorStream=26;
	public static final int XML_Written=27;
	public static final int XML_DBWriteError=28;
	public static final int XML_DBReadError=29;

	public static final int Distribution_Infinite=100;
	public static final int Distribution_Point=101;
	public static final int Distribution_Data=102;
	public static final int Distribution_Exp=103;
	public static final int Distribution_Normal=104;
	public static final int Distribution_LogNormal=105;
	public static final int Distribution_Gamma=106;
	public static final int Distribution_Beta=107;
	public static final int Distribution_Cauchy=108;
	public static final int Distribution_Uniform=109;
	public static final int Distribution_Erlang=110;
	public static final int Distribution_F=111;
	public static final int Distribution_ChiSquare=112;
	public static final int Distribution_Weibull=113;

	public static final int CSV_InvalidStartCell=200;
	public static final int CSV_InvalidEndCell=201;
	public static final int CSV_InvalidRange=202;
	public static final int CSV_CellNotInTable=203;
	public static final int CSV_InvalidValue=204;
	public static final int CSV_ErrorInLine=205;

	public static final int Model_Root=300;
	public static final int Model_Root_Error=301;
	public static final int Model_General_Name=302;
	public static final int Model_General_Version=303;
	public static final int Model_General_Description=304;
	public static final int Model_General_Date=305;
	public static final int Model_General_MaxQueueLength=306;
	public static final int Model_General_Days=307;
	public static final int Model_General_Days_Error=308;
	public static final int Model_General_PreferredShiftLength=309;
	public static final int Model_General_PreferredShiftLength_Error=310;
	public static final int Model_General_ServiceLevel=311;
	public static final int Model_General_ServiceLevel_Error=312;
	public static final int Model_General_Efficiency=313;
	public static final int Model_General_Surcharge=314;
	public static final int Model_General_Bool_False=315;
	public static final int Model_General_Bool_Off=316;
	public static final int Model_General_Bool_No=317;
	public static final int Model_General_Bool_True=318;
	public static final int Model_General_Bool_On=319;
	public static final int Model_General_Bool_Yes=320;
	public static final int Model_General_Attribute_Name=321;
	public static final int Model_General_Attribute_Active=322;
	public static final int Model_General_Attribute_Probability=323;

	public static final int Model_ClientType=401;
	public static final int Model_ClientType_Error=402;
	public static final int Model_ClientType_BlocksLine=403;
	public static final int Model_ClientType_ServiceLevel=404;
	public static final int Model_ClientType_ServiceLevel_Error=405;
	public static final int Model_ClientType_FreshCalls=406;
	public static final int Model_ClientType_FreshCallsCount=407;
	public static final int Model_ClientType_FreshCallsCount_Error=408;
	public static final int Model_ClientType_FreshCallsStandardDeviation=409;
	public static final int Model_ClientType_FreshCallsStandardDeviation_Error=410;
	public static final int Model_ClientType_FreshCallsDistribution=411;
	public static final int Model_ClientType_FreshCallsDistribution_Error=412;
	public static final int Model_ClientType_ClientsScore=413;
	public static final int Model_ClientType_ClientsScore_Base=414;
	public static final int Model_ClientType_ClientsScore_Base_Error=415;
	public static final int Model_ClientType_ClientsScore_Forwarding=416;
	public static final int Model_ClientType_ClientsScore_Forwarding_Error=417;
	public static final int Model_ClientType_ClientsScore_PerWaitingSecond=418;
	public static final int Model_ClientType_ClientsScore_PerWaitingSecond_Error=419;
	public static final int Model_ClientType_WaitingTimeTolerance_Short=420;
	public static final int Model_ClientType_WaitingTimeTolerance_Short_Error=421;
	public static final int Model_ClientType_WaitingTimeTolerance_Long=422;
	public static final int Model_ClientType_WaitingTimeTolerance_Long_Error=423;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation=424;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime=425;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime_Missing=426;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_WaitingTime_Error=427;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate=428;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Missing=429;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Error=430;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue=431;
	public static final int Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue_Error=432;
	public static final int Model_ClientType_Retry=433;
	public static final int Model_ClientType_Retry_Interval=434;
	public static final int Model_ClientType_Retry_Interval_Error=435;
	public static final int Model_ClientType_Retry_BlockedFirst=436;
	public static final int Model_ClientType_Retry_BlockedFirst_Error=437;
	public static final int Model_ClientType_Retry_BlockedFirst_ClientType=438;
	public static final int Model_ClientType_Retry_BlockedSecond=439;
	public static final int Model_ClientType_Retry_BlockedSecond_Error=440;
	public static final int Model_ClientType_Retry_BlockedSecond_ClientType=441;
	public static final int Model_ClientType_Retry_WaitingFirst=442;
	public static final int Model_ClientType_Retry_WaitingFirst_Error=443;
	public static final int Model_ClientType_Retry_WaitingFirst_ClientType=444;
	public static final int Model_ClientType_Retry_WaitingSecond=445;
	public static final int Model_ClientType_Retry_WaitingSecond_Error=446;
	public static final int Model_ClientType_Retry_WaitingSecond_ClientType=447;
	public static final int Model_ClientType_Retry_NewClientType=448;
	public static final int Model_ClientType_Retry_NewClientType_Error=449;
	public static final int Model_ClientType_Forwarding=450;
	public static final int Model_ClientType_Forwarding_Error=451;
	public static final int Model_ClientType_Forwarding_NewClientType=452;
	public static final int Model_ClientType_Forwarding_NewClientType_Error=453;
	public static final int Model_ClientType_Forwarding_Special=454;
	public static final int Model_ClientType_Forwarding_Special_Error=455;
	public static final int Model_ClientType_Forwarding_Special_SkillLevel=456;
	public static final int Model_ClientType_Forwarding_Special_NewClientType=457;
	public static final int Model_ClientType_Forwarding_Special_NewClientType_Error=458;
	public static final int Model_ClientType_Recall=459;
	public static final int Model_ClientType_Recall_Error=460;
	public static final int Model_ClientType_Recall_Interval=461;
	public static final int Model_ClientType_Recall_Interval_Error=462;
	public static final int Model_ClientType_Recall_NewClientType=463;
	public static final int Model_ClientType_Recall_NewClientType_Error=464;
	public static final int Model_ClientType_Recall_Special=465;
	public static final int Model_ClientType_Recall_Special_Error=466;
	public static final int Model_ClientType_Recall_Special_SkillLevel=467;
	public static final int Model_ClientType_Recall_Special_NewClientType=468;
	public static final int Model_ClientType_Recall_Special_NewClientType_Error=469;
	public static final int Model_ClientType_Yield=470;
	public static final int Model_ClientType_Yield_Error=471;
	public static final int Model_ClientType_Costs=472;
	public static final int Model_ClientType_Costs_Cancel=473;
	public static final int Model_ClientType_Costs_Cancel_Error=474;
	public static final int Model_ClientType_Costs_Waiting=475;
	public static final int Model_ClientType_Costs_Waiting_Error=476;

	public static final int Model_CallCenter=501;
	public static final int Model_CallCenter_Error=502;
	public static final int Model_CallCenter_TechnicalFreeTime=503;
	public static final int Model_CallCenter_TechnicalFreeTime_Error=504;
	public static final int Model_CallCenter_CallCenterScore=505;
	public static final int Model_CallCenter_CallCenterScore_Error=506;
	public static final int Model_CallCenter_AgentsScore=507;
	public static final int Model_CallCenter_AgentsScore_LastCall=508;
	public static final int Model_CallCenter_AgentsScore_LastCall_Error=509;
	public static final int Model_CallCenter_AgentsScore_Part=510;
	public static final int Model_CallCenter_AgentsScore_Part_Error=511;
	public static final int Model_CallCenter_MinimumWaitingTime=512;
	public static final int Model_CallCenter_MinimumWaitingTime_ClientType=513;
	public static final int Model_CallCenter_MinimumWaitingTime_ClientType_Error=514;

	public static final int Model_Agents=601;
	public static final int Model_Agents_Error=602;
	public static final int Model_Agents_Count=603;
	public static final int Model_Agents_Count_Error=604;
	public static final int Model_Agents_WorkingStart=605;
	public static final int Model_Agents_WorkingStart_Error=606;
	public static final int Model_Agents_WorkingEnd=607;
	public static final int Model_Agents_WorkingEnd_Error=608;
	public static final int Model_Agents_Distribution=609;
	public static final int Model_Agents_Distribution_Error=610;
	public static final int Model_Agents_Distribution_LastShiftOpenEnd=611;
	public static final int Model_Agents_ByClients=612;
	public static final int Model_Agents_ByClients_WorkingHalfHours=613;
	public static final int Model_Agents_ByClients_WorkingHalfHours_Error=614;
	public static final int Model_Agents_ByClients_ClientType=615;
	public static final int Model_Agents_ByClients_ClientType_Rate=616;
	public static final int Model_Agents_ByClients_ClientType_Rate_Error=617;
	public static final int Model_Agents_SkillLevel=618;
	public static final int Model_Agents_CostsPerHour=619;
	public static final int Model_Agents_CostsPerHour_Error=620;
	public static final int Model_Agents_CostsPerClientType=621;
	public static final int Model_Agents_CostsPerClientType_ClientType=622;
	public static final int Model_Agents_CostsPerClientType_ClientType_NoData=623;
	public static final int Model_Agents_CostsPerClientType_PerCall=624;
	public static final int Model_Agents_CostsPerClientType_PerCall_NoData=625;
	public static final int Model_Agents_CostsPerClientType_PerCall_Error=626;
	public static final int Model_Agents_CostsPerClientType_PerMinute=627;
	public static final int Model_Agents_CostsPerClientType_PerMinute_NoData=628;
	public static final int Model_Agents_CostsPerClientType_PerMinute_Error=629;
	public static final int Model_Agents_ModeError=630;

	public static final int Model_SkillLevel=701;
	public static final int Model_SkillLevel_Error=702;
	public static final int Model_SkillLevel_ClientType=703;
	public static final int Model_SkillLevel_HoldingTime=704;
	public static final int Model_SkillLevel_HoldingTime_Interval=705;
	public static final int Model_SkillLevel_PostProcessingTime=706;
	public static final int Model_SkillLevel_PostProcessingTime_Interval=707;
	public static final int Model_SkillLevel_Score=708;
	public static final int Model_SkillLevel_Score_Error=709;
	public static final int Model_SkillLevel_NoDataError=710;

	private final List<LanguageData> languages;
	private LanguageData selectedLanguage;

	private static Language instance;

	private Language() {
		languages=new ArrayList<Language.LanguageData>();
		languages.add(new English());
		languages.add(new German());
		selectedLanguage=languages.get(0);
	}

	private static Language getInstance() {
		if (instance==null) instance=new Language();
		return instance;
	}

	/**
	 * EN: Selects the language to be used<br>
	 * DE: W�hlt die Sprache, die verwendet werden soll
	 * @param languageID	<br>
	 * EN: ID of the language which should be used (see <code>LANGUAGE_*</code> consts).<br>
	 * DE: ID der Sprache, die verwendet werden soll (siehe <code>LANGUAGE_*</code>-Konstanten).
	 * @return
	 * EN: Returns <code>true</code>, if the selected language could be enabled.<br>
	 * DE: Gibt <code>true</code> zur�ck, wenn die gew�hlte Sprache aktiviert werden konnte.
	 */
	public static boolean select(int languageID) {
		final Language language=getInstance();
		for (final LanguageData lang : language.languages) if (lang.getID()==languageID) {
			language.selectedLanguage=lang;
			return true;
		}
		return false;
	}

	/**
	 * EN: Gets a string in the selected language<br>
	 * DE: Liefert eine Zeichenkette in der gew�hlten Sprache
	 * @param stringID	<br>
	 * EN: ID of the string to get<br>
	 * DE: ID der Zeichenkette, die geliefert werden soll
	 * @return
	 * EN: Returns the requested string or <code>null</code>, if there is not string for the specified ID.<br>
	 * DE: Liefert die angefragte Zeichenkette zur�ck oder <code>null</code>, wenn f�r die angegebene ID keine Zeichenkette vorhanden ist.
	 */
	public static String get(int stringID) {
		final Language language=getInstance();
		final LanguageData selected=language.selectedLanguage;
		if (selected==null) return null;
		return selected.getString(stringID);
	}

	/**
	 *
	 * @return
	 */
	public static Locale getLocale() {
		final Language language=getInstance();
		final LanguageData selected=language.selectedLanguage;
		if (selected==null) return Locale.getDefault();
		return selected.getLocalte();
	}

	private interface LanguageData {
		int getID();
		String getString(int stringID);
		Locale getLocalte();
	}

	private class English implements LanguageData {
		@Override
		public int getID() {
			return LANGUAGE_ENGLISH;
		}

		@Override
		public Locale getLocalte() {
			return Locale.ENGLISH;
		}

		@Override
		public String getString(int stringID) {
			switch (stringID) {
			case File_InputFileDoesNotExist : return "Input file %s does not exist.";
			case File_InputFileIsADirectory : return "Input file %s is a directory.";
			case File_LoadError : return "Cannot load input file %s.";

			case XML_DTD: return "CallcenterSimulator_en.dtd";
			case XML_XSD: return "CallcenterSimulator_en.xsd";
			case XML_WritingFailed: return "Writing failed.";
			case XML_ErrorCreatingXMLData: return "Error creating the XML data.";
			case XML_NoOutputFileSpecified: return "No ouput file was specified.";
			case XML_LoadErrorFile: return "Unable to load file %s.";
			case XML_LoadErrorStream: return "Unable to load the XML data.";
			case XML_Written: return "File successfully written.";
			case XML_DBWriteError: return "An error occured creating the data base.";
			case XML_DBReadError: return "An error occured reading from the data base.";

			case Distribution_Infinite: return "infinite";
			case Distribution_Point: return "One point distribution";
			case Distribution_Data: return "Empirical data";
			case Distribution_Exp: return "Exponential distribution";
			case Distribution_Normal: return "Normal distribution";
			case Distribution_LogNormal: return "Lognormal distribution";
			case Distribution_Gamma: return "Gamma distribution";
			case Distribution_Beta: return "Beta distribution";
			case Distribution_Cauchy: return "Cauchy distribution";
			case Distribution_Uniform: return "Uniform distribution";
			case Distribution_Erlang: return "Erlang distribution";
			case Distribution_F: return "F distribution";
			case Distribution_ChiSquare: return "Chi^2 distribution";
			case Distribution_Weibull: return "Weibull distribution";

			case CSV_InvalidStartCell: return "The specified starting cell \"%s\" is invalid.";
			case CSV_InvalidEndCell: return "The specified end cell \"%s\" is invalid.";
			case CSV_InvalidRange: return "The range specified by \"%s\" and \"%s\" has to be either a row or a column.";
			case CSV_CellNotInTable: return "The cell %s is after the end of the table. The table ends at cell %s.";
			case CSV_InvalidValue: return "The value of the cell %s \"%s\" is no valid number.";
			case CSV_ErrorInLine: return "Error in line %d : %s";

			case Model_Root: return "CallCenterModel";
			case Model_Root_Error: return "The root element is not \"CallCenterModel\".";
			case Model_General_Name: return "ModelName";
			case Model_General_Version: return "ModelSimulatorVersion";
			case Model_General_Description: return "ModelDescription";
			case Model_General_Date: return "ModelDate";
			case Model_General_MaxQueueLength: return "ModelMaxQueueLength";
			case Model_General_Days: return "ModelSimulatedDays";
			case Model_General_Days_Error: return "The number of days to be simulation has to be a positive integer number.";
			case Model_General_PreferredShiftLength: return "ModelPreferredShiftLength";
			case Model_General_PreferredShiftLength_Error: return "The preferred shift length has to be a positive integer number.";
			case Model_General_ServiceLevel: return "ModelServiceLevel";
			case Model_General_ServiceLevel_Error: return "The number of seconds for the service level has to be a positive integer number.";
			case Model_General_Efficiency: return "ModelProductivity";
			case Model_General_Surcharge: return "ModelDiseaseRelatedSurchage";
			case Model_General_Bool_False: return "false";
			case Model_General_Bool_Off: return "off";
			case Model_General_Bool_No: return "no";
			case Model_General_Bool_True: return "true";
			case Model_General_Bool_On: return "on";
			case Model_General_Bool_Yes: return "yes";
			case Model_General_Attribute_Name: return "Name";
			case Model_General_Attribute_Active: return "Active";
			case Model_General_Attribute_Probability: return "Probability";

			case Model_ClientType: return "ModelClientType";
			case Model_ClientType_Error: return "On loading client type %d.";
			case Model_ClientType_BlocksLine: return "BlocksLine";
			case Model_ClientType_ServiceLevel: return "ServiceLevel";
			case Model_ClientType_ServiceLevel_Error: return "The specified service level is invalid.";
			case Model_ClientType_FreshCalls: return "ClientsFreshCalls";
			case Model_ClientType_FreshCallsCount: return "FreshCallsCount";
			case Model_ClientType_FreshCallsCount_Error: return "The number of fresh calls has to be a non-negative integer number.";
			case Model_ClientType_FreshCallsStandardDeviation: return "StandardDeviation";
			case Model_ClientType_FreshCallsStandardDeviation_Error: return "The standard deviation for the number of fresh calls has to be a non-negative number.";
			case Model_ClientType_FreshCallsDistribution: return "FreshCallsDistribution";
			case Model_ClientType_FreshCallsDistribution_Error: return "The number of fresh calls per interval is invalid.";
			case Model_ClientType_ClientsScore: return "ClientsScore";
			case Model_ClientType_ClientsScore_Base: return "Base";
			case Model_ClientType_ClientsScore_Base_Error: return "The clients base score has to be a non-negative integer number.";
			case Model_ClientType_ClientsScore_Forwarding: return "Forwarding";
			case Model_ClientType_ClientsScore_Forwarding_Error: return "The client score on forwarding has to be a non-negative integer number.";
			case Model_ClientType_ClientsScore_PerWaitingSecond: return "PerWaitingSecond";
			case Model_ClientType_ClientsScore_PerWaitingSecond_Error: return "The client score per waiting second has to be a non-negative integer number.";
			case Model_ClientType_WaitingTimeTolerance_Short: return "ClientsWaitingTimeToleranceDistribution";
			case Model_ClientType_WaitingTimeTolerance_Short_Error: return "The specified waiting time tolerance distribution is invalid.";
			case Model_ClientType_WaitingTimeTolerance_Long: return "ClientsWaitingTimeToleranceDistributionLong";
			case Model_ClientType_WaitingTimeTolerance_Long_Error: return "The specified waiting time tolerance distribution is invalid.";
			case Model_ClientType_WaitingTimeTolerance_Estimation: return "ClientsWaitingTimeToleranceEstimation";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime: return "WaitingTime";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime_Missing: return "No average waiting time for the waiting time tolerance estimation was specified.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WaitingTime_Error: return "The specified average waiting time for the waiting time tolerance estimation is invalid.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate: return "CancelRate";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Missing: return "No cancel rate for the waiting time tolerance estimation was specified.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Error: return "The specified cancel rate for the waiting time tolerance estimation is invalid.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue: return "Correction";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue_Error: return "The specified correction value for the waiting time tolerance estimation is invalid.";
			case Model_ClientType_Retry: return "ClientsRetry";
			case Model_ClientType_Retry_Interval: return "RetryIntervalDistribution";
			case Model_ClientType_Retry_Interval_Error: return "The specified retry interval distribution is invalid.";
			case Model_ClientType_Retry_BlockedFirst: return "RetryProbabilityAfterBeingBlockedFirstRetry";
			case Model_ClientType_Retry_BlockedFirst_Error: return "The specified retry probability for the first retry after being blocked is invalid.";
			case Model_ClientType_Retry_BlockedFirst_ClientType: return "RetryClientTypeAfterBeingBlockedFirstRetry";
			case Model_ClientType_Retry_BlockedSecond: return "RetryProbabilityAfterBeingBlockedFurtherRetrys";
			case Model_ClientType_Retry_BlockedSecond_Error: return "The specified retry probability for the second, third etc. retry after being blocked is invalid.";
			case Model_ClientType_Retry_BlockedSecond_ClientType: return "RetryClientTypeAfterBeingBlockedFurtherRetrys";
			case Model_ClientType_Retry_WaitingFirst: return "RetryProbabilityAfterCanceledFirstRetry";
			case Model_ClientType_Retry_WaitingFirst_Error: return "The specified retry probability for the first retry after canceling is invalid.";
			case Model_ClientType_Retry_WaitingFirst_ClientType: return "RetryClientTypeAfterCanceledFirstRetry";
			case Model_ClientType_Retry_WaitingSecond: return "RetryProbabilityAfterCanceledFurtherRetrys";
			case Model_ClientType_Retry_WaitingSecond_Error: return "The specified retry probability for the second, third etc. retry after canceling is invalid.";
			case Model_ClientType_Retry_WaitingSecond_ClientType: return "RetryClientTypeAfterCanceledFurtherRetrys";
			case Model_ClientType_Retry_NewClientType: return "RetryNewClientType";
			case Model_ClientType_Retry_NewClientType_Error: return "The specified rate for client type \"%s\" is invalid.";
			case Model_ClientType_Forwarding: return "ClientsForwarding";
			case Model_ClientType_Forwarding_Error: return "The forwarding probability is invalid.";
			case Model_ClientType_Forwarding_NewClientType: return "ForwardingNewClientType";
			case Model_ClientType_Forwarding_NewClientType_Error: return "The specified rate for client type \"%s\" is invalid.";
			case Model_ClientType_Forwarding_Special: return "ForwardingSkillLevelDepending";
			case Model_ClientType_Forwarding_Special_Error: return "The forwarding probability is invalid.";
			case Model_ClientType_Forwarding_Special_SkillLevel: return "SkillLevel";
			case Model_ClientType_Forwarding_Special_NewClientType: return "ForwardingNewClientType";
			case Model_ClientType_Forwarding_Special_NewClientType_Error: return "The specified rate for client type \"%s\" is invalid.";
			case Model_ClientType_Recall: return "ClientsRecall";
			case Model_ClientType_Recall_Error: return "The recalling probability is invalid.";
			case Model_ClientType_Recall_Interval: return "RecallIntervalDistribution";
			case Model_ClientType_Recall_Interval_Error: return "The specified recall distribution is invalid.";
			case Model_ClientType_Recall_NewClientType: return "RecallNewClientType";
			case Model_ClientType_Recall_NewClientType_Error: return "The specified rate for client type \"%s\" is invalid.";
			case Model_ClientType_Recall_Special: return "RecallSkillLevelDepending";
			case Model_ClientType_Recall_Special_Error: return "The recalling probability is invalid.";
			case Model_ClientType_Recall_Special_SkillLevel: return "SkillLevel";
			case Model_ClientType_Recall_Special_NewClientType: return "RecallNewClientType";
			case Model_ClientType_Recall_Special_NewClientType_Error: return "The specified rate for client type \"%s\" is invalid.";
			case Model_ClientType_Yield: return "YieldPerClient";
			case Model_ClientType_Yield_Error: return "The specified yield per successful served client is invalid.";
			case Model_ClientType_Costs: return "CostPerCaller";
			case Model_ClientType_Costs_Cancel: return "Canceling";
			case Model_ClientType_Costs_Cancel_Error: return "The specified costs per canceled caller are invalid.";
			case Model_ClientType_Costs_Waiting: return "WaitingSecond";
			case Model_ClientType_Costs_Waiting_Error: return "The specified costs per waiting second are invalid.";

			case Model_CallCenter: return "ModelCallCenter";
			case Model_CallCenter_Error: return "On loading call center %s.";
			case Model_CallCenter_TechnicalFreeTime: return "CallCenterTechnicalFreeTime";
			case Model_CallCenter_TechnicalFreeTime_Error: return "The specified technical free time has to be a non-negative integer value.";
			case Model_CallCenter_CallCenterScore: return "CallCenterScore";
			case Model_CallCenter_CallCenterScore_Error: return "The specified call center score has to be a non-negative integer number.";
			case Model_CallCenter_AgentsScore: return "CallCenterAgentsScore";
			case Model_CallCenter_AgentsScore_LastCall: return "AgentsScoreFactorSinceLastCall";
			case Model_CallCenter_AgentsScore_LastCall_Error: return "The specified factor for respecting the free time since the last call of an agent for calculating the agents score is invalid.";
			case Model_CallCenter_AgentsScore_Part: return "AgentsScoreFactorFreeTimePart";
			case Model_CallCenter_AgentsScore_Part_Error: return "The specified factor for respecting the free time part an agent for calculating the agents score is invalid.";
			case Model_CallCenter_MinimumWaitingTime: return "CallCenterMinimumWaitingTime";
			case Model_CallCenter_MinimumWaitingTime_ClientType: return "MinimumWaitingTimeClientType";
			case Model_CallCenter_MinimumWaitingTime_ClientType_Error: return "The specified minimum waiting time has to be a non-negative integer number.";

			case Model_Agents: return "CallCenterAgentsGroup";
			case Model_Agents_Error: return "On loading agents group %s.";
			case Model_Agents_Count: return "AgentsGroupCount";
			case Model_Agents_Count_Error: return "The number of agents has to be a non-negative integer number.";
			case Model_Agents_WorkingStart: return "AgentsGroupWorkingTimeBegin";
			case Model_Agents_WorkingStart_Error: return "The specified working time start is invalid.";
			case Model_Agents_WorkingEnd: return "AgentsGroupWorkingTimeEnd";
			case Model_Agents_WorkingEnd_Error: return "The specified working time end is invalid.";
			case Model_Agents_Distribution: return "AgentsGroupDistribution";
			case Model_Agents_Distribution_Error: return "The number of agents per interval is invalid.";
			case Model_Agents_Distribution_LastShiftOpenEnd: return "LastShiftIsOpenEnd";
			case Model_Agents_ByClients: return "AgentsGroupByClientArrivals";
			case Model_Agents_ByClients_WorkingHalfHours: return "AgentsHalfHours";
			case Model_Agents_ByClients_WorkingHalfHours_Error: return "The specified number of available agents half-hours is invalid.";
			case Model_Agents_ByClients_ClientType: return "ByClientArrivalsGroup";
			case Model_Agents_ByClients_ClientType_Rate: return "Rate";
			case Model_Agents_ByClients_ClientType_Rate_Error: return "The specified rate for the calculation of the agents distribution from the client arrivals is invalid.";
			case Model_Agents_SkillLevel: return "AgentsGroupSkillLevel";
			case Model_Agents_CostsPerHour: return "CostsPerHour";
			case Model_Agents_CostsPerHour_Error: return "The specified costs per agents working hour are invalid.";
			case Model_Agents_CostsPerClientType: return "CostsPerClientType";
			case Model_Agents_CostsPerClientType_ClientType: return "ClientType";
			case Model_Agents_CostsPerClientType_ClientType_NoData: return "On a cost per client type node there is no client type specified.";
			case Model_Agents_CostsPerClientType_PerCall: return "PerCall";
			case Model_Agents_CostsPerClientType_PerCall_NoData: return "On there are no costs per call specified.";
			case Model_Agents_CostsPerClientType_PerCall_Error: return "The specified costs per call are invalid.";
			case Model_Agents_CostsPerClientType_PerMinute: return "PerMinute";
			case Model_Agents_CostsPerClientType_PerMinute_NoData: return "On the costs per client type node there are no costs per minute specified.";
			case Model_Agents_CostsPerClientType_PerMinute_Error: return "The specified costs per minute are invalid.";
			case Model_Agents_ModeError: return "You have to specify either a number or a distribution of agents over the day or a list of client types to be used for calculating the distribution over the day.";

			case Model_SkillLevel: return "ModellSkillLevel";
			case Model_SkillLevel_Error: return "On loading skill level %d.";
			case Model_SkillLevel_ClientType: return "SkillLevelClientType";
			case Model_SkillLevel_HoldingTime: return "SkillLevelClientTypeHoldingTimeDistribution";
			case Model_SkillLevel_HoldingTime_Interval: return "Interval";
			case Model_SkillLevel_PostProcessingTime: return "SkillLevelClientTypePostProcessingTimeDistribution";
			case Model_SkillLevel_PostProcessingTime_Interval: return "Interval";
			case Model_SkillLevel_Score: return "SkillLevelClientTypeScore";
			case Model_SkillLevel_Score_Error: return "The specified score for client type has to be a non-negative integer number.";
			case Model_SkillLevel_NoDataError: return "For client type %d no holding and post processing times have been specified.";
			}
			return null;
		}
	}

	private class German implements LanguageData {
		@Override
		public int getID() {
			return LANGUAGE_GERMAN;
		}

		@Override
		public Locale getLocalte() {
			return Locale.GERMAN;
		}

		@Override
		public String getString(int stringID) {
			switch (stringID) {
			case File_InputFileDoesNotExist : return "Die Eingabedatei %s existiert nicht.";
			case File_InputFileIsADirectory : return "Die angegebene Eingabedatei %s ist ein Verzeichnis.";
			case File_LoadError : return "Die Eingabedatei %s kann nicht geladen werden.";

			case XML_DTD: return "CallcenterSimulator_de.dtd";
			case XML_XSD: return "CallcenterSimulator_de.xsd";
			case XML_WritingFailed: return "Speichern fehlgeschlagen.";
			case XML_ErrorCreatingXMLData: return "Fehler beim Erstellen der XML-Daten.";
			case XML_NoOutputFileSpecified: return "Es wurde keine Ausgabedatei angegeben.";
			case XML_LoadErrorFile: return "Die Datei %s konnte nicht geladen werden.";
			case XML_LoadErrorStream: return "Die XML-Daten konnten nicht geladen werden.";
			case XML_Written: return "Datei erfolgreich geschrieben.";
			case XML_DBWriteError: return "Es ist ein Fehler beim Erstellen der Datenbank aufgetreten.";
			case XML_DBReadError: return "Es ist ein Fehler beim Laden der Daten aus der Datenbank aufgetreten.";

			case Distribution_Infinite: return "unendlich";
			case Distribution_Point: return "Ein-Punkt-Verteilung";
			case Distribution_Data: return "Empirische Daten";
			case Distribution_Exp: return "Exponentialverteilung";
			case Distribution_Normal: return "Normalverteilung";
			case Distribution_LogNormal: return "Lognormalverteilung";
			case Distribution_Gamma: return "Gamma-Verteilung";
			case Distribution_Beta: return "Beta-Verteilung";
			case Distribution_Cauchy: return "Cauchy-Verteilung";
			case Distribution_Uniform: return "Gleichverteilung";
			case Distribution_Erlang: return "Erlang-Verteilung";
			case Distribution_F: return "F-Verteilung";
			case Distribution_ChiSquare: return "Chi^2-Verteilung";
			case Distribution_Weibull: return "Weibull-Verteilung";

			case CSV_InvalidStartCell: return "Die angegebene Startzelle \"%s\" ist ung�ltig.";
			case CSV_InvalidEndCell: return "Die angegebene Endzelle \"%s\" ist ung�ltig.";
			case CSV_InvalidRange: return "Der durch \"%s\" und \"%s\" eingegrenzte Bereich muss entweder eine Zeile oder eine Spalte sein.";
			case CSV_CellNotInTable: return "Die Zelle %s liegt au�erhalb der Tabelle. Die Tabelle geht nur bis %s.";
			case CSV_InvalidValue: return "Der Wert der Zelle %s \"%s\" ist keine g�ltige Zahl.";
			case CSV_ErrorInLine: return "Fehler in Zeile %d : %s";

			case Model_Root: return "CallcenterModell";
			case Model_Root_Error: return "Das Basiselement hei�t nicht \"CallcenterModell\".";
			case Model_General_Name: return "ModellName";
			case Model_General_Version: return "ModellSimulatorVersion";
			case Model_General_Description: return "ModellBeschreibung";
			case Model_General_Date: return "ModellDatum";
			case Model_General_MaxQueueLength: return "ModellMaxWarteschlangenLaenge";
			case Model_General_Days: return "ModellSimulierteTage";
			case Model_General_Days_Error: return "Die Anzahl an zu simulierenden Tagen muss eine nat�rliche Zahl sein.";
			case Model_General_PreferredShiftLength: return "ModellBevorzugteSchichtlaenge";
			case Model_General_PreferredShiftLength_Error: return "Die bevorzugte Schichtl�nge muss eine nat�rliche Zahl sein.";
			case Model_General_ServiceLevel: return "ModellServiceLevel";
			case Model_General_ServiceLevel_Error: return "Die Anzahl an Sekunden f�r den Service-Level muss eine nat�rliche Zahl sein.";
			case Model_General_Efficiency: return "ModellProduktivitaet";
			case Model_General_Surcharge: return "ModellPlanungsaufschlag";
			case Model_General_Bool_False: return "falsch";
			case Model_General_Bool_Off: return "aus";
			case Model_General_Bool_No: return "nein";
			case Model_General_Bool_True: return "wahr";
			case Model_General_Bool_On: return "an";
			case Model_General_Bool_Yes: return "ja";
			case Model_General_Attribute_Name: return "Name";
			case Model_General_Attribute_Active: return "Aktiv";
			case Model_General_Attribute_Probability: return "Wahrscheinlichkeit";

			case Model_ClientType: return "ModellKundentyp";
			case Model_ClientType_Error: return "Beim Laden des %d. Kundentyps.";
			case Model_ClientType_BlocksLine: return "BelegtLeitung";
			case Model_ClientType_ServiceLevel: return "ServiceLevel";
			case Model_ClientType_ServiceLevel_Error: return "Der angegebene Service-Level ist ung�ltig.";
			case Model_ClientType_FreshCalls: return "KundenErstanrufer";
			case Model_ClientType_FreshCallsCount: return "ErstanruferAnzahl";
			case Model_ClientType_FreshCallsCount_Error: return "Die Anzahl an Erstanrufern muss eine nichtnegative Ganzzahl sein.";
			case Model_ClientType_FreshCallsStandardDeviation: return "Standardabweichung";
			case Model_ClientType_FreshCallsStandardDeviation_Error: return "Die Standardabweichung der Anzahl an Erstanrufern muss eine nichtnegative Zahl sein.";
			case Model_ClientType_FreshCallsDistribution: return "ErstanruferVerteilung";
			case Model_ClientType_FreshCallsDistribution_Error: return "Die Anzahl an Erstanrufern pro Intervall ist ung�ltig.";
			case Model_ClientType_ClientsScore: return "KundenScore";
			case Model_ClientType_ClientsScore_Base: return "Basis";
			case Model_ClientType_ClientsScore_Base_Error: return "Der Kunden-Basisscore muss eine nichtnegative Ganzzahl sein.";
			case Model_ClientType_ClientsScore_Forwarding: return "Weiterleitung";
			case Model_ClientType_ClientsScore_Forwarding_Error: return "Der Kunden-Score bei Weiterleitungen muss eine nichtnegative Ganzzahl sein.";
			case Model_ClientType_ClientsScore_PerWaitingSecond: return "ProWartesekunde";
			case Model_ClientType_ClientsScore_PerWaitingSecond_Error: return "Der Kunden-Score pro Wartesekunde muss eine nichtnegative Ganzzahl sein.";
			case Model_ClientType_WaitingTimeTolerance_Short: return "KundenWartezeittoleranzVerteilung";
			case Model_ClientType_WaitingTimeTolerance_Short_Error: return "Die angegebene Wartezeittoleranz-Verteilung ist ung�ltig.";
			case Model_ClientType_WaitingTimeTolerance_Long: return "KundenWartezeittoleranzVerteilungLang";
			case Model_ClientType_WaitingTimeTolerance_Long_Error: return "Die angegebene Wartezeittoleranz-Verteilung ist ung�ltig.";
			case Model_ClientType_WaitingTimeTolerance_Estimation: return "KundenWartezeittoleranzSchaetzung";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime: return "Wartezeit";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WatingTime_Missing: return "Es wurde keine mittlere Wartezeit f�r die Wartezeittoleranz-Sch�tzung angegeben.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_WaitingTime_Error: return "Die angegebene mittlere Wartezeit f�r die Wartezeittoleranz-Sch�tzung ist ung�ltig.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate: return "Abbruchwahrscheinlichkeit";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Missing: return "Es wurde keine Abbruchwahrscheinlichkeit f�r die Wartezeittoleranz-Sch�tzung angegeben.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CancelationRate_Error: return "Die angegebene Abbruchwahrscheinlichkeit f�r die Wartezeittoleranz-Sch�tzung ist ung�ltig.";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue: return "Korrekturwert";
			case Model_ClientType_WaitingTimeTolerance_Estimation_CorrectionValue_Error: return "Der angegebene Korrekturwert f�r die Wartezeittoleranz-Sch�tzung ist ung�ltig.";
			case Model_ClientType_Retry: return "KundenWiederholungen";
			case Model_ClientType_Retry_Interval: return "WiederholungenAbstaendeVerteilung";
			case Model_ClientType_Retry_Interval_Error: return "Die angegebene Wiederholabst�nde-Verteilung ist ung�ltig.";
			case Model_ClientType_Retry_BlockedFirst: return "WiederholungenWahrscheinlichkeitNachBlockierungErsterVersuch";
			case Model_ClientType_Retry_BlockedFirst_Error: return "Die angegebene Wiederholwahrscheinlichkeit im ersten Versuch nach einer Blockierung ist ung�ltig.";
			case Model_ClientType_Retry_BlockedFirst_ClientType: return "WiederholungenKundentypNachBlockierungErsterVersuch";
			case Model_ClientType_Retry_BlockedSecond: return "WiederholungenWahrscheinlichkeitNachBlockierungWeitereVersuche";
			case Model_ClientType_Retry_BlockedSecond_Error: return "Die angegebene Wiederholwahrscheinlichkeit ab dem zweiten Versuch nach einer Blockierung ist ung�ltig.";
			case Model_ClientType_Retry_BlockedSecond_ClientType: return "WiederholungenKundentypNachBlockierungWeitereVersuche";
			case Model_ClientType_Retry_WaitingFirst: return "WiederholungenWahrscheinlichkeitNachAbbruchErsterVersuch";
			case Model_ClientType_Retry_WaitingFirst_Error: return "Die angegebene Wiederholwahrscheinlichkeit im ersten Versuch nach einem Warteabbruch ist ung�ltig.";
			case Model_ClientType_Retry_WaitingFirst_ClientType: return "WiederholungenKundentypNachAbbruchErsterVersuch";
			case Model_ClientType_Retry_WaitingSecond: return "WiederholungenWahrscheinlichkeitNachAbbruchWeitereVersuche";
			case Model_ClientType_Retry_WaitingSecond_Error: return "Die angegebene Wiederholwahrscheinlichkeit ab dem zweiten Versuch nach einem Warteabbruch ist ung�ltig.";
			case Model_ClientType_Retry_WaitingSecond_ClientType: return "WiederholungenKundentypNachAbbruchWeitereVersuche";
			case Model_ClientType_Retry_NewClientType: return "WiederholungenNeuerKundentyp";
			case Model_ClientType_Retry_NewClientType_Error: return "Die angegebene Rate f�r den Kundentyp \"%s\" ist ung�ltig.";
			case Model_ClientType_Forwarding: return "KundenWeiterleitungen";
			case Model_ClientType_Forwarding_Error: return "Die Weiterleitungswahrscheinlichkeit ist ung�ltig.";
			case Model_ClientType_Forwarding_NewClientType: return "WeiterleitungenNeuerKundentyp";
			case Model_ClientType_Forwarding_NewClientType_Error: return "Die angegebene Rate f�r den Kundentyp \"%s\" ist ung�ltig.";
			case Model_ClientType_Forwarding_Special: return "WeiterleitungenSkillLevelSpezifisch";
			case Model_ClientType_Forwarding_Special_Error: return "Die Weiterleitungswahrscheinlichkeit ist ung�ltig.";
			case Model_ClientType_Forwarding_Special_SkillLevel: return "SkillLevel";
			case Model_ClientType_Forwarding_Special_NewClientType: return "WeiterleitungenNeuerKundentyp";
			case Model_ClientType_Forwarding_Special_NewClientType_Error: return "Die angegebene Rate f�r den Kundentyp \"%s\" ist ung�ltig.";
			case Model_ClientType_Recall: return "KundenWiederanrufer";
			case Model_ClientType_Recall_Error: return "Die Wiederanrufwahrscheinlichkeit ist ung�ltig.";
			case Model_ClientType_Recall_Interval: return "WiederanrufAbstaendeVerteilung";
			case Model_ClientType_Recall_Interval_Error: return "Die angegebene Wiederanruf-Verteilung ist ung�ltig.";
			case Model_ClientType_Recall_NewClientType: return "WiederanrufNeuerKundentyp";
			case Model_ClientType_Recall_NewClientType_Error: return "Die angegebene Rate f�r den Kundentyp \"%s\" ist ung�ltig.";
			case Model_ClientType_Recall_Special: return "WeiterleitungenSkillLevelSpezifisch";
			case Model_ClientType_Recall_Special_Error: return "Die Wiederanrufwahrscheinlichkeit ist ung�ltig.";
			case Model_ClientType_Recall_Special_SkillLevel: return "SkillLevel";
			case Model_ClientType_Recall_Special_NewClientType: return "WiederanrufNeuerKundentyp";
			case Model_ClientType_Recall_Special_NewClientType_Error: return "Die angegebene Rate f�r den Kundentyp \"%s\" ist ung�ltig.";
			case Model_ClientType_Yield: return "GewinnProKunde";
			case Model_ClientType_Yield_Error: return "Der angegebene Gewinn pro erfolgreich bedientem Kunden ist ung�ltig.";
			case Model_ClientType_Costs: return "KostenProAnrufer";
			case Model_ClientType_Costs_Cancel: return "Abbruch";
			case Model_ClientType_Costs_Cancel_Error: return "Die angegebenen Kosten pro Warteabbruch sind ung�ltig.";
			case Model_ClientType_Costs_Waiting: return "Wartesekunde";
			case Model_ClientType_Costs_Waiting_Error: return "Die angegebenen Kosten pro Wartesekunde sind ung�ltig.";

			case Model_CallCenter: return "ModellCallcenter";
			case Model_CallCenter_Error: return "Beim Laden des %s. Callcenters.";
			case Model_CallCenter_TechnicalFreeTime: return "CallcenterTechnischeBereitzeit";
			case Model_CallCenter_TechnicalFreeTime_Error: return "Die technische Bereitzeit muss eine nichtnegative Ganzzahl sein.";
			case Model_CallCenter_CallCenterScore: return "CallcenterScore";
			case Model_CallCenter_CallCenterScore_Error: return "Die Callcenter-Score muss eine nichtnegative Ganzzahl sein.";
			case Model_CallCenter_AgentsScore: return "CallcenterAgentenScore";
			case Model_CallCenter_AgentsScore_LastCall: return "AgentenScoreFaktorSeitLetztemAnruf";
			case Model_CallCenter_AgentsScore_LastCall_Error: return "Der Faktor f�r die Agentenscore zur Ber�cksichtigung der freien Zeit seit dem letzten Anruf muss eine nichtnegative Zahl sein.";
			case Model_CallCenter_AgentsScore_Part: return "AgentenScoreFaktorLeerlaufAnteil";
			case Model_CallCenter_AgentsScore_Part_Error: return "Der Faktor f�r die Agentenscore zur Ber�cksichtigung des Leerlaufanteils muss eine nichtnegative Zahl sein.";
			case Model_CallCenter_MinimumWaitingTime: return "CallcenterMindestWartezeit";
			case Model_CallCenter_MinimumWaitingTime_ClientType: return "MindestWartezeitKundentyp";
			case Model_CallCenter_MinimumWaitingTime_ClientType_Error: return "Die Mindestwartezeiten m�ssen nichtnegative Ganzzahlen sein.";

			case Model_Agents: return "CallcenterAgentengruppe";
			case Model_Agents_Error: return "Beim Laden der %s. Agentengruppe.";
			case Model_Agents_Count: return "AgentengruppeAnzahl";
			case Model_Agents_Count_Error: return "Die Anzahl an Agenten muss eine nichtnegative Ganzzahl sein.";
			case Model_Agents_WorkingStart: return "AgentengruppeArbeitszeitbeginn";
			case Model_Agents_WorkingStart_Error: return "Der angegebene Arbeitszeitbeginn ist ung�ltig.";
			case Model_Agents_WorkingEnd: return "AgentengruppeArbeitszeitende";
			case Model_Agents_WorkingEnd_Error: return "Das angegebene Arbeitszeitende ist ung�ltig.";
			case Model_Agents_Distribution: return "AgentengruppeVerteilung";
			case Model_Agents_Distribution_Error: return "Die Agentenanzahl pro Intervall ist ung�ltig.";
			case Model_Agents_Distribution_LastShiftOpenEnd: return "SchichtBisMitternachtIstOpenEnd";
			case Model_Agents_ByClients: return "AgentengruppeNachKundenankuenften";
			case Model_Agents_ByClients_WorkingHalfHours: return "Agentenhalbstunden";
			case Model_Agents_ByClients_WorkingHalfHours_Error: return "Die angegebene Anzahl an verf�gbaren Agentenhalbstunden ist ung�ltig.";
			case Model_Agents_ByClients_ClientType: return "KundenankuenfteGruppe";
			case Model_Agents_ByClients_ClientType_Rate: return "Rate";
			case Model_Agents_ByClients_ClientType_Rate_Error: return "Die Rate f�r die Berechnung der Agentenverteilung aus den Kundenank�nften ist ung�ltig.";
			case Model_Agents_SkillLevel: return "AgentengruppeSkillLevel";
			case Model_Agents_CostsPerHour: return "KostenProStunde";
			case Model_Agents_CostsPerHour_Error: return "Die Kosten pro Agentenarbeitsstunde sind ung�ltig.";
			case Model_Agents_CostsPerClientType: return "KostenProKundengruppe";
			case Model_Agents_CostsPerClientType_ClientType: return "Kundentyp";
			case Model_Agents_CostsPerClientType_ClientType_NoData: return "Bei einem Kosten pro Kundengruppe Element ist kein Kundentyp angegeben.";
			case Model_Agents_CostsPerClientType_PerCall: return "ProAnruf";
			case Model_Agents_CostsPerClientType_PerCall_NoData: return "Bei einem Kosten pro Kundengruppe Element sind keine Kosten pro Anruf angegeben.";
			case Model_Agents_CostsPerClientType_PerCall_Error: return "Die angegebenen Kosten pro Anruf sind ung�ltig.";
			case Model_Agents_CostsPerClientType_PerMinute: return "ProMinute";
			case Model_Agents_CostsPerClientType_PerMinute_NoData: return "Bei einem Kosten pro Kundengruppe Element sind keine Kosten pro Minute angegeben.";
			case Model_Agents_CostsPerClientType_PerMinute_Error: return "Die angegebenen Kosten pro Minute sind ung�ltig.";
			case Model_Agents_ModeError: return "Es muss entweder eine Agentenanzahl oder eine Verteilung �ber den Tag oder eine Liste von Kundentypen als Basis f�r die Verteilung �ber den Tag angegeben werden.";

			case Model_SkillLevel: return "ModellSkillLevel";
			case Model_SkillLevel_Error: return "Beim Laden des %d. Skill-Levels.";
			case Model_SkillLevel_ClientType: return "SkillLevelKundentyp";
			case Model_SkillLevel_HoldingTime: return "SkillLevelKundentypBedienzeitverteilung";
			case Model_SkillLevel_HoldingTime_Interval: return "Intervall";
			case Model_SkillLevel_PostProcessingTime: return "SkillLevelKundentypNachbearbeitungszeitverteilung";
			case Model_SkillLevel_PostProcessingTime_Interval: return "Intervall";
			case Model_SkillLevel_Score: return "SkillLevelKundentypScore";
			case Model_SkillLevel_Score_Error: return "Die Score des %s. Kundentyps ist ung�ltig.";
			case Model_SkillLevel_NoDataError: return "F�r den %d. Kundentyp wurde keine Bedienzeit- oder keine Nachbearbeitungszeitverteilung angegeben.";
			}
			return null;
		}
	}
}
