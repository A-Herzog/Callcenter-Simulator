package CallcenterDataModel.Tools;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Tools for writing strings to text files
 * @author Alexander Herzog
 *
 */
public class TextFile {
	/**
	 * Writes a string to a text file
	 * @param text	String to be written
	 * @param outputFile	Text file in which the string is to be written.
	 * @return	Returns <code>null</code> on success. Otherwise returns an error message.
	 */
	public static String save(String text, File outputFile) {
		try (BufferedWriter writer=new BufferedWriter(new FileWriter(outputFile))) {writer.write(text);} catch (final IOException e) {return String.format("Error writing to results file %s",outputFile.toString());}
		return null;
	}

	/**
	 * Writes an array of strings as lines to a text file
	 * @param text	Array of strings to be written
	 * @param outputFile	Text file in which the array is to be written as lines.
	 * @return	Returns <code>null</code> on success. Otherwise returns an error message.
	 */
	public static String save(String[] text, File outputFile) {
		final StringBuilder sb=new StringBuilder();
		for (final String line: text) sb.append(line+"\n");
		return save(sb.toString(),outputFile);
	}

	private TextFile() {}
}
