package CallcenterDataModel.Tools;

import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

/**
 * EN: Tools for converting numbers in strings an vice versa<br>
 * DE: Hilfsmittel zum Umwandeln von Zahlen in Zeichenketten und umgekehrt
 * @author Alexander Herzog
 */
public class Numbers {
	private Numbers() {}

	/**
	 * EN: Convers a time given as a seconds double value to a string. The time value can be negative and can have a fraction part. (As decimal separator a point is used.)<br>
	 * DE: Wandelt eine als Sekunden-Double-Wert gegebene Uhrzeit in eine Zeichenkette um. Die Zeitangabe kann dabei auch negativ sein und Nachkommastellen enthalten. (Als Dezimaltrenner wird ein Punkt verwendet.)	 *
	 * @param time	<br>
	 * EN: Time value to be converted<br>
	 * DE: Umzuwandelnde Uhrzeit
	 * @return
	 * EN: Time as string<br>
	 * DE: Uhrzeit als Zeichenkette
	 * @see formatExactTime
	 */
	public static final String formatExactSystemTime(double time) {
		String s="";
		if (time<0) {s="-"; time=-time;}

		int intTime=(int)Math.round(Math.floor(time));
		s=s+String.format("%02d:%02d:%02d",intTime/3600,intTime/60%60,intTime%60);

		time-=Math.floor(time);
		if (time>=1.0/1000) s=s+"."+Math.round(Math.floor(time*1000));

		return s;
	}

	/**
	 * EN: Converts a floating point number to a system string, this means without respecting local repesentation forms<br>
	 * DE: Wandelt eine Flie�kommazahl in eine System-Zeichenkette um, d.h. ohne Ber�cksichtigung lokaler Darstellungsformen
	 * @param d	<br>
	 * EN: Number to be converted<br>
	 * DE: Umzuwandelnde Zahl
	 * @return
	 * EN: Number as string<br>
	 * DE: Zahl als Zeichenkette
	 */
	public static final String formatSystemNumber(final double d) {
		String s=((Double)d).toString();
		while (((s.contains(",")) || (s.contains("."))) && (s.endsWith("0"))) {s=s.substring(0,s.length()-1);}
		if ((s.endsWith(".")) || (s.endsWith(","))) s=s.substring(0,s.length()-1);
		return s;
	}

	/**
	 * EN: Converts a time value given as a seconds integer value to a string<br>
	 * DE: Wandelt eine als Sekunden-Integer-Wert gegebene Uhrzeit in eine Zeichenkette um
	 * @param time	<br>
	 * EN: Time to be converted<br>
	 * DE: Umzuwandelnde Uhrzeit
	 * @return
	 * EN: Time as string<br>
	 * DE: Uhrzeit als Zeichenkette
	 */
	public static final String formatTime(final long time) {
		return String.format("%02d:%02d:%02d",time/3600,time/60%60,time%60);
	}

	/**
	 * EN: Trys to convert a string to a seconds based time including signs and faction parts.<br>
	 * DE: Versucht die �bergebenen Zeichenkette in eine sekundenbasierende Zeitangabe inkl. Vorzeichen und Nachkommastellen umzuwandeln.
	 * @param s	<br>
	 * EN: String containing the time to be converted<br>
	 * DE: Zeichenkette, die den umzuwandelnden Zeitwert enth�lt
	 * @return
	 * EN: Time value in seconds as <code>Double</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zeit in Sekunden als <code>Double</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public static final Double getExactTime(String s) {
		if (s==null || s.isEmpty()) return null;
		boolean negative=false;

		if (s.substring(0,1).equals("-")) {negative=true; s=s.substring(1);}

		int i1=s.indexOf('.'), i2=s.indexOf(','), i=-1;
		if (i1>=0 || i2>=0) {if (i1<0) i=i2; else {if (i2<0) i=i1; else i=Math.min(i1,i2);}}
		double frac=0;
		if (i>=0) {
			DecimalFormatSymbols format=new DecimalFormatSymbols();
			Double f=null;
			String t="0"+format.getDecimalSeparator()+s.substring(i+1);
			try {
				Number n=NumberFormat.getInstance().parse(t);
				f=n.doubleValue();
			} catch (ParseException e) {f=null;}
			if (f==null) return null;
			frac=f;	s=s.substring(0,i-1);
		}

		Integer time=Numbers.getTime(s);
		if (time==null) return null;

		double t=time+frac;
		if (negative) t=-t;
		return t;
	}

	/**
	 * EN: Trys to convert a string to an <code>Integer</code> number.<br>
	 * DE: Versucht die �bergebene Zeichenkette in eine <code>Integer</code>-Zahl umzuwandeln.
	 * @param s	<br>
	 * EN: String containing the number to be converted<br>
	 * DE: Zeichenkette, die die umzuwandelnde Zahl enth�lt
	 * @return
	 * EN: Number a <code>Integer</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zahl als <code>Integer</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public static final Integer getInteger(final String s) {
		if (s==null) return null;
		try {
			double d=Double.parseDouble(s);
			if ((Math.round(d)!=d)) return null;
			return ((int)Math.round(d));
		} catch (NumberFormatException e) {return null;}
	}

	/**
	 * EN: Trys to convert a string to an <code>Integer</code> number, but accepts only non-negative values.<br>
	 * DE: Versucht die �bergebene Zeichenkette in eine <code>Integer</code>-Zahl umzuwandeln, akzeptiert dabei jedoch nur nichtnegative Werte.
	 * @param s	<br>
	 * EN: String containing the number to be converted<br>
	 * DE: Zeichenkette, die die umzuwandelnde Zahl enth�lt
	 * @return
	 * EN: Number a <code>Integer</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zahl als <code>Integer</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public static final Integer getNotNegativeInteger(final String s) {
		if (s==null) return null;
		try {
			double d=Double.parseDouble(s);
			if ((Math.round(d)!=d)) return null;
			if (d<0) return null;
			return ((int)Math.round(d));
		} catch (NumberFormatException e) {return null;}
	}

	/**
	 * EN: Trys to convert a string to an <code>Double</code> number, but accepts only non-negative values. (As decimal separator locale indepentend a point is expected.)<br>
	 * DE: Versucht den �bergebenen String in eine <code>Double</code>-Zahl umzuwandeln, akzeptiert dabei jedoch nur nicht negative Werte. (Als Dezimaltrenner wird landestyp-unabh�ngig ein Punkt erwartet.)
	 * @param s	<br>
	 * EN: String containing the number to be converted<br>
	 * DE: Zeichenkette, die die umzuwandelnde Zahl enth�lt
	 * @return
	 * EN: Number a <code>Double</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zahl als <code>Double</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public final static Double getNotNegativeSystemDouble(String s) {
		s=XML.systemNumberToLocalNumber(s);
		if (s==null) return null;
		try {
			boolean percent=false;
			if (s!=null && !s.isEmpty() && s.charAt(s.length()-1)=='%') {
				percent=true;
				s=s.substring(0,s.length()-1);
				if (!s.isEmpty() && s.charAt(s.length()-1)==' ') s=s.substring(0,s.length()-1);
			}
			Number n=NumberFormat.getInstance().parse(s);
			double d=n.doubleValue();
			if (d<0) return null;
			if (percent) d/=100;
			return d;
		} catch (ParseException e) {return null;}
	}

	/**
	 * EN: Trys to convert a string to an <code>Double</code> number. (As decimal separator locale indepentend a point is expected.)<br>
	 * DE: Versucht den �bergebenen String in eine <code>Double</code>-Zahl umzuwandeln. (Als Dezimaltrenner wird landestyp-unabh�ngig ein Punkt erwartet.)
	 * @param s	<br>
	 * EN: String containing the number to be converted<br>
	 * DE: Zeichenkette, die die umzuwandelnde Zahl enth�lt
	 * @return
	 * EN: Number a <code>Double</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zahl als <code>Double</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public final static Double getSystemDouble(String s) {
		s=XML.systemNumberToLocalNumber(s);
		if (s==null) return null;
		try {
			boolean percent=false;
			if (s!=null && !s.isEmpty() && s.charAt(s.length()-1)=='%') {
				percent=true;
				s=s.substring(0,s.length()-1);
				if (!s.isEmpty() && s.charAt(s.length()-1)==' ') s=s.substring(0,s.length()-1);
			}
			Number n=NumberFormat.getInstance().parse(s);
			double d=n.doubleValue();
			if (percent) d/=100;
			return d;
		} catch (ParseException e) {return null;}
	}

	/**
	 * EN: Trys to convert a string to an <code>Double</code> number, but accepts only values in the range 0 to 1. (As decimal separator locale indepentend a point is expected.)<br>
	 * DE: Versucht den �bergebenen String in eine <code>Double</code>-Zahl umzuwandeln, akzeptiert dabei jedoch nur Werte im Bereich von 0 bis 1. (Als Dezimaltrenner wird landestyp-unabh�ngig ein Punkt erwartet.)
	 * @param s	<br>
	 * EN: String containing the number to be converted<br>
	 * DE: Zeichenkette, die die umzuwandelnde Zahl enth�lt
	 * @return
	 * EN: Number a <code>Double</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zahl als <code>Double</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public static final Double getSystemProbability(String s) {
		if (s==null) return null;
		try {
			boolean percent=false;
			if (s!=null && !s.isEmpty() && s.charAt(s.length()-1)=='%') {
				percent=true;
				s=s.substring(0,s.length()-1);
				if (!s.isEmpty() && s.charAt(s.length()-1)==' ') s=s.substring(0,s.length()-1);
			}
			double d=(s==null)?-1:(Double.parseDouble(s));
			if (percent) d/=100;
			if ((d<0) || (d>1)) return null;
			return d;
		} catch (NumberFormatException e) {return null;}
	}

	/**
	 * EN: Trys to convert a string to a seconds based time value.<br>
	 * DE: Versucht die �bergebene Zeichenkette in eine sekundenbasierende Zeitangabe umzuwandeln.
	 * @param s	<br>
	 * EN: String containing the time value to be converted<br>
	 * DE: Zeichenkette, die den umzuwandelnden Zeitwert enth�lt
	 * @return
	 * EN: Time in seconds as <code>Integer</code>; if converting fails, <code>null</code> will be returned.<br>
	 * DE: Zeit in Sekunden als <code>Integer</code>; wenn die Umwandlung fehlschl�gt, wird <code>null</code> zur�ckgegeben.
	 */
	public static final Integer getTime(final String s) {
		String[] l=s.split(":");
		if (l.length!=3) return null;

		int result=0;
		for (int i=0;i<3;i++) {
			if (l[i].startsWith("0")) l[i]=l[i].substring(1);
			if (l[i].isEmpty()) l[i]="0";
			Integer v=getInteger(l[i]);
			if (v==null) return null;
			result*=60;
			result+=v;
		}
		return result;
	}
}
