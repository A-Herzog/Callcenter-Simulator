package CallcenterDataModel.Tools;

import java.util.List;

/**
 * EN: This class contains helper functions for filling the distribution field in the model components.<br>
 * DE: Diese Klasse enth�lt Hilfsfunktionen zum Ausf�llen der Verteilungsfelder der einzelnen Modellkomponenten.
 * @author Alexander Herzog
 */
public final class Distribution {
	private Distribution() {}

	/**
	 * EN: Sums up a row of numerical values.<br>
	 * DE: Summiert eine Reihe von Zahlenwerten auf.
	 * @param values	<br>
	 * EN: Values to be summed up.<br>
	 * DE: Zu summierende Werte.
	 * @return
	 * EN: Sum<br>
	 * DE: Summe
	 */
	public final static int sum(final int[] values) {
		int sum=0; for (int i: values) sum+=i;
		return sum;
	}

	/**
	 * EN: Sums up a row of numerical values.<br>
	 * DE: Summiert eine Reihe von Zahlenwerten auf.
	 * @param values	<br>
	 * EN: Values to be summed up.<br>
	 * DE: Zu summierende Werte.
	 * @return
	 * EN: Sum<br>
	 * DE: Summe
	 */
	public final static double sum(final double[] values) {
		double sum=0; for (double d: values) sum+=d;
		return sum;
	}

	/**
	 * EN: Sums up a row of numerical values.<br>
	 * DE: Summiert eine Reihe von Zahlenwerten auf.
	 * @param values	<br>
	 * EN: Values to be summed up.<br>
	 * DE: Zu summierende Werte.
	 * @return
	 * EN: Sum<br>
	 * DE: Summe
	 */
	public final static int sumInteger(final List<Integer> values) {
		int sum=0; for (Integer d: values) sum+=d;
		return sum;
	}

	/**
	 * EN: Sums up a row of numerical values.<br>
	 * DE: Summiert eine Reihe von Zahlenwerten auf.
	 * @param values	<br>
	 * EN: Values to be summed up.<br>
	 * DE: Zu summierende Werte.
	 * @return
	 * EN: Sum<br>
	 * DE: Summe
	 */
	public final static double sumDouble(final List<Double> values) {
		double sum=0; for (Double d: values) sum+=d;
		return sum;
	}

	/**
	 * EN: Create a list separated by ";" from the given strings array. (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Bildet aus dem �bergebenen Array aus Zeichenketten eine durch ";" getrennte Liste. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the strings<br>
	 * DE: Liste mit Zeichenketten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getData(final String[] values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.length;i++) {if (i>0) sb.append(";"); sb.append(values[i]);}
		return sb.toString();
	}

	/**
	 * EN: Create a list separated by ";" from the given strings array. (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Bildet aus dem �bergebenen Array aus Zeichenketten eine durch ";" getrennte Liste. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the strings<br>
	 * DE: Liste mit Zeichenketten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getData(final int[] values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.length;i++) {if (i>0) sb.append(";"); sb.append(""+values[i]);}
		return sb.toString();
	}

	/**
	 * EN: Create a list separated by ";" from the given strings array. (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Bildet aus dem �bergebenen Array aus Zeichenketten eine durch ";" getrennte Liste. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the strings<br>
	 * DE: Liste mit Zeichenketten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getData(final double[] values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.length;i++) {if (i>0) sb.append(";"); sb.append(Numbers.formatSystemNumber(values[i]));}
		return sb.toString();
	}

	/**
	 * EN: Creates a string containing a list of values separated by ";". In this list the given numerical value will be repeated as specified.<br>
	 * DE: Erzeugt eine Zeichenkette, die eine Liste mit ";" als Trennzeichen enth�lt. In dieser Liste wird die angegebe Zahl so h�ufig wie angegeben wiederholt.
	 * @param value	<br>
	 * EN: Numerical value to be repeated<br>
	 * DE: Zahlenwert, der wiederholt ausgegeben werden soll
	 * @param count	<br>
	 * EN: Specifies how often the value is to be written
	 * DE: Gibt an, wie oft der Wert mit sich selbst verkettet werden soll
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getData(final int value, final int count) {
		StringBuilder sb=new StringBuilder();
		for (int i=0;i<count;i++) {if (i>0) sb.append(";"); sb.append(""+value);}
		return sb.toString();
	}

	/**
	 * EN: Creates a string containing a list of values separated by ";". In this list the given numerical value will be repeated as specified.<br>
	 * DE: Erzeugt eine Zeichenkette, die eine Liste mit ";" als Trennzeichen enth�lt. In dieser Liste wird die angegebe Zahl so h�ufig wie angegeben wiederholt.
	 * @param value	<br>
	 * EN: Numerical value to be repeated<br>
	 * DE: Zahlenwert, der wiederholt ausgegeben werden soll
	 * @param count	<br>
	 * EN: Specifies how often the value is to be written
	 * DE: Gibt an, wie oft der Wert mit sich selbst verkettet werden soll
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getData(final double value, final int count) {
		StringBuilder sb=new StringBuilder();
		for (int i=0;i<count;i++) {if (i>0) sb.append(";"); sb.append(Numbers.formatSystemNumber(value));}
		return sb.toString();
	}

	/**
	 * EN: Creates a string containing a list of values separated by ";". (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Erzeugt eine Zeichenkette, die eine Liste mit ";" als Trennzeichen enth�lt. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the numerical values<br>
	 * DE: Liste mit den Zahlenwerten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getDataString(final List<String> values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.size();i++) {if (i>0) sb.append(";"); sb.append(values.get(i));}
		return sb.toString();
	}

	/**
	 * EN: Creates a string containing a list of values separated by ";". (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Erzeugt eine Zeichenkette, die eine Liste mit ";" als Trennzeichen enth�lt. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the numerical values<br>
	 * DE: Liste mit den Zahlenwerten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getDataInteger(final List<Integer> values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.size();i++) {if (i>0) sb.append(";"); sb.append(Numbers.formatSystemNumber(values.get(i)));}
		return sb.toString();
	}

	/**
	 * EN: Creates a string containing a list of values separated by ";". (Such a list is needed for the distribution of the fresh calls and the number of agents over the day.)<br>
	 * DE: Erzeugt eine Zeichenkette, die eine Liste mit ";" als Trennzeichen enth�lt. (Solch eine Liste wird f�r die Verteilung der Erstanrufer und der Agentenverf�gbarkeit �ber den Tag ben�tigt.)
	 * @param values	<br>
	 * EN: List containing the numerical values<br>
	 * DE: Liste mit den Zahlenwerten
	 * @return
	 * EN: Merged list<br>
	 * DE: Zusammengef�hrte Liste
	 */
	public final static String getDataDouble(final List<Double> values) {
		StringBuilder sb=new StringBuilder();
		if (values!=null) for (int i=0;i<values.size();i++) {if (i>0) sb.append(";"); sb.append(Numbers.formatSystemNumber(values.get(i)));}
		return sb.toString();
	}

	/**
	 * EN: Calculates the mean of the given values.<br>
	 * DE: Berechnet den Mittelwert der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the mean is to be calculated.<br>
	 * DE: Werte, von denen der Mittelwert berechnet werden soll.
	 * @return
	 * EN: Mean<br>
	 * DE: Mittelwert
	 */
	public final static double mean(final int[] values) {
		if (values.length==0) return 0; else return sum(values)/values.length;
	}

	/**
	 * EN: Calculates the mean of the given values.<br>
	 * DE: Berechnet den Mittelwert der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the mean is to be calculated.<br>
	 * DE: Werte, von denen der Mittelwert berechnet werden soll.
	 * @return
	 * EN: Mean<br>
	 * DE: Mittelwert
	 */
	public final static double mean(final double[] values) {
		if (values.length==0) return 0; else return sum(values)/values.length;
	}

	/**
	 * EN: Calculates the mean of the given values.<br>
	 * DE: Berechnet den Mittelwert der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the mean is to be calculated.<br>
	 * DE: Werte, von denen der Mittelwert berechnet werden soll.
	 * @return
	 * EN: Mean<br>
	 * DE: Mittelwert
	 */
	public final static double meanInteger(final List<Integer> values) {
		if (values.size()==0) return 0; else return sumInteger(values)/values.size();
	}

	/**
	 * EN: Calculates the mean of the given values.<br>
	 * DE: Berechnet den Mittelwert der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the mean is to be calculated.<br>
	 * DE: Werte, von denen der Mittelwert berechnet werden soll.
	 * @return
	 * EN: Mean<br>
	 * DE: Mittelwert
	 */
	public final static double meanDouble(final List<Double> values) {
		if (values.size()==0) return 0; else return sumDouble(values)/values.size();
	}

	/**
	 * EN: Calculated the standard deviation of the given values.<br>
	 * DE: Berechnet die Standardabweichung der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the standard deviation is to be calculated.<br>
	 * DE: Werte, von denen die Standardabweichung berechnet werden soll.
	 * @return
	 * EN: Standard deviation<br>
	 * DE: Standardabweichung
	 */
	public final static double sd(final int[] values) {
		if (values.length<2) return 0;
		int sum2=0; for (int i: values) sum2+=(i*i);
		return Math.sqrt(sum2-Math.pow(sum(values),2)/values.length)/(values.length-1);
	}

	/**
	 * EN: Calculated the standard deviation of the given values.<br>
	 * DE: Berechnet die Standardabweichung der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the standard deviation is to be calculated.<br>
	 * DE: Werte, von denen die Standardabweichung berechnet werden soll.
	 * @return
	 * EN: Standard deviation<br>
	 * DE: Standardabweichung
	 */
	public final static double sd(final double[] values) {
		if (values.length<2) return 0;
		double sum2=0; for (double i: values) sum2+=(i*i);
		return Math.sqrt(sum2-Math.pow(sum(values),2)/values.length)/(values.length-1);
	}

	/**
	 * EN: Calculated the standard deviation of the given values.<br>
	 * DE: Berechnet die Standardabweichung der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the standard deviation is to be calculated.<br>
	 * DE: Werte, von denen die Standardabweichung berechnet werden soll.
	 * @return
	 * EN: Standard deviation<br>
	 * DE: Standardabweichung
	 */
	public final static double sdInteger(final List<Integer> values) {
		if (values.size()<2) return 0;
		int sum2=0; for (int i: values) sum2+=(i*i);
		return Math.sqrt(sum2-Math.pow(sumInteger(values),2)/values.size())/(values.size()-1);
	}

	/**
	 * EN: Calculated the standard deviation of the given values.<br>
	 * DE: Berechnet die Standardabweichung der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the standard deviation is to be calculated.<br>
	 * DE: Werte, von denen die Standardabweichung berechnet werden soll.
	 * @return
	 * EN: Standard deviation<br>
	 * DE: Standardabweichung
	 */
	public final static double sdDouble(final List<Double> values) {
		if (values.size()<2) return 0;
		double sum2=0; for (Double i: values) sum2+=(i*i);
		return Math.sqrt(sum2-Math.pow(sumDouble(values),2)/values.size())/(values.size()-1);
	}

	/**
	 * EN: Calculated the coefficient of variation of the given values.<br>
	 * DE: Berechnet den Variationskoeffizient der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the coefficient of variation is to be calculated.<br>
	 * DE: Werte, von denen der Variationskoeffizient berechnet werden soll.
	 * @return
	 * EN: Coefficient of variation<br>
	 * DE: Variationskoeffizient
	 */
	public final static double cv(final int[] values) {
		double m=mean(values);
		if (m==0) return 0;
		return sd(values)/m;
	}

	/**
	 * EN: Calculated the coefficient of variation of the given values.<br>
	 * DE: Berechnet den Variationskoeffizient der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the coefficient of variation is to be calculated.<br>
	 * DE: Werte, von denen der Variationskoeffizient berechnet werden soll.
	 * @return
	 * EN: Coefficient of variation<br>
	 * DE: Variationskoeffizient
	 */
	public final static double cv(final double[] values) {
		double m=mean(values);
		if (m==0) return 0;
		return sd(values)/m;
	}

	/**
	 * EN: Calculated the coefficient of variation of the given values.<br>
	 * DE: Berechnet den Variationskoeffizient der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the coefficient of variation is to be calculated.<br>
	 * DE: Werte, von denen der Variationskoeffizient berechnet werden soll.
	 * @return
	 * EN: Coefficient of variation<br>
	 * DE: Variationskoeffizient
	 */
	public final static double cvInteger(final List<Integer> values) {
		double m=meanInteger(values);
		if (m==0) return 0;
		return sdInteger(values)/m;
	}

	/**
	 * EN: Calculated the coefficient of variation of the given values.<br>
	 * DE: Berechnet den Variationskoeffizient der �bergebenen Werte.
	 * @param values	<br>
	 * EN: Values from which the coefficient of variation is to be calculated.<br>
	 * DE: Werte, von denen der Variationskoeffizient berechnet werden soll.
	 * @return
	 * EN: Coefficient of variation<br>
	 * DE: Variationskoeffizient
	 */
	public final static double cvDouble(final List<Double> values) {
		double m=meanDouble(values);
		if (m==0) return 0;
		return sdDouble(values)/m;
	}

	/**
	 * EN: Gives the value for the "never" distribution for distribution fields.
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Niemals"-Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionNever() {
		return Language.get(Language.Distribution_Infinite);
	}

	/**
	 * EN: Gives the value for the one point distribution for distribution fields.
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Ein-Punkt-Verteilung.
	 * @param	point	<br>
	 * EN: Value at which the proability mass should concentrate.<br>
	 * DE: Wert, auf den sich die Verteilungsmasse konzentrieren soll.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionOnePoint(final double point) {
		return Language.get(Language.Distribution_Point)+" ("+Numbers.formatSystemNumber(point)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionData(final String[] values) {
		return Language.get(Language.Distribution_Data)+" ("+getData(values)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionData(final int[] values) {
		return Language.get(Language.Distribution_Data)+" ("+getData(values)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionData(final double[] values) {
		return Language.get(Language.Distribution_Data)+" ("+getData(values)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionDataString(final List<String> values) {
		return Language.get(Language.Distribution_Data)+" ("+getDataString(values)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionDataInteger(final List<Integer> values) {
		return Language.get(Language.Distribution_Data)+" ("+getDataInteger(values)+")";
	}

	/**
	 * EN: Gives the value for the "Empirical data" distribution for distribution fields.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die "Empirische Daten"-Verteilung.
	 * @param	values	<br>
	 * EN: Density values of the distribution.<br>
	 * DE: Dichtewerte der Verteilung.
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionDataDouble(final List<Double> values) {
		return Language.get(Language.Distribution_Data)+" ("+getDataDouble(values)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the exponential distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Exponentialverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionExponential(final double mean) {
		return Language.get(Language.Distribution_Exp)+" ("+Numbers.formatSystemNumber(mean)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the normal distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Normalverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @param	sd	<br>
	 * EN: standard deviation<br>
	 * DE: Standardabweichung
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionNormal(final double mean, final double sd) {
		return Language.get(Language.Distribution_Normal)+" ("+Numbers.formatSystemNumber(mean)+";"+Numbers.formatSystemNumber(sd)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the lognormal distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Lognormalverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @param	sd	<br>
	 * EN: standard deviation<br>
	 * DE: Standardabweichung
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionLogNormal(final double mean, final double sd) {
		return Language.get(Language.Distribution_LogNormal)+" ("+Numbers.formatSystemNumber(mean)+";"+Numbers.formatSystemNumber(sd)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the gamma distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Gammaverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @param	sd	<br>
	 * EN: standard deviation<br>
	 * DE: Standardabweichung
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionGamma(final double mean, final double sd) {
		double beta=Math.pow(sd,2)/mean;
		double alpha=mean/beta;
		return Language.get(Language.Distribution_Gamma)+" ("+Numbers.formatSystemNumber(alpha)+";"+Numbers.formatSystemNumber(beta)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the beta distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Betaverteilung.
	 * @param	alpha	<br>
	 * EN: First parameter (&alpha;)<br>
	 * DE: Erster Parameter (&alpha;)
	 * @param	beta	<br>
	 * EN: Second parameter (&beta;)<br>
	 * DE: Zweiter Parameter (&beta;)
	 * @param supportLower	<br>
	 * EN: Lower border of the support<br>
	 * DE: Untere Grenze des Tr�gerbereichs
	 * @param supportHigher	<br>
	 * EN: Upper borwser of the support<br>
	 * DE: Obere Grenze des Tr�gerbereichs
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionBeta(final double alpha, final double beta, final double supportLower, final double supportHigher) {
		return Language.get(Language.Distribution_Beta)+" ("+Numbers.formatSystemNumber(alpha)+";"+Numbers.formatSystemNumber(beta)+";"+Numbers.formatSystemNumber(supportLower)+";"+Numbers.formatSystemNumber(supportHigher)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the Erlang distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Erlangverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @param	sd	<br>
	 * EN: standard deviation<br>
	 * DE: Standardabweichung
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionErlang(final double mean, final double sd) {
		double beta=Math.pow(sd,2)/mean;
		double alpha=mean/beta;
		return Language.get(Language.Distribution_Erlang)+" ("+Numbers.formatSystemNumber(alpha)+";"+Numbers.formatSystemNumber(beta)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the cauchy distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Cauchyverteilung.
	 * @param	mean	<br>
	 * EN: Mean<br>
	 * DE: Mittelwert
	 * @param	sd	<br>
	 * EN: standard deviation<br>
	 * DE: Standardabweichung
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionCauchy(final double mean, final double sd) {
		return Language.get(Language.Distribution_Cauchy)+" ("+Numbers.formatSystemNumber(mean)+";"+Numbers.formatSystemNumber(sd)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the uniform distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Gleichverteilung.
	 * @param supportLower	<br>
	 * EN: Lower border of the support<br>
	 * DE: Untere Grenze des Tr�gerbereichs
	 * @param supportHigher	<br>
	 * EN: Upper borwser of the support<br>
	 * DE: Obere Grenze des Tr�gerbereichs
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionUniform(final double supportLower, final double supportHigher) {
		return Language.get(Language.Distribution_Uniform)+" ("+Numbers.formatSystemNumber(supportLower)+";"+Numbers.formatSystemNumber(supportHigher)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the Weibul distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Weibullverteilung.
	 * @param scale	<br>
	 * EN: First parameter<br>
	 * DE: Erster Parameter
	 * @param shape	<br>
	 * EN: Second parameter<br>
	 * DE: Zweiter Parameter
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionWeibul(final double scale, final double shape) {
		return Language.get(Language.Distribution_Weibull)+" ("+Numbers.formatSystemNumber(scale)+";"+Numbers.formatSystemNumber(shape)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the chi^2 distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die Chi^2-Verteilung.
	 * @param degreesOfFreedom	<br>
	 * EN: Degrees of freedom<br>
	 * DE: Freiheitsgrade
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionChiSquare(final double degreesOfFreedom) {
		return Language.get(Language.Distribution_ChiSquare)+" ("+Numbers.formatSystemNumber(degreesOfFreedom)+")";
	}

	/**
	 * EN: Gives the value for distribution fields for the F distribution.<br>
	 * DE: Liefert den Wert f�r Verteilungsfelder f�r die F-Verteilung.
	 * @param numeratorDegreesOfFreedom	<br>
	 * EN: Dgrees of freedom (numerator)<br>
	 * DE: Freiheitsgrade (Z�hler)
	 * @param denominatorDegreesOfFreedom	<br>
	 * EN: Dgrees of freedom (denominator)<br>
	 * DE: Freiheitsgrade (Nenner)
	 * @return
	 * EN: Value which can be written into distribution fields.<br>
	 * DE: Wert, der in ein Verteilungsfeld geschrieben werden kann.
	 */
	public final static String getDistributionF(final double numeratorDegreesOfFreedom, double denominatorDegreesOfFreedom) {
		return Language.get(Language.Distribution_F)+" ("+Numbers.formatSystemNumber(numeratorDegreesOfFreedom)+";"+Numbers.formatSystemNumber(denominatorDegreesOfFreedom)+")";
	}
}