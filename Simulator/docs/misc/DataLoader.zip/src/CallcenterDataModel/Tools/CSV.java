package CallcenterDataModel.Tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * EN: The class <code>CSV</code> encapsulates a table consisting of <code>String</code> objects. The class provides methods for loading table files.
 * DE: Die Klasse <code>CSV</code> kapselt eine Tabelle aus <code>String</code>-Objekten. Die Klasse stellt Methoden zum Laden von Tabellen-Dateien zur Verf�gung.
 * @author Alexander Herzog
 * @version 1.0
 */
public class CSV implements Cloneable {
	private final List<List<String>> data;

	/**
	 * EN: Constructor of the class <code>CSV</code>
	 * DE: Konstruktor der Klasse <code>CSV</code>
	 */
	public CSV() {
		data=new ArrayList<List<String>>();
	}

	/**
	 * EN: Constructor of the class <code>CSV</code>
	 * DE: Konstruktor der Klasse <code>CSV</code>
	 * @param data	<br>
	 * EN: Data to be copied into the table.<br>
	 * DE: Daten, die in die Tabelle kopiert werden sollen.
	 */
	public CSV(List<List<String>> data) {
		this();
		setData(data);
	}

	/**
	 * EN: Constructor of the class <code>CSV</code>
	 * DE: Konstruktor der Klasse <code>CSV</code>
	 * @param data	<br>
	 * EN: Data to be copied into the table.<br>
	 * DE: Daten, die in die Tabelle kopiert werden sollen.
	 */
	public CSV(String[][] data) {
		this();
		setData(data);
	}

	/**
	 * EN: Constructor of the class <code>CSV</code>
	 * DE: Konstruktor der Klasse <code>CSV</code>
	 * @param data	<br>
	 * EN: Data in the csv format to be copied into the table.<br>
	 * DE: Daten im csv-Format, die in die Tabelle kopiert werden sollen.
	 */
	public CSV(String data) {
		this();
		setData(data);
	}

	/**
	 * EN: Gives the size of the table.<br>
	 * DE: Liefert die Gr��e der Tabelle.
	 * @param level	<br>
	 * EN: Gives the number of rows (level=0) or the number of columns (level=1).<br>
	 * DE: Zeilenanzahl (level=0) oder Spaltenanzahl (level=1) abfragen.
	 * @return
	 * EN: Number of rows or columns.<br>
	 * DE: Anzahl der Zeilen oder Anzahl der Spalten.
	 */
	public final int getSize(int level) {
		switch (level) {
		case 0: return data.size();
		case 1: if (data.size()==0) return 0; else return data.get(0).size();
		}
		return 0;
	}

	/**
	 * EN: Give the complete table data.<br>
	 * DE: Liefert die kompletten Tabellendaten zur�ck.
	 * @return
	 * EN: <code>List</code object containing the data.<br>
	 * DE: <code>List</code>-Objekt, welches die Daten enth�lt.
	 * @see setData
	 * @see getDataArray
	 */
	public final List<List<String>> getDataList() {
		return data;
	}

	/**
	 * EN: Give the complete table data.<br>
	 * DE: Liefert die kompletten Tabellendaten zur�ck.
	 * @return
	 * EN: Array object containing the data.<br>
	 * DE: Array-Objekt, welches die Daten enth�lt.
	 * @see setData
	 * @see getData
	 */
	public final String[][] getDataArray() {
		String[][] s=new String[data.size()][];
		for (int i=0;i<data.size();i++) {
			List<String> v=data.get(i);
			s[i]=new String[v.size()];
			for (int j=0;j<v.size();j++) s[i][j]=v.get(j);
		}
		return s;
	}

	/**
	 * EN: Replaces the current table data by new data
	 * DE: Ersetzt die bisherigen Tabellendaten durch die neuen Daten
	 * @param newData	<br>
	 * EN: New table content<br>
	 * DE: Neuer Tabelleninhalt
	 * @see getData
	 * @see load
	 */
	public final void setData(List<List<String>> newData) {
		clear();
		for (int i=0;i<newData.size();i++) addLine(newData.get(i));
		makeSquare();
	}

	/**
	 * EN: Replaces the current table data by new data
	 * DE: Ersetzt die bisherigen Tabellendaten durch die neuen Daten
	 * @param newData	<br>
	 * EN: New table content<br>
	 * DE: Neuer Tabelleninhalt	 * @see getData
	 * @see load
	 */
	public final void setData(String[][] newData) {
		clear();
		for (int i=0;i<newData.length;i++) addLine(newData[i]);
		makeSquare();
	}

	/**
	 * EN: Replaces the current table data by new data
	 * DE: Ersetzt die bisherigen Tabellendaten durch die neuen Daten
	 * @param newData	<br>
	 * EN: New table content in csv format<br>
	 * @see getData
	 * @see load
	 */
	public final void setData(String newData) {
		clear();
		String[] lines=newData.split("\n");
		for (int i=0;i<lines.length;i++) data.add(fromCSV(lines[i]));
		makeSquare();
	}

	/**
	 * EN: Gets a row.<br>
	 * DE: Liefert eine Zeile.
	 * @param index	<br>
	 * EN: Index of the row.<br>
	 * DE: Index der Zeile.
	 * @return
	 * <code>List</code> containing the row.<br>
	 * <code>List</code>, die die Zeile enth�lt.
	 * @see setLine
	 */
	public final List<String> getLine(int index) {
		if (index<0 || index>=data.size()) return null; return data.get(index);
	}

	/**
	 * EN: Replaces the content of a row by new data.<br>
	 * DE: Ersetzt den Inhalt einer Zeile durch eine neue.
	 * @param index	<br>
	 * EN: Index of the row.<br>
	 * DE: Index der Zeile.
	 * @param newLine	<br>
	 * EN: New row.<br>
	 * DE: Neue Zeile.
	 */
	public final void setLine(int index, List<String> newLine) {
		if (index<0) return;
		while (index>=data.size()) data.add(new ArrayList<String>());
		ArrayList<String> list=new ArrayList<String>();
		list.addAll(newLine);
		data.set(index,list);
	}

	/**
	 * EN: Replaces the content of a row by new data.<br>
	 * DE: Ersetzt den Inhalt einer Zeile durch eine neue.
	 * @param index	<br>
	 * EN: Index of the row.<br>
	 * DE: Index der Zeile.
	 * @param newLine	<br>
	 * EN: New row.<br>
	 * DE: Neue Zeile.
	 */
	public final void setLine(int index, String[] newLine) {
		if (index<0) return;
		while (index>=data.size()) data.add(new ArrayList<String>());
		List<String> v=new ArrayList<String>();
		for (int i=0;i<newLine.length;i++) v.add(newLine[i]);
		data.set(index,v);
	}

	/**
	 * EN: Appends a row to the table.<br>
	 * DE: F�gt eine Zeile an die Tabelle an.
	 * @param newLine	<br>
	 * EN: Row to be appended.<br>
	 * DE: Anzuf�gende Zeile.
	 */
	public final void addLine(List<String> newLine) {
		ArrayList<String> list=new ArrayList<String>();
		list.addAll(newLine);
		data.add(list);
	}

	/**
	 * EN: Appends a row to the table.<br>
	 * DE: F�gt eine Zeile an die Tabelle an.
	 * @param newLine	<br>
	 * EN: Row to be appended.<br>
	 * DE: Anzuf�gende Zeile.
	 */
	public final void addLine(String[] newLine) {
		List<String> v=new ArrayList<String>();
		for (int i=0;i<newLine.length;i++) v.add(newLine[i]);
		data.add(v);
	}

	/**
	 * EN: Appends multiple lines to the table.<br>
	 * DE: F�gt mehrere Zeilen an die Tabelle an.
	 * @param newLines	<br>
	 * EN: Lines to be appended.<br>
	 * DE: Anzuf�gende Zeilen.
	 */
	public final void addLines(List<List<String>> newLines) {
		for (int i=0;i<newLines.size();i++) addLine(newLines.get(i));
	}

	/**
	 * EN: Appends multiple lines to the table.<br>
	 * DE: F�gt mehrere Zeilen an die Tabelle an.
	 * @param newLines	<br>
	 * EN: Lines to be appended.<br>
	 * DE: Anzuf�gende Zeilen.
	 */
	public final void addLines(String[][] newLines) {
		for (int i=0;i<newLines.length;i++) addLine(newLines[i]);
	}

	/**
	 * EN: Inserts a row into the table at the given index.<br>
	 * DE: F�gt eine Zeile am angegebenen Index in die Tabelle ein.
	 * @param newLine	<br>
	 * EN: Row to be inserted.<br>
	 * DE: Einzuf�gende Zeile.
	 * @param index	<br>
	 * EN: Position at which the row is to be inserted.<br>
	 * DE: Position, an der die Zeile eingef�gt werden soll.
	 */
	public final void insertLine(String[] newLine, int index) {
		List<String> v=new ArrayList<String>();
		for (int i=0;i<newLine.length;i++) v.add(newLine[i]);
		data.add(index,v);
	}

	/**
	 * EN: Inserts a row into the table at the given index.<br>
	 * DE: F�gt eine Zeile am angegebenen Index in die Tabelle ein.
	 * @param newLine	<br>
	 * EN: Row to be inserted.<br>
	 * DE: Einzuf�gende Zeile.
	 * @param index	<br>
	 * EN: Position at which the row is to be inserted.<br>
	 * DE: Position, an der die Zeile eingef�gt werden soll.
	 */
	public final void insertLine(List<String> newLine, int index) {
		insertLine(newLine.toArray(new String[0]),index);
	}

	/**
	 * EN: Returns the value of a single cell<br>
	 * DE: Liefert den Wert einer einzelnen Zelle
	 * @param index1	<br>
	 * EN: Row index<br>
	 * DE: Zeilenindex
	 * @param index2	<br>
	 * EN: Column index<br>
	 * DE: Spaltenindex
	 * @return
	 * EN: Value of the selected cell<br>
	 * DE: Wert der angegebenen Zelle
	 * @see setValue
	 */
	public final String getCell(int index1, int index2) {
		if (index1<0 || index1>=data.size()) return "";
		if (index2<0 || index2>=data.get(index1).size()) return "";
		return data.get(index1).get(index2);
	}

	/**
	 * EN: Sets the value of a cell<br>
	 * DE: Setzt den Wert einer Zelle
	 * @param index1	<br>
	 * EN: Row index<br>
	 * DE: Zeilenindex
	 * @param index2	<br>
	 * EN: Column index<br>
	 * DE: Spaltenindex
	 * @param value	<br>
	 * EN: New value of the selected cell<b>
	 * DE: Neuer Wert f�r die entsprechende Zelle
	 * @see getValue
	 */
	public final void setCell(int index1, int index2, String value) {
		if (index1<0 || index2<0) return;

		while (data.size()<=index1) data.add(new ArrayList<String>());

		List<String> v=data.get(index1);
		while (v.size()<=index2) v.add("");

		v.set(index2,value);
	}

	@Override
	public final String toString() {
		String s="";
		for (int i=0;i<data.size();i++) {
			List<String> v=data.get(i);
			for (int j=0;j<v.size();j++) {
				s+=v.get(j);
				if (j<v.size()-1) s+="\t";
			}
			if (i<data.size()-1) s+="\n";
		}
		return s;
	}

	@Override
	public CSV clone() {
		return new CSV(data);
	}

	/**
	 * EN: Gets a transposed version of the table.<br>
	 * DE: Liefert eine transponierte Fassung der Tabelle.
	 * @return
	 * EN: Transposed version of the table.<br>
	 * DE: Transponierte Fassung der Tabelle.
	 */
	public CSV transpose() {
		CSV t=new CSV();
		for (int i=0;i<data.size();i++) for (int j=0;j<data.get(i).size();j++) t.setCell(j,i,data.get(i).get(j));
		return t;
	}

	/**
	 * EN: Deletes the content of the table.<br>
	 * DE: L�scht den Inhalt der Tabelle.
	 */
	public void clear() {
		data.clear();
	}

	/**
	 * EN: Converts a string containing CSV values to a list of values<br>
	 * DE: Wandelt eine Zeichenkette aus CSV-Werten in eine Liste mit diesen Werten um
	 * @param line	<br>
	 * EN: Row containing CSV values<br>
	 * DE: Zeile mit CSV-Werten
	 * @return
	 * EN: <code>List</code> objekt containing the values.<br>
	 * DE: <code>List</code>-Objekt, welches die Werte enth�lt.
	 */
	private final List<String> fromCSV(String line) {
		List<String> v=new ArrayList<String>();

		String divider=";";
		if (line.indexOf('\t')>=0) divider="\t";

		while (!line.isEmpty()) {
			String cell="";
			if (line.startsWith("\"")) {
				/* Cell in quotation marks / Zelle in Anf�hrungszeichen */
				line=line.substring(1);
				int endBorder=-1;
				boolean lastWasBorder=false;
				for (int i=0;i<line.length();i++) {
					char c=line.charAt(i);
					if (c=='"') {lastWasBorder=!lastWasBorder; continue;}
					if (lastWasBorder) {endBorder=i-1; break;}
				}
				if (endBorder==-1) {
					if (lastWasBorder) cell=line.substring(0,line.length()-1); else cell=line;
					line="";
				} else {
					cell=line.substring(0,endBorder); line=line.substring(endBorder+1);
					if (line.startsWith(divider)) {
						if (line.length()==1) line=""; else line=line.substring(1);
					}
				}
			} else {
				/* Cell without quotation marks / Zelle ohne Anf�hrungszeichen */
				int i=line.indexOf(divider);
				if (i<0) {cell=line; line="";} else {
					if (i==line.length()-1) {cell=""; line="";} else {
						if (i==0) {cell=""; line=(line.length()>1)?line.substring(1):"";} else {
							cell=line.substring(0,i); line=line.substring(i+1);
						}
					}
				}
			}
			v.add(cell);
		}
		return v;
	}

	/**
	 * EN: Loads the content of a table from a file.<br>
	 * DE: L�dt den Inhalt der Tabelle aus einer Datei.
	 * @param file	<br>
	 * EN: File name of the table file to be loaded.<br>
	 * DE: Dateiname der Tabellendatei, die geladen werden soll.
	 * @return
	 * EN: Returns <code>true</code>, if the table could be loaded successfully.<br>
	 * DE: Liefert <code>true</code> zur�ck, wenn die Tabelle erfolgreich geladen wurde.
	 */
	public final boolean load(File file) {
		clear();

		try {
			try (BufferedReader br=new BufferedReader(new FileReader(file))) {
				String s;
				while ((s=br.readLine())!=null) data.add(fromCSV(s));
			}
		} catch (IOException e) {return false;}
		makeSquare();
		return true;
	}

	/**
	 * EN: Assures that all rows have the same number of columns after adding rows.<br>
	 * DE: Sorgt durch eventuelles Hinzuf�gen von Spalten in einzelnen Zeilen daf�r, dass alle Zeilen gleich viele Spalten besitzen.
	 */
	private final void makeSquare() {
		if (data==null || data.size()==0) return;
		int maxLen=0;
		for (int i=0;i<data.size();i++) maxLen=Math.max(maxLen,data.get(i).size());
		for (int i=0;i<data.size();i++) {List<String> line=data.get(i); while (line.size()<maxLen) line.add("");}
	}

	/**
	 * EN: Temporary storing error messaages of errors that occurred when converting strings to numbers.<br>
	 * DE: Zwischenspeicherung von Fehlerbeschreibungen von Fehlern, die beim Umwandeln von Strings in Zahlen aufgetreten sind.
	 */
	private String numberAreaError=null;

	/**
	 * EN: Returns the information message fo the error that occured during the execution of <code>getNumberArea</code>.<br>
	 * DE: Liefert eine Beschreibung zu dem w�hrend des Aufrufs von <code>getNumberArea</code> aufgetretenen Fehlers.
	 * @return
	 * EN: Error message or <code>null</code>, if <code>getNumberArea</code> was executed successfully.
	 * DE: Fehlerbeschreibung oder <code>null</code>, wenn <code>getNumberArea</code> erfolgreich ausgef�hrt wurde.
	 * @see getNumberArea
	 */
	public final String getNumberAreaError() {
		return numberAreaError;
	}

	/**
	 * EN: Converts a cell description like A1 in an array of row and column number (each 0-based).<br>
	 * DE: Wandelt eine Zellenbeschreibung wie A1 in ein Array aus Zeilen- und Spaltennummer (jeweils 0-basierend) um.
	 * @param cellID	<br>
	 * EN: Identifier of the cell<br>
	 * DE: Bezeichner der Zelle
	 * @return
	 * EN: Two elements array of row and column number (each 0-based)<br>
	 * DE: Zweielementiges Array aus Zeilen- und Spaltennummer (jeweils 0-basierend)
	 */
	private static final int[] cellIDToNumbers(String cellID) {
		char[] c=cellID.trim().toUpperCase().toCharArray();
		int i=0,col=0;
		while (i<c.length) {
			if (c[i]<'A' || c[i]>'Z') break;
			col*=26;
			col+=(c[i]-'A');
			i++;
		}
		if (i==0 || i==c.length) return null;

		Integer row=Numbers.getInteger(cellID.trim().substring(i));
		if (row==null || row<=0) return null;

		return new int[]{row-1,col};
	}

	/**
	 * EN: Converts a 0-based column number into an identifier.<br>
	 * DE: Wandelt eine 0-basierende Spaltennummer in einen Bezeichner um.
	 * @param column	<br>
	 * EN: 0-based column number<br>
	 * DE: 0-basierende Spaltennumer
	 * @return
	 * EN: Identifier of the column<br>
	 * DE: Bezeichner der Spalte
	 */
	private static final String columnNameFromNumber(int column) {
		String col="";
		int c=column+1;
		while (c!=0) {
			byte b=(byte)(c%26-1);
			char ch=(char)(b+'A');
			col=ch+col;
			c=c/26;
		}
		return col;
	}

	/**
	 * EN: Converts an array of row and column number (each 0-based) into a cell identifier.<br>
	 * DE: Wandelt ein Array aus Zeilen- und Spaltennummer (jeweils 0-basierend) in einen Zellenbezeichner um.
	 * @param cell	<br>
	 * EN: Two element array of row and column number (each 0-based)<br>
	 * DE: Zweielementiges Array aus Zeilen- und Spaltennummer (jeweils 0-basierend)
	 * @return
	 * EN: Identifier of the cell<br>
	 * DE: Bezeichner der Zelle
	 */
	private static final String cellIDFromNumber(int[] cell) {
		if (cell.length!=2) return "";
		return columnNameFromNumber(cell[1])+(cell[0]+1);
	}

	/**
	 * EN: Extracts a range of data from the table. The area has to be either a line or a column. The entries has to be valid numbers.<br>
	 * DE: Extrahiert einen Datenbereich aus der Tabelle. Der Bereich muss entweder entweder die Form einer Zeile oder die einer Spalte haben. Die Eintr�ge m�ssen g�ltige Zahlen sein.
	 * @param cellStart	<br>
	 * EN: Starting cell<br>
	 * DE: Anfangszelle
	 * @param cellEnd
	 * EN: End cell<br>
	 * DE: Endzelle
	 * @return
	 * EN: Returns if successfull the data area, otherwide <code>null</code>. In case of an error the error message can be received by calling <code>getNumberAreaError</code>.
	 * DE: Liefert im Erfolgsfall den Datenbereich zur�ck, sonst <code>null</code>. Im Fehlerfall kann �ber <code>getNumberAreaError</code> eine Fehlerbeschreibung ermittelt werden.
	 * @see getNumberAreaError
	 */
	public final double[] getNumberArea(String cellStart, String cellEnd) {
		numberAreaError=null;
		int[] cell1=cellIDToNumbers(cellStart);
		int[] cell2=cellIDToNumbers(cellEnd);
		if (cell1==null) {numberAreaError=String.format(Language.get(Language.CSV_InvalidStartCell),cellStart); return null;}
		if (cell2==null) {numberAreaError=String.format(Language.get(Language.CSV_InvalidEndCell),cellEnd); return null;}
		if (cell1[0]!=cell2[0] && cell1[1]!=cell2[1]) {numberAreaError=String.format(Language.get(Language.CSV_InvalidRange),cellStart,cellEnd); return null;}

		if (cell1[0]==cell2[0]) {
			double[] data=new double[Math.abs(cell2[1]-cell1[1])+1];
			int dir=(cell2[1]>cell1[1])?1:-1;
			int nr=0;
			for (int i=cell1[1];;i+=dir) {
				if (getSize(0)<=cell1[0] || getSize(1)<=i) {numberAreaError=String.format(Language.get(Language.CSV_CellNotInTable),cellIDFromNumber(new int[]{cell1[0],i}),cellIDFromNumber(new int[]{getSize(0)-1,getSize(1)-1})); return null;}
				String s=getLine(cell1[0]).get(i);
				Double d=Numbers.getNotNegativeSystemDouble(s);
				if (d==null) d=	Numbers.getSystemDouble(s);
				if (d==null) {numberAreaError=String.format(Language.get(Language.CSV_InvalidValue),cellIDFromNumber(new int[]{cell1[0],i}),s); return null;}
				data[nr]=d;
				nr++;
				if (i==cell2[1]) break;
			}
			return data;
		} else {
			double[] data=new double[Math.abs(cell2[0]-cell1[0])+1];
			int dir=(cell2[0]>cell1[0])?1:-1;
			int nr=0;
			for (int i=cell1[0];;i+=dir) {
				if (getSize(0)<=i || getSize(1)<=cell1[1]) {numberAreaError=String.format(Language.get(Language.CSV_CellNotInTable),cellIDFromNumber(new int[]{i,cell1[1]}),cellIDFromNumber(new int[]{getSize(0)-1,getSize(1)-1})); return null;}
				String s=getLine(i).get(cell1[1]);
				Double d=Numbers.getNotNegativeSystemDouble(s);
				if (d==null) d=Numbers.getSystemDouble(s);
				if (d==null) {numberAreaError=String.format(Language.get(Language.CSV_InvalidValue),cellIDFromNumber(new int[]{i,cell1[1]}),s); return null;}
				data[nr]=d;
				nr++;
				if (i==cell2[0]) break;
			}
			return data;
		}
	}
}