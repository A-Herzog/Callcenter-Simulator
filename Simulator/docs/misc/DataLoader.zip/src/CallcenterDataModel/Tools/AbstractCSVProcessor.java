package CallcenterDataModel.Tools;

import java.io.File;
import java.util.List;

/**
 * EN: Base class for loading and processing data from a csv file<br>
 * DE: Basisklasse zur Laden und Verarbeiten von Daten aus einer CSV-Datei
 * @author Alexander Herzog
 */
public abstract class AbstractCSVProcessor {
	private final File inputFile;
	private final CSV csv;

	/**
	 * EN: Constructor of the class <code>AbstractCSVProcessor</code><br>
	 * DE: Konstruktor der Klasse <code>AbstractCSVProcessor</code>
	 * @param inputFile<br>
	 * EN: Input file to be read<br>
	 * DE: Zu ladende Eingabedatei
	 */
	public AbstractCSVProcessor(File inputFile) {
		this.inputFile=inputFile;
		this.csv=new CSV();
	}

	/**
	 * EN: Processes one line of the file. (Is to be overwritten by concrete implementations.)<br>
	 * DE: Verarbeitet eine Zeile der Datei. (Muss von konkreten Implementierungen �berschrieben werden.)
	 * @param lineNumber<br>
	 * EN: Number of the current row (0 based)<br>
	 * DE: Nummer der aktuellen Zeile (0-basierend)
	 * @param line<br>
	 * EN: Columns in the current row as a list of strings<br>
	 * DE: Spalten der aktuellen Zeile in Form einer Liste aus Strings
	 * @return
	 * EN: Returns <code>null</code> if the line could be processed successfully, otherwise an error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Zeile erfolgreich verarbeitet werden konnte, ansonsten eine entsprechende Fehlermeldung.
	 */
	protected abstract String processLine(int lineNumber, List<String> line);

	/**
	 * EN: Loads the file and processes it.<br>
	 * DE: L�dt und verarbeitet die Datei.
	 * @return
	 * EN: Returns <code>null</code> if the file could be read and processed, otherwise returns an error message.<br>
	 * DE: Liefert <code>null</code> zur�ck, wenn die Datei geladen und verarbeitet werden konnte, ansonsten eine entsprechende Fehlermeldung.
	 */
	public String loadFile() {
		if (!inputFile.exists()) return String.format(Language.get(Language.File_InputFileDoesNotExist),inputFile.toString());
		if (inputFile.isDirectory()) return String.format(Language.get(Language.File_InputFileIsADirectory),inputFile.toString());
		if (!csv.load(inputFile)) return String.format(Language.get(Language.File_LoadError),inputFile.toString());

		final int count=csv.getSize(0);
		for (int i=0;i<count;i++) {
			final String s=processLine(i,csv.getLine(i));
			if (s!=null) return String.format(Language.get(Language.CSV_ErrorInLine),i+1,s);
		}

		return null;
	}
}
