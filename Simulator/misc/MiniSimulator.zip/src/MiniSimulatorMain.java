import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import callcenter.VersionConst;
import callcenter.editor.CallcenterEditorFrame;
import callcenter.editor.CallcenterEditorFrame.DropTargetRegister;
import callcenter.editor.CallcenterEditorFrame.LoadCallback;
import mathtools.distribution.swing.CommonVariables;
import mathtools.distribution.tools.FileDropper;
import mathtools.distribution.tools.FileDropperData;

public class MiniSimulatorMain {
	private static void setupUI() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {} catch (InstantiationException e) {} catch (IllegalAccessException e) {} catch (UnsupportedLookAndFeelException e) {}
	}

	public static void main(String[] args) {
		setupUI();
		new CallcenterEditorFrame(VersionConst.version, new DropTargetRegisterImpl());
	}

	private static class DropTargetRegisterImpl implements DropTargetRegister {
		private final List<LoadCallback> loadCallbacks=new ArrayList<LoadCallback>();

		@Override
		public void registerJComponent(JComponent component) {
			new FileDropper(component,new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (!(e.getSource() instanceof FileDropperData)) return;
					final FileDropperData data=(FileDropperData)e.getSource();
					File file=data.getFile();
					for (LoadCallback callback : loadCallbacks) if (callback.loadFile(file)) {
						data.dragDropConsumed();
						CommonVariables.setInitialDirectoryFromFile(file);
						break;
					}
				}
			});
		}

		@Override
		public void addLoadCallback(LoadCallback callback) {
			loadCallbacks.add(callback);
		}
	}
}
