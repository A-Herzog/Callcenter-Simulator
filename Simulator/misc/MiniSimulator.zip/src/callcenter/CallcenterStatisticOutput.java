package callcenter;
import org.apache.commons.math3.distribution.ExponentialDistribution;

import mathtools.ErlangC;
import mathtools.distribution.NeverDistributionImpl;
import mathtools.distribution.tools.DistributionTools;

/**
 * Diese Klasse bereitet die w�hrend der Simulation anfallenden Statistikdaten auf und stellt diese in Form von
 * finalisierten Membervariablen zum Auslesen zur Verf�gung. Dabei werden neben den reinen Statisikdaten auch
 * Modellparameter und Leistungswerte zur Simulation ausgegeben. (Daher ben�tigt diese Klasse auch Zugriff auf
 * das <code>CallcenterSimulator</code>-Objekt und nicht nur auf das <code>CallcenterStatisticSimData</code>-Objekt.
 * @author Alexander Herzog
 * @version 1.0
 */
public class CallcenterStatisticOutput {
	private final double inverseLambda;
	private final double inverseMu;
	private final double inverseNu;
	private final double cvIB;
	private final double cvSB;
	private final boolean LambdaIsExp;
	private final boolean MuIsExp;
	private final boolean NuIsExp;
	private final int batchArrival;
	private final int batchWorking;

	public final double inputContinueProbability;
	public final double inputRetryProbability;
	public final int inputAgents;
	public final int inputWaitingRoomSize;

	public final long systemRunTime;
	public final long systemEvents;
	public final int systemEventsPerMs;
	public final int systemThreads;

	public final long callsFresh;
	public final long callsRetrys;
	public final long callsAll;
	public final long callsSuccessful;
	public final double callsSuccessfulPercent;
	public final long callsCanceled;
	public final double callsCanceledPercent;
	public final long callsRejected;
	public final double callsRejectedPercent;

	public final double interarrivalMean;
	public final double interarrivalStd;

	public final int waitCalls;
	public final double waitCallsPercent;
	public final double waitMeanSuccess;
	public final double waitMeanCancel;
	public final double waitMeanAll;
	public final double waitVarSuccess;
	public final double waitVarCancel;
	public final double waitVarAll;
	public final double waitStdSuccess;
	public final double waitStdCancel;
	public final double waitStdAll;

	public final double serviceMean;
	public final double serviceStd;

	public final double systemMean;
	public final double systemStd;

	public final double[] queueLengthTimes;
	public final double queueLengthMean;
	public final double queueLengthVar;
	public final double queueLengthStd;
	public final int queueLengthMax;
	public final double queueNoQueuePercent;

	public final double[] systemLengthTimes;
	public final double systemLengthMean;
	public final double systemLengthVar;
	public final double systemLengthStd;
	public final int systemLengthMax;

	public final int loadAgentCount;
	public final double[] loadWorkingAgentTimes;
	public final double loadAllFreePercent;
	public final double loadAllBusyPercent;
	public final double loadMeanWorkingAgents;
	public final double loadMeanWorkingAgentsPercent;
	public final double loadVarWorkingAgents;
	public final double loadStdWorkingAgents;

	public final double meanFreeAgents;

	/**
	 * Konstruktor der Klasse <code>CallcenterStatisticOutput</code>
	 * @param simulator	Objekt vom Typ <code>CallcenterSimulator</code> aus dem die statischen Daten ausgelesen und aufbereitet werden sollen.
	 */
	public CallcenterStatisticOutput(CallcenterSimulator simulator) {
		CallcenterStatisticSimData statisticSimData=simulator.collectStatistic();

		/* Eingabedaten speichern */
		inputContinueProbability=simulator.staticSimData.callContinueProbability;
		inputRetryProbability=simulator.staticSimData.retryProbability;
		inputAgents=simulator.staticSimData.agents;
		inputWaitingRoomSize=simulator.staticSimData.waitingRoomSize;

		/* Informationen zum Simulationslauf */
		systemRunTime=simulator.runTime;
		systemEvents=simulator.getEventCount();
		systemEventsPerMs=(int)(simulator.getEventCount()/simulator.runTime);
		systemThreads=simulator.threadCount;

		/* Anruferzahlen */
		callsAll=statisticSimData.calls;
		callsFresh=statisticSimData.freshCalls;
		callsRetrys=callsAll-callsFresh;
		callsSuccessful=statisticSimData.successful;
		callsSuccessfulPercent=100*(double)callsSuccessful/Math.max(1,callsAll);
		callsCanceled=callsAll-statisticSimData.successful-statisticSimData.rejectedCalls;
		callsCanceledPercent=100*(double)callsCanceled/Math.max(1,callsAll);
		callsRejected=statisticSimData.rejectedCalls;
		callsRejectedPercent=100*(double)callsRejected/Math.max(1,callsAll);

		/* Zwischenankunftszeiten */
		interarrivalMean=statisticSimData.interarrivalTimeSum/Math.max(1,callsAll);
		interarrivalStd=Math.sqrt(statisticSimData.interarrivalTimeSumSqr/Math.max(1,callsAll)-Math.pow(interarrivalMean,2));

		/* Wartezeiten */
		waitCalls=statisticSimData.callsNeededToWait;
		waitCallsPercent=100*(double)waitCalls/Math.max(1,callsAll);
		waitMeanSuccess=statisticSimData.waitingTimeSum/Math.max(1,callsSuccessful);
		waitMeanCancel=statisticSimData.abortTimeSum/Math.max(1,callsCanceled);
		waitMeanAll=(statisticSimData.waitingTimeSum+statisticSimData.abortTimeSum)/Math.max(1,callsSuccessful+callsCanceled);
		double E2Sucess=statisticSimData.waitingTimeSqrSum/Math.max(1,callsSuccessful);
		double E2Cancel=statisticSimData.abortTimeSqrSum/Math.max(1,callsCanceled);
		double E2All=(statisticSimData.waitingTimeSqrSum+statisticSimData.abortTimeSqrSum)/Math.max(1,callsSuccessful+callsCanceled);
		if (callsSuccessful==0) waitVarSuccess=0; else waitVarSuccess=E2Sucess-Math.pow(waitMeanSuccess,2);
		if (callsCanceled==0) waitVarCancel=0; else waitVarCancel=E2Cancel-Math.pow(waitMeanCancel,2);
		waitVarAll=E2All-Math.pow(waitMeanAll,2);

		waitStdSuccess=Math.sqrt(waitVarSuccess);
		waitStdCancel=Math.sqrt(waitVarCancel);
		waitStdAll=Math.sqrt(waitVarAll);

		/* Bedienzeiten */
		serviceMean=statisticSimData.serviceTimeSum/Math.max(1,callsSuccessful);
		serviceStd=Math.sqrt(statisticSimData.serviceTimeSqrSum/Math.max(1,callsSuccessful)-Math.pow(serviceMean,2));

		/* Verweilzeiten */
		systemMean=statisticSimData.systemTimeSum/Math.max(1,statisticSimData.calls);
		systemStd=Math.sqrt(statisticSimData.systemTimeSqrSum/Math.max(1,statisticSimData.calls)-Math.pow(systemMean,2));

		/* Warteschlange */
		int j=0;
		for (int i=0;i<statisticSimData.queueLengthTimes.length;i++) if (statisticSimData.queueLengthTimes[i]!=0) j=i;
		queueLengthMax=j;
		queueLengthTimes=new double[queueLengthMax+1];
		for (int i=0;i<=queueLengthMax;i++) queueLengthTimes[i]=statisticSimData.queueLengthTimes[i];

		double queueSum=0, E1Queue=0, E2Queue=0;
		for (int i=0;i<queueLengthTimes.length;i++) {
			queueSum+=queueLengthTimes[i];
			E1Queue+=i*queueLengthTimes[i];
			E2Queue+=Math.pow(i,2)*queueLengthTimes[i];
		}
		E1Queue/=queueSum;
		E2Queue/=queueSum;
		queueLengthMean=E1Queue;
		queueLengthVar=E2Queue-Math.pow(E1Queue,2);
		queueLengthStd=Math.sqrt(queueLengthVar);
		queueNoQueuePercent=queueLengthTimes[0]/queueSum*100;

		/* Kunden im System */
		j=0;
		for (int i=0;i<statisticSimData.systemLengthTimes.length;i++) if (statisticSimData.systemLengthTimes[i]!=0) j=i;
		systemLengthMax=j;
		systemLengthTimes=new double[systemLengthMax+1];
		for (int i=0;i<=systemLengthMax;i++) systemLengthTimes[i]=statisticSimData.systemLengthTimes[i];

		double systemSum=0, E1System=0, E2System=0;
		for (int i=0;i<systemLengthTimes.length;i++) {
			systemSum+=systemLengthTimes[i];
			E1System+=i*systemLengthTimes[i];
			E2System+=Math.pow(i,2)*systemLengthTimes[i];
		}
		E1System/=systemSum;
		E2System/=systemSum;
		systemLengthMean=E1System;
		systemLengthVar=E2System-Math.pow(E1System,2);
		systemLengthStd=Math.sqrt(systemLengthVar);

		/* Auslastung */
		loadAgentCount=simulator.staticSimData.agents;
		loadWorkingAgentTimes=new double[statisticSimData.freeAgentTimes.length];
		double freeSum=0;
		double meanFreeAgentsTemp=0, E1Load=0, E2Load=0;
		for (int i=0;i<statisticSimData.freeAgentTimes.length;i++) {
			freeSum+=statisticSimData.freeAgentTimes[i];
			E1Load+=i*statisticSimData.freeAgentTimes[statisticSimData.freeAgentTimes.length-1-i];
			E2Load+=Math.pow(i,2)*statisticSimData.freeAgentTimes[statisticSimData.freeAgentTimes.length-1-i];
			meanFreeAgentsTemp+=i*statisticSimData.freeAgentTimes[i];
			loadWorkingAgentTimes[loadWorkingAgentTimes.length-1-i]=statisticSimData.freeAgentTimes[i];
		}
		loadAllFreePercent=statisticSimData.freeAgentTimes[statisticSimData.freeAgentTimes.length-1]/freeSum*100;
		loadAllBusyPercent=statisticSimData.freeAgentTimes[0]/freeSum*100;

		meanFreeAgentsTemp/=freeSum;
		E1Load/=freeSum;
		E2Load/=freeSum;
		loadMeanWorkingAgents=E1Load;
		loadMeanWorkingAgentsPercent=E1Load/(statisticSimData.freeAgentTimes.length-1)*100;
		loadVarWorkingAgents=E2Load-Math.pow(E1Load,2);
		loadStdWorkingAgents=Math.sqrt(loadVarWorkingAgents);
		meanFreeAgents=meanFreeAgentsTemp;

		/* Interne Daten f�r das analytische Erlang-C Modell */
		inverseLambda=DistributionTools.getMean(simulator.staticSimData.interArrivalTimeDist);
		cvIB=DistributionTools.getCV(simulator.staticSimData.interArrivalTimeDist);
		inverseMu=DistributionTools.getMean(simulator.staticSimData.workingTimeDist);
		cvSB=DistributionTools.getCV(simulator.staticSimData.workingTimeDist);
		inverseNu=DistributionTools.getMean(simulator.staticSimData.waitingTimeDist);
		LambdaIsExp=(simulator.staticSimData.interArrivalTimeDist instanceof ExponentialDistribution);
		MuIsExp=(simulator.staticSimData.workingTimeDist instanceof ExponentialDistribution);
		NuIsExp=(simulator.staticSimData.waitingTimeDist instanceof ExponentialDistribution) || (simulator.staticSimData.waitingTimeDist instanceof NeverDistributionImpl);
		batchArrival=simulator.staticSimData.batchArrival;
		batchWorking=simulator.staticSimData.batchWorking;
	}

	/*
	private static double HalfConfidenceSize(double mean, double var, double n, double probability) {
		Bekannte Varianz: z_{(1+probability)/2}*stdvar/sqrt(n) , Phi(z_x)=x
		Unbekannte Varianz: t(probability/2,n-1)*stdvar/sqrt(n) t(x,n)=TDist^{-1}_n(1-x)
		try {
			NormalDistributionImpl d=new NormalDistributionImpl();
			return d.inverseCumulativeProbability((1+probability)/2)*Math.sqrt(var)/Math.max(Math.sqrt(n),1);

			TDistributionImpl d=new TDistributionImpl(Math.max(n-1,1));
			return d.inverseCumulativeProbability(1-probability/2)*Math.sqrt(var)/Math.max(Math.sqrt(n),1);
		} catch (MathException e) {return 0;}
	}
	 */

	/**
	 * Gibt die Daten zum Simulationssystem als String zur�ck
	 * @return Daten zum Simulationssystem
	 */
	public String getSystemData() {
		StringBuilder s=new StringBuilder("SYSTEM\n");
		s.append(String.format("Simulationslaufzeit: %,dms\n",systemRunTime));
		s.append(String.format("Ereignisse: %,d (Ereignisse/ms: %,d)\n",systemEvents,systemEventsPerMs));
		s.append(String.format("Rechenthreads: %d\n",systemThreads));
		s.append("\n");
		return s.toString();
	}

	/**
	 * Gibt die Daten zur Anzahl der Anrufe als String zur�ck
	 * @return Daten zur Anzahl der Anrufe
	 */
	public String getCallData() {
		StringBuilder s=new StringBuilder("ANRUFERZAHLEN\n");
		if (inputContinueProbability>0) {
			s.append(String.format("Anrufe (Ernstanrufer/Wiederholer/alle): %,d/%,d/%,d\n",callsFresh,callsRetrys,callsAll));
		} else {
			s.append(String.format("Anrufe: %,d\n",callsAll));
		}
		s.append(String.format("Erfolgsquote: %.1f%% (%,d Anrufer)\n",callsSuccessfulPercent,callsSuccessful));
		if (callsCanceled>0) s.append(String.format("Abbrecherqoute: P(A)=%.1f%% (%,d Anrufer)\n",callsCanceledPercent,callsCanceled));
		if (callsRejected>0) s.append(String.format("Besetztzeichenquote: %.1f%% (%,d Anrufer)\n",callsRejectedPercent,callsRejected));
		if (callsSuccessful>callsAll) {
			s.append("(Da die Anruferz�hlung erst nach der Einschwingphase, also zu einem Zeitpunkt,\n");
			s.append("an dem die Warteschlange nicht leer sein muss, beginnt, k�nnen in der Statistik\n");
			s.append("mehr bediente Anrufer als Erstanrufer auftreten.)\n");
		}
		s.append("\n");

		s.append("ZWISCHENANKUNFTSZEITEN\n");
		s.append(String.format("Mittlere Zwischenankunftszeit: E[I]=%.3f\n",interarrivalMean));
		s.append(String.format("Std.Abweichung: Std[I]=%.3f\n",interarrivalStd));
		if (batchArrival>1) s.append("(Die Angaben beziehen sich auf die Abst�nde zwischen einzenen Kunden, nicht zwischen den Gruppen.)\n");
		s.append("\n");

		return s.toString();
	}

	/**
	 * Gibt Daten zu den Wartezeiten als String zur�ck
	 * @return Daten zu den Wartezeiten
	 */
	public String getWaitingData() {
		StringBuilder s=new StringBuilder("WARTEZEITEN\n");
		if (waitCalls>0) s.append(String.format("Anteil der Anrufer, der warten musste: %.1f%% (%,d Anrufer)\n",waitCallsPercent,waitCalls));
		if (callsCanceled>0) {
			s.append(String.format("Mittlere Wartezeit/Abbruchzeit/�ber alle: E[W]=%.3f/E[A]=%.3f/%.3f\n",waitMeanSuccess,waitMeanCancel,waitMeanAll));

			s.append(String.format("Std.Abweichung Wartezeit/Abbruchzeit/�ber alle: Std[W]=%.3f/Std[A]=%.3f/%.3f\n",waitStdSuccess,waitStdCancel,waitStdAll));
			/*
			Die Anrufer sind nicht unabh�ngig.
			s.append("95%-Konfidentintervalle: ");
			double CSuccess=HalfConfidenceSize(waitMeanSuccess,waitVarSuccess,callsSuccessful,0.95);
			double CCancel=HalfConfidenceSize(waitMeanCancel,waitVarCancel,callsCanceled,0.95);
			double CAll=HalfConfidenceSize(waitMeanAll,waitVarAll,callsSuccessfull+callsCanceled,0.95);
			s.append(String.format("[%.3f;%.3f]",waitMeanSuccess-CSuccess,waitMeanSuccess+CSuccess)+"/");
			s.append(String.format("[%.3f;%.3f]",waitMeanCancel-CCancel,waitMeanCancel+CCancel)+"/");
			s.append(String.format("[%.3f;%.3f]",waitMeanAll-CAll,waitMeanAll+CAll)+"\n");
			 */
		} else {
			s.append(String.format("Mittlere Wartezeit: E[W]=%.3f\n",waitMeanSuccess));
			s.append(String.format("Std.Abweichung: Std[W]=%.3f\n",waitStdAll));
			/* double CSuccess=HalfConfidenceSize(waitMeanSuccess,waitVarSuccess,callsSuccessful,0.95);
			s.append(String.format("95%-Konfidentintervalle: [%.3f;%.3f]\n",waitMeanSuccess-CSuccess,waitMeanSuccess+CSuccess)); */
		}
		s.append("\n");

		s.append("BEDIENZEITEN\n");
		s.append(String.format("Mittlere Bedienzeit: E[S]=%.3f\n",serviceMean));
		s.append(String.format("Std.Abweichung der Bedienzeit: Std[S]=%.3f\n",serviceStd));
		s.append("\n");

		s.append("VERWEILZEITEN\n");
		s.append(String.format("Mittlere Verweilzeit: E[V]=%.3f\n",systemMean));
		s.append(String.format("Std.Abweichung der Verweilzeit: Std[V]=%.3f\n",systemStd));
		s.append("\n");

		return s.toString();
	}

	/**
	 * Gibt Daten zu der Warteschlange als String zur�ck
	 * @return Daten zu der Warteschlange
	 */
	public String getQueueData() {
		StringBuilder s=new StringBuilder("WARTESCHLANGE\n");
		s.append(String.format("Mittlere Warteschlangenl�nge: E[NQ]=%.3f\n",queueLengthMean));
		s.append(String.format("Std.Abweichung der Warteschlangenl�nge: Std[NQ]=%.3f\n",queueLengthStd));
		s.append(String.format("Zeitanteil, in dem die Schlange leer war: %.3f%%\n",queueNoQueuePercent));
		s.append(String.format("Maximale Warteschlangenl�nge: %d\n",queueLengthMax));
		s.append("\n");

		s.append("KUNDEN IM SYSTEM\n");
		s.append(String.format("Mittlere Anzahl an Kunden im System: E[N]=%.3f\n",systemLengthMean));
		s.append(String.format("Std.Abweichung der Anzahl an Kunden im System: Std[N]=%.3f\n",systemLengthStd));
		s.append("\n");

		return s.toString();
	}

	/**
	 * Gibt Daten zur Auslastung der Agenten als String zur�ck
	 * @return Daten zur Auslastung der Agenten
	 */
	public String getLoadData() {
		StringBuilder s=new StringBuilder("AUSLASTUNG\n");

		s.append(String.format("Leerlaufanteil: %.3f%%",loadAllFreePercent)+" (kein aktives Gespr�ch)\n");
		s.append(String.format("Volllastanteil: %.3f%%",loadAllBusyPercent)+" (alle Agenten belegt)\n");
		s.append(String.format("Mittlere Anzahl an Kunden in Bedienung: E[B]=%.3f\n",loadMeanWorkingAgents*batchWorking));
		s.append(String.format("Mittlere Anzahl an besch�ftigten Agenten: %.3f (rho=%.3f%%)\n",loadMeanWorkingAgents,loadMeanWorkingAgentsPercent));
		s.append(String.format("Std.Abweichung der Anzahl an besch�ftigten Agenten: %.3f\n",loadStdWorkingAgents));
		s.append(String.format("Mittlere Anzahl an Agenten im Leerlauf: %.3f",meanFreeAgents)+"\n");
		s.append("\n");
		return s.toString();
	}

	/**
	 * Gibt mit dem Erlang C Modell berechnete Vergleichsdaten als String zur�ck
	 * @return Mit dem Erlang C Modell berechnete Vergleichsdaten zu der Simulation
	 * @see getErlangCInfoData
	 */
	public String getErlangCData() {
		StringBuilder s=new StringBuilder("ANALYTISCHE ERLANG-C MODELLE\n");

		int K; if (inputWaitingRoomSize==Integer.MAX_VALUE) K=Integer.MAX_VALUE; else K=inputWaitingRoomSize+inputAgents;
		double lambda=1/inverseLambda*batchArrival;
		double mu=1/inverseMu*batchWorking;
		double nu=1/inverseNu;

		if (callsCanceled>0) {
			s.append(String.format("Wartezeit (ohne Ber�cksichtigung der Abbrecher): %.3f\n",ErlangC.waitingTimeExt(lambda,mu,0,inputAgents,K)));
			s.append(String.format("Wartezeit (mit Ber�cksichtigung der Abbrecher): %.3f\n",ErlangC.waitingTimeExt(lambda,mu,nu,inputAgents,K)));
		} else {
			s.append(String.format("Wartezeit (ohne Ber�cksichtigung der Abbrecher): %.3f\n",ErlangC.waitingTimeExt(lambda,mu,0,inputAgents,K)));
		}
		if (inputContinueProbability>0) s.append(String.format("Wartezeit (Abbrecher+Weiterleitungsapproximation): %.3f\n",ErlangC.waitingTimeExt(lambda*(1+inputContinueProbability),mu,nu,inputAgents,K)));

		s.append("\n");
		return s.toString();
	}

	private double powerFactorial(double a, long c) {
		/* a^c/c! */
		double result=1;
		for (int i=1;i<=c;i++) result*=(a/i);
		return result;
	}

	/**
	 * Gibt mit dem Allen Cunnen Modell berechnete Vergleichsdaten als String zur�ck
	 * @return Mit dem Allen Cunnen Modell berechnete Vergleichsdaten zu der Simulation
	 */
	public String getACData() {
		StringBuilder s=new StringBuilder("ALLEN-CUNNEN-N�HERUNGSFORMEL\n");

		double lambda=1/inverseLambda;
		long bI=batchArrival;
		double muInv=inverseMu;
		long c=inputAgents;
		long b=batchWorking;

		/* Umrechnung von Arrival-Batches auf einzelne Kunden */
		lambda=lambda*bI;
		double cvI=Math.sqrt(bI*cvIB*cvIB+bI-1);

		double rho=lambda*muInv/(b*c);

		/*
		PC1=(c*rho)^c/(c!(1-rho));
		PC=PC1/(PC1+sum(k=0...c-1; (c*rho)^k/k!))
		E[NQ]=rho/(1-rho)*PC*(SCV[I]+b*SCV[S])/2+(b-1)/2
		E[N]=E[NQ]+b*c*rho
		 */

		double PC1=powerFactorial(c*rho,c)/(1-rho);
		double PC=0; for(int i=0;i<=c-1;i++) PC+=powerFactorial(c*rho,i);
		PC=PC1/(PC1+PC);

		double ENQ=rho/(1-rho)*PC*(cvI*cvI+b*cvSB*cvSB)/2+(((double)b)-1)/2;
		double EN=ENQ+((double)b)*((double)c)*rho;
		double EW=ENQ/lambda;
		double EV=EW+muInv;

		s.append(String.format("Mittlere Auslastung rho=%.3f%%\n",rho*100));
		s.append(String.format("Mittlere Anzahl an Kunden im System: E[N]=%.3f\n",EN));
		s.append(String.format("Mittlere Warteschlangenl�nge: E[NQ]=%.3f\n",ENQ));
		s.append(String.format("Mittlere Anzahl an Kunden in Bedienung: E[B]=%.3f\n",rho*c*b));
		s.append(String.format("Mittlere Verweilzeit: E[V]=%.3f\n",EV));
		s.append(String.format("Mittlere Wartezeit: E[W]=%.3f\n",EW));
		s.append(String.format("Mittlere Bedienzeit: E[S]=%.3f\n",muInv));

		s.append("\n");
		return s.toString();
	}

	/**
	 * Gibt Informationen dar�ber als String zur�ck, ob sich das Modell vollst�ndig durch das Erlang C Modell beschreiben l�sst bzw. wodurch mit Abweichungen zu rechnen ist
	 * @return	Informationen zu �bereinstimmungen und Abweichungen zwischen Erlang C Modell und dem konkreten Modell
	 * @see getErlangCData
	 */
	public String getErlangCInfoData() {
		StringBuilder s=new StringBuilder("");

		if (inputContinueProbability>0) s.append("* Weiterleitungen k�nnen nur approximativ erfasst werden.\n");
		if (inputRetryProbability>0) s.append("* Wahlwiederholungen k�nnen im Erlang-C Modell nicht erfasst werden.\n");
		if (!LambdaIsExp) s.append("* In den analytischen Modellen werden die Zwischenankunftszeiten stets als exponentiell verteilt angenommen.\n");
		if (!MuIsExp) s.append("* In den analytischen Modellen werden die Bedienzeiten stets als exponentiell verteilt angenommen.\n");
		if (!NuIsExp) s.append("* In den analytischen Modellen werden die Wartezeittoleranzen stets als exponentiell verteilt angenommen.\n");
		if (batchArrival>1) s.append("* In den analytischen Modellen werden keine Gruppenank�nfte ber�cksichtigt.\n");
		if (batchWorking>1)s.append("* In den analytischen Modellen werden keine Gruppenbedienungen ber�cksichtigt.\n");
		if (s.toString().isEmpty()) s.append("Das Modell kann vollst�ndig analytisch beschrieben werden.\n"); else s.insert(0,"Aufgrund folgender Eigenschaften kann das Modell nicht vollst�ndig analytisch beschrieben werden:\n");

		s.append("\n");
		return "VERGLEICH SIMULATION UND ANALYTISCHES ERLANG-C MODELL\n"+s.toString();
	}

	/**
	 * Liefert alle Informationen zu der Simulation als String zur�ck
	 * @return	Informationen zu der gesamten Simulation
	 * @see getSystemData
	 * @see getSystemData
	 * @see getWaitingData
	 * @see getQueueData
	 * @see getLoadData
	 * @see getErlangCData
	 * @see getErlangCInfoData
	 */
	public String getAllData() {
		StringBuilder s=new StringBuilder();
		s.append(getSystemData());
		s.append(getCallData());
		s.append(getWaitingData());
		s.append(getQueueData());
		s.append(getLoadData());
		s.append(getErlangCData());
		s.append(getErlangCInfoData());
		s.append(getACData());
		return s.toString();
	}
}
