package callcenter;

import simcore.SimData;
import simcore.SimulatorBase;
import simcore.eventcache.HashMapEventCache;
import simcore.eventmanager.PriorityQueueEventManager;

/**
 * Von <code>Simulator</code> abgeleitete Klasse zur Simulation von Callcentern.
 * Dem Konstruktor wird eine Referenz auf die statischen Simulationsdaten �bergeben,
 * woraus diese Klasse f�r jeden Thread ein eigenes Simulationsdatenobjekt (bestehend
 * aus statischen und dynamischen Daten) erstellt.
 * @author Alexander Herzog
 * @version 1.0
 * @see Simulator
 */
public final class CallcenterSimulator extends SimulatorBase {

	/**
	 * Lesezugriff auf das bei der Simulation verwendete statische Simulationsdatenobjekt
	 */
	public final CallcenterStaticSimData staticSimData;

	/**
	 * Konstruktor der Klasse <code>CallcenterSimulator</code>
	 * @param staticSimData Referenz auf die statischen Daten f�r die Simulation.
	 * @see CallcenterStaticSimData
	 */
	public CallcenterSimulator(CallcenterStaticSimData staticSimData) {
		super();
		this.staticSimData=staticSimData;
	}

	@Override
	protected SimData getSimDataForThread(int threadNr, int threadCount) {
		CallcenterSimData simData=new CallcenterSimData(new PriorityQueueEventManager(),new HashMapEventCache(),threadNr,threadCount,staticSimData);
		simData.scheduleCall(0,true);
		return simData;
	}

	/**
	 * F�hrt nach dem Ende der Simulation die Statistikdaten der einzelnen Threads zusammen und
	 * gibt diese als gemeinsames Objekt des Typs <code>CallcenterStatisticSimData</code> zur�ck.
	 * @return Statistikobjekt mit Daten, die von allen Threads zusammengef�hrt wurden.
	 */
	public final CallcenterStatisticSimData collectStatistic() {
		CallcenterStatisticSimData statisticSimData=new CallcenterStatisticSimData(staticSimData.agents,staticSimData.batchWorking,Math.min(staticSimData.waitingRoomSize,10000));
		for (int i=0;i<threads.length;i++) statisticSimData.addData(((CallcenterSimData)threads[i].simData).statisticSimData);
		return 	statisticSimData;
	}

	/**
	 * Erstellt ein <code>CallcenterSimulator</code> und f�hrt die Simulation ohne die M�glichkeit
	 * der Unterbrechung aus. Dabei werden als Fortschrittsbalken Punkte in der Console ausgegeben.
	 * Nach dem Ende der Simulation liefert diese statische Methode das CallcenterSimulator-Objekt zur�ck,
	 * so dass eine Auswertung der Statistik erfolgen kann.
	 * @param staticSimData	Referenz auf die statischen Daten f�r die Simulation.
	 * @return Objekt vom Typ <code>CallcenterSimulator</code>, aus dem die Statistikdaten ausgelesen werden k�nnen.
	 */
	@Deprecated
	public static CallcenterSimulator CreateAndRunSimpleSimulator(CallcenterStaticSimData staticSimData) {
		CallcenterSimulator simulator=new CallcenterSimulator(staticSimData);
		simulator.startAndRunAndFinalizeSimulator(true);
		return simulator;
	}

	/**
	 * Erzeugt und simuliert ein M/M/10/infty Callcenter.<br>
	 * Die Ergebnisse werden direkt in der Console ausgegeben.
	 * @return	Objekt vom Typ <code>CallcenterSimulator</code>, das zur Simulation verwendet wurde.
	 */
	@Deprecated
	public static CallcenterSimulator TestSimpleCallcenter1() {
		int inversLambda=1050;
		int inversMu=10000;
		int c=10;
		CallcenterStaticSimData staticSimData=CallcenterStaticSimData.CreateMMcinf(inversLambda,inversMu,c,7000000);
		CallcenterSimulator simulator=CallcenterSimulator.CreateAndRunSimpleSimulator(staticSimData);
		System.out.println(new CallcenterStatisticOutput(simulator).getAllData());
		return simulator;
	}

	/**
	 * Erzeugt und simuliert ein M/M/10/infty+M Callcenter.<br>
	 * Die Ergebnisse werden direkt in der Console ausgegeben.
	 * @return	Objekt vom Typ <code>CallcenterSimulator</code>, das zur Simulation verwendet wurde.
	 */
	@Deprecated
	public static CallcenterSimulator TestSimpleCallcenter2() {
		double inversLambda=1250;
		double inversMu=10000;
		double inversNu=5000;
		int c=10;
		CallcenterStaticSimData staticSimData=CallcenterStaticSimData.CreateMMcinfM(inversLambda,inversMu,inversNu,c,10000000);
		CallcenterSimulator simulator=CallcenterSimulator.CreateAndRunSimpleSimulator(staticSimData);
		System.out.println(new CallcenterStatisticOutput(simulator).getAllData());
		return simulator;
	}

	/**
	 * Erzeugt und simuliert ein M/M/10/infty+M Callcenter mit Wiederholern und Weiterleitungen.<br>
	 * Die Ergebnisse werden direkt in der Console ausgegeben.
	 * @return	Objekt vom Typ <code>CallcenterSimulator</code>, das zur Simulation verwendet wurde.
	 */
	@Deprecated
	public static CallcenterSimulator TestSimpleCallcenter3() {
		double inversLambda=1250;
		double inversMu=10000;
		double inversNu=50000;
		double inversDelta=2000;
		double pContinue=0.1;
		double pRetry=0.4;
		int c=10;
		CallcenterStaticSimData staticSimData=CallcenterStaticSimData.CreateFullM(inversLambda,inversMu,inversNu,inversDelta,c,pContinue,pRetry,1000000);
		CallcenterSimulator simulator=CallcenterSimulator.CreateAndRunSimpleSimulator(staticSimData);
		System.out.println(new CallcenterStatisticOutput(simulator).getAllData());
		return simulator;
	}
}
