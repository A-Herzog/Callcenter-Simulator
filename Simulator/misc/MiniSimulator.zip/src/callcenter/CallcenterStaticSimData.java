package callcenter;


import org.apache.commons.math3.distribution.AbstractRealDistribution;
import org.apache.commons.math3.distribution.ExponentialDistribution;

import mathtools.distribution.NeverDistributionImpl;
import mathtools.distribution.tools.DistributionRandomNumber;

/**
 * Diese Klasse speichert alle statischen Daten f�r den Simulationsprozess.
 * Ein und dasselbe Objket dieses Typs wird alle <code>CallcenterSimData</code> Objekte,
 * die an die Rechenthreads �bergeben werden, eingebaut.
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallcenterStaticSimData {
	/**
	 * Zwischenankunftzeitverteilung
	 */
	public final AbstractRealDistribution interArrivalTimeDist;

	/**
	 * Kunden treffen nicht einzeln, sondern in Batches dieser Gr��en ein.
	 */
	public final int batchArrival;

	/**
	 * Wartezeittoleranzverteilung
	 */
	public final AbstractRealDistribution waitingTimeDist;

	/**
	 * Bedienzeitverteilung
	 */
	public final AbstractRealDistribution workingTimeDist;

	/**
	 * Ein Agent arbeitet steht so viele Kunden gleichzeitig ab. Sind nicht genug Kunden vorhanden, m�ssen die anwesenden Kunden weiter warten.
	 */
	public final int batchWorking;

	/**
	 * Wiederholabst�ndeverteilung
	 */
	public final AbstractRealDistribution retryTimeDist;

	/**
	 * Faktor zwischen der Ganzzahl-Zeitberechnung im Simulationsprozess (<code>long</code>)
	 * und den Verteilungsfunktionen bzw. der Statistik (<code>double</code> mit Sekundenbasis)
	 */
	public final static long timeBase=1000000; /* Factor between long and double */

	/**
	 * Anzahl an Callcenter-Agenten
	 */
	public final int agents;

	/**
	 * Weiterleitungswahrscheinlichkeit
	 */
	public final double callContinueProbability;

	/**
	 * Wiederholwahrscheinlichkeit (nach Besetztzeichen oder Warteabbruch)
	 */
	public final double retryProbability;

	/**
	 * Anzahl der zu simulierenden Erstanrufe
	 */
	public final double callsToSimulate;

	/**
	 * Gr��e des Warteraums (ein in Bedienung befindlicher Anrufer belegt keinen Warteraum mehr)
	 */
	public final int waitingRoomSize;

	/**
	 * Anzahl an zu simulierenden Anrufen, bevor die <code>callsToSimulate</code>-Z�hlung beginnt.<br>
	 * Die bis zu diesem Zeitpunkt gesammelten Statistikdaten werden verworfen und die Z�hlung zu
	 * diesem Zeitpunkt neu gestartet.
	 */
	public final int warmUpCalls;

	/**
	 * Konstuktor der Klasse <code>CallcenterStaticSimData</code>
	 * @param agents	Anzahl an Callcenter-Agenten
	 * @param interArrivalTimeDist	Zwischenankunftzeitverteilung
	 * @param batchArrival	Kunden treffen nicht einzeln, sondern in Batches dieser Gr��en ein.
	 * @param waitingTimeDist	Wartezeittoleranzverteilung
	 * @param workingTimeDist	Bedienzeitverteilung
	 * @param batchWorking	batchWorking
	 * @param callContinueProbability	Weiterleitungswahrscheinlichkeit
	 * @param retryProbability	Wiederholwahrscheinlichkeit (nach Besetztzeichen oder Warteabbruch)
	 * @param retryTimeDist	Wiederholabst�ndeverteilung
	 * @param callsToSimulate	Anzahl der zu simulierenden Erstanrufe
	 * @param waitingRoomSize	Gr��e des Warteraums (ein in Bedienung befindlicher Anrufer belegt keinen Warteraum mehr)
	 * @param warmUpCalls	Anzahl an zu simulierenden Anrufen, bevor die <code>callsToSimulate</code>-Z�hlung beginnt.
	 */
	public CallcenterStaticSimData(int agents, AbstractRealDistribution interArrivalTimeDist, int batchArrival, AbstractRealDistribution waitingTimeDist, AbstractRealDistribution workingTimeDist, int batchWorking, double callContinueProbability, double retryProbability, AbstractRealDistribution retryTimeDist, long callsToSimulate, int waitingRoomSize, int warmUpCalls) {
		this.agents=agents;
		this.interArrivalTimeDist=interArrivalTimeDist;
		this.batchArrival=batchArrival;
		this.waitingTimeDist=waitingTimeDist;
		this.workingTimeDist=workingTimeDist;
		this.batchWorking=batchWorking;
		this.callContinueProbability=callContinueProbability;
		this.retryProbability=retryProbability;
		this.retryTimeDist=retryTimeDist;
		this.callsToSimulate=callsToSimulate;
		this.waitingRoomSize=waitingRoomSize;
		this.warmUpCalls=warmUpCalls;
	}

	/**
	 * Liefert eine Zufallszahl gem�� Zwischenankunftszeitverteilung
	 * (bereits umgerechnet in einen <code>long</code>-Wert f�r die Simulation)
	 * @return	Zuf�llige Zwischenankunftszeit
	 */
	public final long getInterArrivalTime() {return (long)(timeBase*DistributionRandomNumber.randomNonNegative(interArrivalTimeDist));}

	/**
	 * Liefert eine Zufallszahl gem�� Wartezeittoleranzverteilung
	 * (bereits umgerechnet in einen <code>long</code>-Wert f�r die Simulation)
	 * @return	Zuf�llige Wartezeittoleranz
	 */
	public final long getWaitingToleranceTime() {return (long)(timeBase*DistributionRandomNumber.randomNonNegative(waitingTimeDist));}

	/**
	 * Liefert eine Zufallszahl gem�� Bedienzeitenverteilung
	 * (bereits umgerechnet in einen <code>long</code>-Wert f�r die Simulation)
	 * @return	Zuf�llige Bedienzeit
	 */
	public final long getWorkingTime() {return (long)(timeBase*DistributionRandomNumber.randomNonNegative(workingTimeDist));}

	/**
	 * Liefert eine Zufallszahl gem�� Wiederholabst�ndeverteilung
	 * (bereits umgerechnet in einen <code>long</code>-Wert f�r die Simulation)
	 * @return	Zuf�lliger Wiederholabstand
	 */
	public final long getRetryTime() {return (long)(timeBase*DistributionRandomNumber.randomNonNegative(retryTimeDist));}

	/**
	 * Erstellt ein <code>CallcenterStaticSimData</code>-Objekt f�r ein einfaches M/M/c/infty Callcenter
	 * @param inversLambda	Inverse Ankunftsrate
	 * @param inversMu	Inverse Bedienrate
	 * @param c	Anzahl an Agenten
	 * @param callsToSimulate	Anzahl der zu simulierenden Anrufe
	 * @return
	 */
	public static CallcenterStaticSimData CreateMMcinf(double inversLambda, double inversMu, int c, long callsToSimulate) {
		return new CallcenterStaticSimData(
				/* agents */ c,
				/* InterArrivalTimeDist */ new ExponentialDistribution(inversLambda),
				/* batchArrival */ 1,
				/* WaitingTimeDist */ new NeverDistributionImpl(),
				/* WorkingTimeDist */ new ExponentialDistribution(inversMu),
				/* batchWorking */ 1,
				/* P(continue) */ 0,
				/* P(retry) */ 0,
				/* RetryTimeDist */ new ExponentialDistribution(1000),
				/* Calls to simulate */ callsToSimulate,
				/* K */ Integer.MAX_VALUE,
				/* WarmUpCalls */ (int)Math.max(callsToSimulate/10,100000)
				);
	}

	/**
	 * Erstellt ein <code>CallcenterStaticSimData</code>-Objekt f�r ein einfaches M/M/c/infty+M Callcenter
	 * @param inversLambda	Inverse Ankunftsrate
	 * @param inversMu	Inverse Bedienrate
	 * @param inversNu Inverse Warteabbruchrate
	 * @param c	Anzahl an Agenten
	 * @param callsToSimulate	Anzahl der zu simulierenden Anrufe
	 * @return
	 */
	public static CallcenterStaticSimData CreateMMcinfM(double inversLambda, double inversMu, double inversNu, int c, long callsToSimulate) {
		return new CallcenterStaticSimData(
				/* agents */ c,
				/* InterArrivalTimeDist */ new ExponentialDistribution(inversLambda),
				/* batchArrival */ 1,
				/* WaitingTimeDist */ new ExponentialDistribution(inversNu),
				/* WorkingTimeDist */ new ExponentialDistribution(inversMu),
				/* batchWorking */ 1,
				/* P(continue) */ 0,
				/* P(retry) */ 0,
				/* RetryTimeDist */ new ExponentialDistribution(1000),
				/* Calls to simulate */ callsToSimulate,
				/* K */ Integer.MAX_VALUE,
				/* WarmUpCalls */ (int)Math.max(callsToSimulate/10,100000)
				);
	}

	/**
	 * Erstellt ein <code>CallcenterStaticSimData</code>-Objekt f�r ein einfaches M/M/c/infty+M Callcenter mit Weiterleitungen und Wiederholern
	 * @param inversLambda	Inverse Ankunftsrate
	 * @param inversMu	Inverse Bedienrate
	 * @param inversNu Inverse Warteabbruchrate
	 * @param inversDelta Inverse Wiederholrate
	 * @param c	Anzahl an Agenten
	 * @param pContinue	Weiterleitungswahrscheinlichkeit
	 * @param pRetry	Wiederholwahrscheinlichkeit (nach Warteabbruch)
	 * @param callsToSimulate	Anzahl der zu simulierenden Anrufe
	 * @return
	 */
	public static CallcenterStaticSimData CreateFullM(double inversLambda, double inversMu, double inversNu, double inversDelta, int c, double pContinue, double pRetry, long callsToSimulate) {
		return new CallcenterStaticSimData(
				/* agents */ c,
				/* InterArrivalTimeDist */ new ExponentialDistribution(inversLambda),
				/* batchArrival */ 1,
				/* WaitingTimeDist */ new ExponentialDistribution(inversNu),
				/* WorkingTimeDist */ new ExponentialDistribution(inversMu),
				/* batchWorking */ 1,
				/* P(continue) */ pContinue,
				/* P(retry) */ pRetry,
				/* RetryTimeDist */ new ExponentialDistribution(inversDelta),
				/* Calls to simulate */ callsToSimulate,
				/* K */ Integer.MAX_VALUE,
				/* WarmUpCalls */ (int)Math.max(callsToSimulate/10,100000)
				);
	}
}
