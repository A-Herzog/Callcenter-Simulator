package callcenter.events;

import java.util.concurrent.ThreadLocalRandom;

import callcenter.CallcenterSimData;
import callcenter.CallcenterStaticSimData;
import simcore.Event;
import simcore.SimData;

/**
 * Anruf-Ereignis w�hrend der Callcenter-Simulation
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallEvent extends Event {
	/**
	 * Legt fest, ob es sich um einen neuen Anruf oder um eine Wiederholung handelt (relevant f�r die Statistik)
	 */
	public boolean isNewCall;

	@Override
	public final void run(SimData data) {
		CallcenterSimData simData=(CallcenterSimData)data;

		for (int i=1;i<=simData.staticSimData.batchArrival;i++)
			simData.logIncomingCall(time,isNewCall);

		/* N�chsten Anruf in Eventliste einf�gen und Zwischenankunftszeit in Statistik erfassen */
		if (isNewCall) {
			if ((simData.staticSimData.callsToSimulate<0) || (simData.staticSimData.callsToSimulate/simData.threadCount>simData.statisticSimData.freshCalls)) {
				final long time=simData.staticSimData.getInterArrivalTime();
				final double d=(double)time/CallcenterStaticSimData.timeBase;
				simData.statisticSimData.interarrivalTimeSum+=d;
				simData.statisticSimData.interarrivalTimeSumSqr+=d*d;
				/* Bei Batches hier noch ein paar mal +=0 f�r die 0-Abst�nde zwischen den Kunden in den Batches */
				simData.scheduleCall(time,true);
			} else {
				/* Bei Gruppenbedienungen muss ggf. die Warteschlange geleert werden, wenn am Ende kein ganzer Batch mehr zusammen kommt. */
				if (simData.staticSimData.batchWorking>1) simData.scheduleStopTest();
			}
		}

		for (int i=1;i<=simData.staticSimData.batchArrival;i++) {
			if (simData.dynamicSimData.freeAgents>0 && simData.dynamicSimData.waitingCalls.size()+1>=simData.staticSimData.batchWorking) {
				/* Anrufer muss nicht warten */
				long workingTime=simData.tryStartCall(time,true,true,0);
				simData.logSuccessfulCall(0,workingTime);
				for (int j=2;j<=simData.staticSimData.batchWorking;j++) {
					/* Weitere Bedienprozesse im Batch beginnen */
					CallCancelEvent cancelEvent=simData.dynamicSimData.waitingCalls.poll();
					workingTime=simData.tryStartCall(time,false,false,workingTime);
					long waitingTime=time-cancelEvent.waitingStartTime;
					if (waitingTime==0) simData.statisticSimData.callsNeededToWait--;
					simData.logSuccessfulCall(waitingTime,workingTime);
					simData.eventManager.deleteEvent(cancelEvent,simData);
				}
				continue;
			}

			/* Anrufer wird nicht sofort bedient */
			simData.statisticSimData.callsNeededToWait++;

			if (simData.dynamicSimData.waitingCalls.size()<simData.staticSimData.waitingRoomSize) {
				/* Warten beginnt */
				simData.scheduleCallCancel(simData.staticSimData.getWaitingToleranceTime());
			} else {
				/* Keine freien Wartepl�tze */
				simData.statisticSimData.rejectedCalls++;
				simData.logCallCancel(time,0);
				if (ThreadLocalRandom.current().nextDouble()<simData.staticSimData.retryProbability) {
					simData.statisticSimData.retrys++;
					simData.scheduleCall(simData.staticSimData.getRetryTime(),false);
				}
			}
		}
	}
}
