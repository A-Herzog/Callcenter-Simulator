package callcenter.events;

import java.util.concurrent.ThreadLocalRandom;

import callcenter.CallcenterSimData;
import simcore.Event;
import simcore.SimData;

/**
 * Warteabbruch-Ereignis bei der Callcenter-Simulation
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallCancelEvent extends Event {
	/**
	 * Beginn der Wartezeit (relevant f�r die Statistik)
	 */
	public long waitingStartTime;

	/**
	 * (Re-)Initialisierung des Warteabbruch-Ereignisses
	 * @param now	Aktuelle Systemzeit
	 * @param time	Zeitpunkt, zu dem der Warteabbruch erfolgen soll
	 */
	public final void init(long now, long time) {super.init(time); waitingStartTime=now;}

	@Override
	public final void run(SimData data) {
		CallcenterSimData simData=(CallcenterSimData)data;
		simData.logCallCancel(time,time-waitingStartTime);

		simData.dynamicSimData.waitingCalls.remove(this);

		if (ThreadLocalRandom.current().nextDouble()<simData.staticSimData.retryProbability) {
			simData.statisticSimData.retrys++;
			simData.scheduleCall(simData.staticSimData.getRetryTime(),false);
		}
	}
}
