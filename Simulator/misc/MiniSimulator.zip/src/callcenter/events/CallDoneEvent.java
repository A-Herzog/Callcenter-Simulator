package callcenter.events;

import java.util.concurrent.ThreadLocalRandom;

import callcenter.CallcenterSimData;
import simcore.Event;
import simcore.SimData;

/**
 * Ereignis, das beim Ende eines Anrufs bei der Callcenter-Simulation ausgef�hrt wird.<br>
 * (Durch dieses Ereignis wird u.a. gepr�ft, ob es wartende Kunden gibt und ggf. der n�chste Bedienprozess gestartet.)
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallDoneEvent extends Event {
	public boolean firstOfBatch;

	@Override
	public final void run(SimData data) {
		CallcenterSimData simData=(CallcenterSimData)data;
		simData.logDistDataChange(time);

		/* Agent ist wieder frei */
		if (firstOfBatch) simData.dynamicSimData.freeAgents++;

		/* Weiterleitung ? */
		if (ThreadLocalRandom.current().nextDouble()<simData.staticSimData.callContinueProbability) {
			simData.scheduleCall(0,false);
		}

		/* Kunden zum Bedienen in der Warteschlange ? */
		if (simData.dynamicSimData.freeAgents>0 && simData.dynamicSimData.waitingCalls.size()>=simData.staticSimData.batchWorking)	{
			long workingTime=-10;
			for (int i=1;i<=simData.staticSimData.batchWorking;i++) {
				CallCancelEvent cancelEvent=simData.dynamicSimData.waitingCalls.poll();
				workingTime=simData.tryStartCall(time,false,i==1,workingTime);
				assert(workingTime>=0);
				simData.logSuccessfulCall(time-cancelEvent.waitingStartTime,workingTime);
				simData.eventManager.deleteEvent(cancelEvent,simData);
			}
		}
	}
}
