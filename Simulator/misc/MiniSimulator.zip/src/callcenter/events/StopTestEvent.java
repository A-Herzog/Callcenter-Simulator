package callcenter.events;

import callcenter.CallcenterSimData;
import simcore.Event;
import simcore.SimData;

/**
 * Pr�ft, ob sich noch Kunden in der Warteschlange befinden, die nicht mehr bedient werden k�nnen
 * (weil die Anzahl zu klein ist, um noch einen Batch zu bilden.
 * In diesem Fall wird die Warteschlange geleert.
 * @author Alexander Herzog
 * @version 1.0
 */
public class StopTestEvent extends Event {

	@Override
	public void run(SimData data) {
		CallcenterSimData simData=(CallcenterSimData)data;

		/* Keiner mehr da? - Um so besser. Nichts tun, Simulation endet. */
		if (simData.dynamicSimData.waitingCalls.size()==0) return;

		if (simData.dynamicSimData.freeAgents==simData.staticSimData.agents) {
			/* Warteschlange leeren, da Agenten frei sind, aber Kunden dennoch nicht bedient werden. */
			while (simData.dynamicSimData.waitingCalls.size()>0) {
				CallCancelEvent cancelEvent=simData.dynamicSimData.waitingCalls.poll();
				simData.eventManager.deleteEvent(cancelEvent,simData);
				simData.statisticSimData.successful++; /* Etwas gemogelt: Die Kunden waren nicht erfolgreich; aber Abbrecher sind sie ja auch nicht. */
			}
		} else {
			/* Sp�ter noch einmal pr�fen. */
			simData.scheduleStopTest();
		}
	}
}
