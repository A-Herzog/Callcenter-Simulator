package callcenter;

import org.apache.commons.math3.distribution.AbstractRealDistribution;

import callcenter.events.CallCancelEvent;
import callcenter.events.CallDoneEvent;
import callcenter.events.CallEvent;
import callcenter.events.StopTestEvent;
import simcore.SimData;
import simcore.eventcache.EventCache;
import simcore.eventmanager.EventManager;

/**
 * Diese Klasse ist eine Callcenter-Simulations-spezifische Ableitung aus der Klasse <code>SimData</code>.
 * Sie enth�lt drei Unterobjekte zur Speicherung der statischen Simulationsdaten (<code>staticSimData</code>),
 * der dynamischen Simulationsdaten (<code>dynamicSimData</code>) und der Statistikdaten (<code>statisticSimData</code>).
 * In den <code>CallcenterSimData</code>-Objekten alle Rechenthreads kann jeweils eine Referenz auf dasselbe <code>staticSimData</code>-Objekt
 * verwendet werden, da dieses absolut statisch ist. <code>dynamicSimData</code> und <code>statisticSimData</code> m�ssen
 * thread-lokale Objekte sein, da sie Daten des konkreten Simulationslaufes enthalten.
 * @author Alexander Herzog
 * @version 1.0
 * @see SimData
 * @see CallcenterStaticSimData
 * @see CallcenterDynamicSimData
 * @see CallcenterStatisticSimData
 */
public final class CallcenterSimData extends SimData {
	/**
	 * Statische Daten des Simulationsmodells; in allen Rechenthreads kann eine Referenz auf dasselbe Objekt verwendet werden.
	 * @see CallcenterStaticSimData
	 */
	public final CallcenterStaticSimData staticSimData;

	/**
	 * Sich im Simulationsverlauf dynamisch ver�ndernde Daten.
	 * @see CallcenterDynamicSimData
	 */
	public final CallcenterDynamicSimData dynamicSimData;

	/**
	 * Objekt zur Aufzeichnung von statistischen Daten.
	 * @see CallcenterStatisticSimData
	 */
	public CallcenterStatisticSimData statisticSimData;

	/**
	 * Konstruktor der Klasse <code>CallcenterSimData</code><br>
	 * (Die <code>staticSimData</code> wird gem�� dem Parameter belegt. die Objekte <code>dynamicSimData</code> und <code>statisticSimData</code> werden
	 * vom Konstruktor selbst angelegt.)
	 * @param eventManager	Referenz auf das zur Simulation zu verwendende EventManager-Objekt
	 * @param eventCache	Referenz auf das zur Simulation zu verwendende EventCache-Objekt
	 * @param threadNr	Nummer des Simulationsthreads (von 0 an gez�hlt)
	 * @param threadCount	Anzahl der Rechenthreads (wird ben�tigt, um aus der Gesamtzahl der zu simulierenden Anrufe auf die in diesem Thread zu simulierende Anruferanzahl zu schlie�en)
	 * @param staticSimData	Referenz auf das Objekt, welches die statischen Simulationsdaten enth�lt
	 */
	public CallcenterSimData(EventManager eventManager, EventCache eventCache, int threadNr, int threadCount, CallcenterStaticSimData staticSimData) {
		super(eventManager,eventCache,threadNr,threadCount);
		this.staticSimData=staticSimData;
		dynamicSimData=new CallcenterDynamicSimData(staticSimData.agents);
		statisticSimData=new CallcenterStatisticSimData(staticSimData.agents,staticSimData.batchWorking,Math.min(staticSimData.waitingRoomSize,10000));
	}

	/**
	 * Konstruktor der Klasse <code>CallcenterSimData</code><br>
	 * (Alle drei Datenobjekte, d.h. <code>staticSimData</code>, <code>dynamicSimData</code> und <code>statisticSimData</code> werden
	 * vom Konstruktor gem�� der Parameter selbst angelegt.)
	 * @param eventManager	Referenz auf das zur Simulation zu verwendende EventManager-Objekt
	 * @param eventCache	Referenz auf das zur Simulation zu verwendende EventCache-Objekt
	 * @param threadNr	Nummer des Simulationsthreads (von 0 an gez�hlt)
	 * @param threadCount	Anzahl der Rechenthreads (wird ben�tigt, um aus der Gesamtzahl der zu simulierenden Anrufe auf die in diesem Thread zu simulierende Anruferanzahl zu schlie�en)
	 * @param agents	Anzahl an Callcenter-Agenten
	 * @param interArrivalTimeDist	Zwischenankunftzeitverteilung
	 * @param batchArrival	Kunden treffen nicht einzeln, sondern in Batches dieser Gr��en ein.
	 * @param waitingTimeDist	Wartezeittoleranzverteilung
	 * @param workingTimeDist	Bedienzeitverteilung
	 * @param batchWorking	batchWorking
	 * @param callContinueProbability	Weiterleitungswahrscheinlichkeit
	 * @param retryProbability	Wiederholwahrscheinlichkeit (nach Besetztzeichen oder Warteabbruch)
	 * @param retryTimeDist	Wiederholabst�ndeverteilung
	 * @param callsToSimulate	Anzahl der zu simulierenden Erstanrufe
	 * @param waitingRoomSize	Gr��e des Warteraums (ein in Bedienung befindlicher Anrufer belegt keinen Warteraum mehr)
	 * @param warmUpCalls	Anzahl an zu simulierenden Anrufen, bevor die <code>callsToSimulate</code>-Z�hlung beginnt.
	 */
	public CallcenterSimData(EventManager eventManager, EventCache eventCache, int threadNr, int threadCount, int agents, AbstractRealDistribution interArrivalTimeDist, int batchArrival, AbstractRealDistribution waitingTimeDist, AbstractRealDistribution workingTimeDist, int batchWorking, double callContinueProbability, double retryProbability, AbstractRealDistribution retryTimeDist, long callsToSimulate, int waitingRoomSize, int warmUpCalls) {
		super(eventManager,eventCache,threadNr,threadCount);
		staticSimData=new CallcenterStaticSimData(agents,interArrivalTimeDist,batchArrival,waitingTimeDist,workingTimeDist,batchWorking,callContinueProbability,retryProbability,retryTimeDist,callsToSimulate,waitingRoomSize,warmUpCalls);
		dynamicSimData=new CallcenterDynamicSimData(agents);
		statisticSimData=new CallcenterStatisticSimData(agents,batchWorking,Math.min(waitingRoomSize,10000));
	}

	/**
	 * Legt ein <code>CallEvent</code> an
	 * @param timeFromNow	Zeitabstand von der aktuellen Zeit an gerechnet
	 * @param newCall	Wird auf <code>true</code> gesetzt, wenn es sich um einen Erstanrufer und nicht um einen Wiederholer handelt
	 * @see CallEvent
	 */
	public final void scheduleCall(long timeFromNow, boolean newCall) {
		CallEvent callEvent=(CallEvent)getEvent(CallEvent.class);
		callEvent.init(currentTime+timeFromNow);
		callEvent.isNewCall=newCall;
		eventManager.addEvent(callEvent);
	}

	/**
	 * Legt ein <code>CallCancelEvent</code> an
	 * @param timeFromNow	Zeitabstand von der aktuellen Zeit an gerechnet
	 * @see CallCancelEvent
	 */
	public final void scheduleCallCancel(long timeFromNow) {
		CallCancelEvent cancelEvent=(CallCancelEvent)getEvent(CallCancelEvent.class);
		cancelEvent.init(currentTime,currentTime+timeFromNow);
		dynamicSimData.waitingCalls.add(cancelEvent);
		eventManager.addEvent(cancelEvent);
	}

	/**
	 * Plant ein Event ein mit dem gepr�ft wird, ob es noch Kunden-Agent-Verkn�pfungen geben kann oder ob die Simulation beendet werden kann.
	 */
	public final void scheduleStopTest() {
		StopTestEvent stopTestEvent=(StopTestEvent)getEvent(StopTestEvent.class);
		stopTestEvent.init(currentTime+CallcenterStaticSimData.timeBase);
		eventManager.addEvent(stopTestEvent);
	}

	/**
	 * Pr�ft, ob es freie Agenten gibt und startet ggf. einen Anruf (d.h. die Anzahl der freien Agenten wird verringert und
	 * ein <code>CallDoneEvent</code> wird angelegt.)
	 * @param now	Aktuelle Systemzeit
	 * @param justCalling	Gibt an, ob es sich um einen neuen Anruf handelt (<code>true</code>) oder um einen Check innerhalb von <code>CallDoneEvent</code> (<code>false</code>).
	 * @return	Gibt -1 zur�ck, wenn die Bedienung nicht gestartet werden konnte, sonst gibt die Funktion die Bedienzeit zur�ck.
	 */
	public final long tryStartCall(long now, boolean justCalling, boolean firstOfBatch, long batchWorkingTime) {
		if (dynamicSimData.freeAgents==0 && firstOfBatch) {if (justCalling) statisticSimData.callsNeededToWait++; return -1;}

		if (firstOfBatch) dynamicSimData.freeAgents--;

		final long workingTime=firstOfBatch?staticSimData.getWorkingTime():batchWorkingTime;

		CallDoneEvent callDoneEvent=(CallDoneEvent)getEvent(CallDoneEvent.class);
		callDoneEvent.init(now+workingTime);
		callDoneEvent.firstOfBatch=firstOfBatch;
		eventManager.addEvent(callDoneEvent);

		return workingTime;
	}

	/**
	 * Erfasst einen Anruf in der Statistik
	 * @param now	Aktuelle Systemzeit
	 * @param freshCall	Gibt an, ob es sich um einen Erstanrufer (<code>true</code>) oder um einen Wiederholer (<code>false</code>) handelt.
	 */
	public final void logIncomingCall(final long now, final boolean freshCall) {
		if (dynamicSimData.isWarmUpPeriod && (statisticSimData.calls>=staticSimData.warmUpCalls)) {
			dynamicSimData.isWarmUpPeriod=false;
			logDistDataChange((now+dynamicSimData.lastDataLogTime)/2);
			statisticSimData=new CallcenterStatisticSimData(staticSimData.agents,staticSimData.batchWorking,statisticSimData.queueLengthTimes.length-1);
		}

		logDistDataChange(now);

		statisticSimData.calls++;
		if (freshCall) statisticSimData.freshCalls++;
	}

	/**
	 * Erfasst die Wartezeit eines erfolgreichen Anrufs in der Statistik
	 * @param waitingTime	Wartezeit des Anrufers
	 */
	public final void logSuccessfulCall(final long waitingTime, final long serviceTime) {
		final double d1=((double)waitingTime)/CallcenterStaticSimData.timeBase;
		final double d2=((double)serviceTime)/CallcenterStaticSimData.timeBase;
		final double d3=d1+d2;

		if (d1>0) {
			statisticSimData.waitingTimeSum+=d1;
			statisticSimData.waitingTimeSqrSum+=d1*d1;
		}

		statisticSimData.serviceTimeSum+=d2;
		statisticSimData.serviceTimeSqrSum+=d2*d2;

		statisticSimData.systemTimeSum+=d3;
		statisticSimData.systemTimeSqrSum+=d3*d3;

		statisticSimData.successful++;
	}

	/**
	 * Erfasst die Abbruchzeit eines Warteabbrechers in der Statistik
	 * @param now	Aktuelle Systemzeit
	 * @param abortTime	Wartezeit bis zum Abbruch
	 */
	public final void logCallCancel(final long now, final long abortTime) {
		logDistDataChange(now);

		final double d=((double)abortTime)/CallcenterStaticSimData.timeBase;
		final double dSqr=Math.pow(d,2);

		statisticSimData.abortTimeSum+=d;
		statisticSimData.abortTimeSqrSum+=dSqr;

		statisticSimData.systemTimeSum+=d;
		statisticSimData.systemTimeSqrSum+=dSqr;
	}

	/**
	 * Erfasst, wenn sich die Anzahl an freien Agenten oder wartenden Kunden �ndert in der Statistik
	 * (Ist aufzurufen unmittelbar <b>bevor</b> sich der Wert �ndert.)
	 * @param now	Aktuelle Systemzeit
	 */
	public final void logDistDataChange(final long now) {
		final long timeSpanLong=now-dynamicSimData.lastDataLogTime;
		if (timeSpanLong<=0) return;

		final int freeAgents=dynamicSimData.freeAgents;
		final int busyAgents=staticSimData.agents-freeAgents;
		final int waitingCalls=dynamicSimData.waitingCalls.size();

		final double timeSpan=((double)timeSpanLong)/CallcenterStaticSimData.timeBase;

		statisticSimData.freeAgentTimes[Math.min(statisticSimData.freeAgentTimes.length-1,freeAgents)]+=timeSpan;
		statisticSimData.queueLengthTimes[Math.min(statisticSimData.queueLengthTimes.length-1,waitingCalls)]+=timeSpan;
		statisticSimData.systemLengthTimes[Math.min(statisticSimData.systemLengthTimes.length-1,busyAgents*staticSimData.batchWorking+waitingCalls)]+=timeSpan;

		dynamicSimData.lastDataLogTime=now;
	}

	@Override
	public void terminateCleanUp(final long now) {
		statisticSimData.calls-=dynamicSimData.waitingCalls.size();
		logDistDataChange(now);
	}
}
