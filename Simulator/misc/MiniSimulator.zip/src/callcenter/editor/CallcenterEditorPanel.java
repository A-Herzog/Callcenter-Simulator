package callcenter.editor;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.math3.distribution.AbstractRealDistribution;
import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import callcenter.CallcenterSimulator;
import callcenter.CallcenterStaticSimData;
import callcenter.CallcenterStatisticOutput;
import callcenter.editor.CallcenterEditorFrame.DropTargetRegister;
import callcenter.editor.CallcenterEditorFrame.LoadCallback;
import mathtools.NumberTools;
import mathtools.distribution.LogNormalDistributionImpl;
import mathtools.distribution.NeverDistributionImpl;
import mathtools.distribution.swing.CommonVariables;
import mathtools.distribution.swing.JDistributionPanel;

/**
 * Enth�lt einen vollst�ndigen Callcenter-Editor als Panel.
 * @author Alexander Herzog
 * @version
 */
public class CallcenterEditorPanel extends JPanel {
	private static final long serialVersionUID = 7566959476572957005L;

	public static final String HOME_URL="https://www.mathematik.tu-clausthal.de";
	public static final String AUTHOR_LONG="Alexander Herzog (alexander.herzog@tu-clausthal.de)";

	private static int maxPlotTime=3600;

	private final String version;

	private final int simResultsPageIndex;

	private WindowListener[] OwnerWindowListener;

	private JMenuBar menuBar=null;

	private JList<JLabel> listbox;
	private final DefaultListModel<JLabel> listboxModel;
	private JPanel main;

	private final JDistributionPanel Zwischenankunftszeiten;
	private final JTextField batchAnkuenfte;
	private final JDistributionPanel Bedienzeiten;
	private final JDistributionPanel Wartezeittoleranz;
	private final JDistributionPanel Wiederholabstaende;
	private final JTextField WarteraumGroesse;
	private final JTextField Bediener;
	private final JTextField batchBedienung;
	private final JTextField Wiederholwahrscheinlichkeit;
	private final JTextField Weiterleitungen;
	private JRadioButton UnendlicheWarteraumGroesse;
	private JRadioButton EndlicheWarteraumGroesse;
	private JRadioButton UnendlicheWartezeittoleranz;
	private JRadioButton EndlicheWartezeittoleranz;
	private final JTextField simRunCount;
	private JButton simButton;
	private JButton simCancelButton;
	private JTextArea results;

	private boolean abortRun;
	private Timer simulationTimer;

	private File lastFile=null;

	/**
	 * Konstruktor der Klasse <code>CallcenterEditorPanel</code>
	 * @param owner	Besitzer-Frame des Panels. Wird hier ein Wert ungleich <code>null</code> angegeben, so wird das Frame mit einem Men� versehen. Andernfalls werden Funktionen zum Laden von Beispiel-Modellen als Dialogseite angeboten.
	 * @param version Anzuzeigende Programmversion
	 */
	public CallcenterEditorPanel(JFrame owner, String version, DropTargetRegister dropTargetRegister) {
		this.version=version;

		setLayout(new BorderLayout());
		add(listbox=new JList<JLabel>(),BorderLayout.WEST);
		listbox.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		listboxModel=new DefaultListModel<JLabel>();
		listbox.setModel(listboxModel);
		listbox.setCellRenderer(new ListRenderer());
		listbox.addListSelectionListener(new ItemChangeEvent());
		add(main=new JPanel(new CardLayout()),BorderLayout.CENTER);
		main.setBackground(Color.lightGray);

		JPanel p,p2,p3;
		ButtonGroup cbg;

		/* Modell�bersicht */
		addMainPage(new CallcenterModellPanel(version),"res/information.png","Modell�bersicht");

		/* Zwischenankunftszeiten */
		Zwischenankunftszeiten=createExpDistributionPanel(5);
		p=addMainPageWithSubPanels(Zwischenankunftszeiten,"res/user.png","Zwischenankunftszeiten");
		batchAnkuenfte=addTextField(p,"Gleichzeitige Kundenank�nfte:","","1");

		/* Warteraumgr��e */
		p=addMainPageWithSubPanels(null,"res/house.png","Warteraumgr��e");
		p.setLayout(new GridLayout(3,1));
		cbg=new ButtonGroup();
		p.add(UnendlicheWarteraumGroesse=new JRadioButton("Kunden werden nie abgewiesen",true));
		cbg.add(UnendlicheWarteraumGroesse);
		p.add(EndlicheWarteraumGroesse=new JRadioButton("Es k�nnen maximal so viele Kunden wie im Folgenden angegeben gleichzeitig warten",false));
		cbg.add(EndlicheWarteraumGroesse);
		p.add(p2=new JPanel(new FlowLayout(FlowLayout.LEFT)));
		WarteraumGroesse=addTextField(p2,"Warteraumgr��e:","","10000");

		/* Bediener & Bedienzeiten */
		Bedienzeiten=createExpDistributionPanel(8);
		p=addMainPageWithSubPanels(Bedienzeiten,"res/group.png","Bediener & Bedienzeiten");
		Bediener=addTextField(p,"Anzahl an Bedienern:","","2");
		batchBedienung=addTextField(p,"Gleichzeitige Bedienungen pro Bediener:","","1");

		/* Wartezeittoleranz */
		Wartezeittoleranz=createExpDistributionPanel(10);
		p=addMainPageWithSubPanels(Wartezeittoleranz,"res/cancel.png","Wartezeittoleranz");
		cbg=new ButtonGroup();
		p.setLayout(new GridLayout(2,1));
		p.add(UnendlicheWartezeittoleranz=new JRadioButton("Kunden warten beliebig lange",false));
		cbg.add(UnendlicheWartezeittoleranz);
		p.add(EndlicheWartezeittoleranz=new JRadioButton("Wartezeittoleranz der Kunden gem�� der folgenden Verteilung",true));
		cbg.add(EndlicheWartezeittoleranz);

		/* Wahlwiederholungen */
		Wiederholabstaende=createExpDistributionPanel(30);
		p=addMainPageWithSubPanels(Wiederholabstaende,"res/arrow_redo.png","Wahlwiederholungen");
		Wiederholwahrscheinlichkeit=addTextField(p,"Wiederholwahrscheinlichkeit:","(Wahrscheinlichkeit, Werte zwischen 0 und 1)","0,5");

		/* Weiterleitungen */
		p=addMainPageWithSubPanels(null,"res/arrow_right.png","Weiterleilungen");
		p.setLayout(new FlowLayout(FlowLayout.LEFT));
		Weiterleitungen=addTextField(p,"Weiterleitungen:","(Wahrscheinlichkeit, Werte zwischen 0 und 1)","0,2");

		/* Simulation & Ergebnisse */
		p=new JPanel(new BorderLayout());
		p.add(p2=new JPanel(new BorderLayout()),BorderLayout.NORTH);
		p3=new JPanel(new FlowLayout(FlowLayout.LEFT));
		simRunCount=addTextField(p3,"Zu simulierende Kunden:","","1000000");
		p2.add(p3,BorderLayout.CENTER);

		p3=new JPanel(new FlowLayout(FlowLayout.LEFT));
		p2.add(p3,BorderLayout.EAST);

		p3.add(simButton=new JButton("Simulation starten"),BorderLayout.EAST);
		URL imgURL=CallcenterEditorPanel.class.getResource("res/action_go.gif");
		if (imgURL!=null) simButton.setIcon(new ImageIcon(imgURL));
		simButton.addActionListener(new SimButtonActionEvent());

		p3.add(simCancelButton=new JButton("Simulation abbrechen"),BorderLayout.EAST);
		simCancelButton.setVisible(false);
		imgURL=CallcenterEditorPanel.class.getResource("res/cancel.png");
		if (imgURL!=null) simCancelButton.setIcon(new ImageIcon(imgURL));
		simCancelButton.addActionListener(new SimButtonActionEvent());

		p.add(new JScrollPane(results=new JTextArea()),BorderLayout.CENTER);
		results.setEditable(false);
		addMainPage(p,"res/action_go.gif","Simulation & Ergebnisse");
		simResultsPageIndex=listboxModel.getSize()-1;

		/* Werkzeuge */
		if (owner==null) {
			addMainPage(p=new JPanel(new FlowLayout(FlowLayout.LEFT)),"res/wrench.png","Werkzeuge");
			JButton resetButton;
			for (int i=0;i<DefaultModels.length;i++) {
				p.add(resetButton=new JButton(DefaultModels[i]+" Modell laden"));
				resetButton.addActionListener(new SetDataEvent(i));
			}
		} else {
			addMenuBar(owner);
		}

		/* Info-Seite */
		if (owner==null) {
			addMainPage(new InfoPanel(version),"res/information.png","Programminformationen");
		}

		/* Defaultwerte laden */
		SetDataEvent loadDefaults=new SetDataEvent(0);
		loadDefaults.actionPerformed(null);
		listbox.setSelectedIndex(0);

		/* Drop-Loader registrieren */
		if (dropTargetRegister!=null) {
			dropTargetRegister.addLoadCallback(new LoadCallback() {
				@Override
				public boolean loadFile(File file) {
					boolean b=loadFromFile(file);
					if (b) {
						lastFile=file;
					} else {
						JOptionPane2.showErrorDialog(CallcenterEditorPanel.this,"Laden der Modelldatei","Aus der angegebenen Datei konnte kein Warteschlangenmodell geladen werden.");
					}
					return b;
				}
			});
		}
	}

	private JDistributionPanel createExpDistributionPanel(double mean) {
		return new JDistributionPanel(new ExponentialDistribution(mean),maxPlotTime,true);
	}

	private void addMainPage(Component c, String icon, String name) {
		main.add(c,name);
		JLabel label=new JLabel(name);
		URL imgURL=CallcenterEditorPanel.class.getResource(icon);
		if (imgURL!=null) label.setIcon(new ImageIcon(imgURL));
		listboxModel.addElement(label);
	}

	private JPanel addMainPageWithSubPanels(JDistributionPanel distribution, String icon, String name) {
		JPanel p=new JPanel(new BorderLayout());
		JPanel p2=new JPanel(new FlowLayout(FlowLayout.LEFT));
		p.add(p2,BorderLayout.NORTH);
		if (distribution!=null) p.add(distribution,BorderLayout.CENTER);
		addMainPage(p,icon,name);
		return p2;
	}

	private JTextField addTextField(JPanel parent, String label, String label2, String defaultValue) {
		parent.add(new JLabel(label));
		JTextField field=new JTextField(10);
		field.setText(defaultValue);
		parent.add(field);
		field.addKeyListener(new TextChangeEvent());
		if (!label2.isEmpty()) parent.add(new JLabel(label2));
		return field;
	}

	private void addMenuBar(JFrame frame) {
		menuBar=new JMenuBar();
		JMenu menu;
		JMenuItem item;
		URL imgURL;

		menu=new JMenu("Datei"); menuBar.add(menu);

		item=new JMenuItem("Modell laden..."); item.addActionListener(new SetDataEvent(-1)); menu.add(item);
		item.setMnemonic('L');
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,InputEvent.CTRL_DOWN_MASK));
		imgURL=CallcenterEditorPanel.class.getResource("res/brick_go.png");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		item=new JMenuItem("Modell speichern"); item.addActionListener(new SetDataEvent(-2)); menu.add(item);
		item.setMnemonic('S');
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_DOWN_MASK));
		imgURL=CallcenterEditorPanel.class.getResource("res/action_save.gif");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		item=new JMenuItem("Modell speichern unter..."); item.addActionListener(new SetDataEvent(-6)); menu.add(item);
		item.setMnemonic('u');

		menu.addSeparator();

		item=new JMenuItem("Simulation starten"); item.addActionListener(new SimButtonActionEvent()); menu.add(item);
		item.setMnemonic('S');
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5,0));
		imgURL=CallcenterEditorPanel.class.getResource("res/action_go.gif");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		menu.addSeparator();

		item=new JMenuItem("Beenden"); item.addActionListener(new SetDataEvent(-3)); menu.add(item);
		item.setMnemonic('B');
		imgURL=CallcenterEditorPanel.class.getResource("res/door_in.png");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		menu=new JMenu("Vorgabewerte"); menuBar.add(menu);
		for (int i=0;i<DefaultModels.length;i++) {
			item=new JMenuItem(DefaultModels[i]+" Modell laden"); item.addActionListener(new SetDataEvent(i)); menu.add(item);
		}

		menu=new JMenu("Hilfe"); menuBar.add(menu);

		item=new JMenuItem("Homepage"); item.addActionListener(new SetDataEvent(-4)); menu.add(item);
		item.setMnemonic('H');
		imgURL=CallcenterEditorPanel.class.getResource("res/world.png");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		menu.addSeparator();

		item=new JMenuItem("Programminformationen..."); item.addActionListener(new SetDataEvent(-5)); menu.add(item);
		item.setMnemonic('P');
		imgURL=CallcenterEditorPanel.class.getResource("res/information.png");
		if (imgURL!=null) item.setIcon(new ImageIcon(imgURL));

		frame.setJMenuBar(menuBar);

		OwnerWindowListener=frame.getWindowListeners();
	}

	private class TextChangeEvent implements KeyListener {

		public void textValueChanged(KeyEvent event) {
			if (event.getSource()==batchAnkuenfte) NumberTools.getPositiveLong(batchAnkuenfte,true);
			if (event.getSource()==WarteraumGroesse) NumberTools.getPositiveIntDouble(WarteraumGroesse,true);
			if (event.getSource()==Bediener) NumberTools.getPositiveIntDouble(Bediener,true);
			if (event.getSource()==batchBedienung) NumberTools.getPositiveLong(batchBedienung,true);
			if (event.getSource()==Wiederholwahrscheinlichkeit) NumberTools.getProbability(Wiederholwahrscheinlichkeit,true);
			if (event.getSource()==Weiterleitungen) NumberTools.getProbability(Weiterleitungen,true);
			if (event.getSource()==simRunCount) NumberTools.getPositiveIntDouble(simRunCount,true);
		}

		@Override
		public void keyTyped(KeyEvent e) {textValueChanged(e);}
		@Override
		public void keyPressed(KeyEvent e) {textValueChanged(e);}
		@Override
		public void keyReleased(KeyEvent e) {textValueChanged(e);}
	}

	private class ItemChangeEvent implements ListSelectionListener {
		@Override
		public void valueChanged(ListSelectionEvent e) {
			if (e.getSource()!=listbox) return;
			((CardLayout)main.getLayout()).show(main,listbox.getSelectedValue().getText());
		}
	}

	private String CheckModell() {
		if (batchAnkuenfte.getBackground().equals(Color.red)) return "Es wurde keine g�ltige Anzahl an Kunden pro eintreffender Kundengruppe angegeben.";
		if ((!UnendlicheWarteraumGroesse.isSelected()) && (WarteraumGroesse.getBackground().equals(Color.red))) return "Es wurde keine g�ltige Warteraumgr��e angegeben.";
		if (Bediener.getBackground().equals(Color.red)) return "Es wurde keine g�ltige Anzahl an Bedienern angegeben.";
		if (batchBedienung.getBackground().equals(Color.red)) return "Es wurde keine g�ltige Anzahl an Kunden pro Bedienvorgang angegeben.";
		if (((EndlicheWartezeittoleranz.isSelected() || (!UnendlicheWarteraumGroesse.isSelected())) && (Wiederholwahrscheinlichkeit.getBackground().equals(Color.red))))	return "Es wurde keine g�ltige Wiederholwahrscheinlichkeit angegeben.";
		if (Weiterleitungen.getBackground().equals(Color.red)) return "Es wurde keine g�ltige Weiterleitungswahrscheinlichkeit angegeben.";
		if (simRunCount.getBackground().equals(Color.red)) return "Es wurde keine g�ltige Anzahl an zu simulierenden Kunden angegeben.";
		return "";
	}

	private CallcenterStaticSimData buildModell() {
		int K; if (UnendlicheWarteraumGroesse.isSelected()) K=Integer.MAX_VALUE; else K=NumberTools.getInteger(WarteraumGroesse,true);
		AbstractRealDistribution waitingTolerance; if (EndlicheWartezeittoleranz.isSelected()) waitingTolerance=Wartezeittoleranz.getDistribution(); else waitingTolerance=new NeverDistributionImpl();

		return new CallcenterStaticSimData(
				/* agents */ NumberTools.getInteger(Bediener,true),
				/* InterArrivalTimeDist */ Zwischenankunftszeiten.getDistribution(),
				/* batchArrival */ (int)(long)NumberTools.getLong(batchAnkuenfte,true),
				/* WaitingTimeDist */ waitingTolerance,
				/* WorkingTimeDist */ Bedienzeiten.getDistribution(),
				/* batchWorking */ (int)(long)NumberTools.getLong(batchBedienung,true),
				/* P(continue) */ NumberTools.getProbability(Weiterleitungen,true),
				/* P(retry) */ NumberTools.getProbability(Wiederholwahrscheinlichkeit,true),
				/* RetryTimeDist */ Wiederholabstaende.getDistribution(),
				/* Calls to simulate */ NumberTools.getInteger(simRunCount,true),
				/* K */ K,
				/* WarmUpCalls */ Math.max(NumberTools.getInteger(simRunCount,true)/10,100000)
				);
	}

	private boolean loadFromFile(File file) {
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {db=dbf.newDocumentBuilder();} catch (ParserConfigurationException e) {return false;}
		db.setErrorHandler(null);
		Element root;
		try {root=db.parse(file).getDocumentElement();} catch (SAXException e) {return false;} catch (IOException e) {return false;}

		if (!root.getNodeName().equalsIgnoreCase("Warteschlangenmodell")) return false;

		batchAnkuenfte.setText("1");
		batchBedienung.setText("1");
		simRunCount.setText("1000000");

		NodeList l=root.getChildNodes();
		for (int i=0; i<l.getLength();i++) {
			if (!(l.item(i) instanceof Element)) continue;
			Element e=(Element)l.item(i);
			String s=e.getNodeName();

			if (s.equalsIgnoreCase("SimulierteKunden")) {
				simRunCount.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}

			if (s.equalsIgnoreCase("Zwischenankunftszeiten")) {
				if (!Zwischenankunftszeiten.fromString(e.getTextContent())) return false;
				continue;
			}

			if (s.equalsIgnoreCase("Gruppenankuenfte")) {
				batchAnkuenfte.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}

			if (s.equalsIgnoreCase("Warteraum")) {
				if (e.getTextContent().equalsIgnoreCase("unendlich") || e.getTextContent().equalsIgnoreCase("nie")) {
					UnendlicheWarteraumGroesse.setSelected(true);
					WarteraumGroesse.setText("10");
				} else {
					EndlicheWarteraumGroesse.setSelected(true);
					WarteraumGroesse.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				}
				continue;
			}

			if (s.equalsIgnoreCase("Bediener")) {
				Bediener.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}

			if (s.equalsIgnoreCase("Bedienzeiten")) {
				if (!Bedienzeiten.fromString(e.getTextContent())) return false;
				continue;
			}

			if (s.equalsIgnoreCase("Gruppenbedienungen")) {
				batchBedienung.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}

			if (s.equalsIgnoreCase("Wartezeittoleranz")) {
				if (e.getTextContent().equalsIgnoreCase("unendlich") || e.getTextContent().equalsIgnoreCase("nie")) {
					UnendlicheWartezeittoleranz.setSelected(true);
					Wartezeittoleranz.setDistribution(120);
				} else {
					EndlicheWartezeittoleranz.setSelected(true);
					if (!Wartezeittoleranz.fromString(e.getTextContent())) return false;
				}
				continue;
			}

			if (s.equalsIgnoreCase("Wiederholwahrscheinlichkeit")) {
				Wiederholwahrscheinlichkeit.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}

			if (s.equalsIgnoreCase("Wiederholabstaende")) {
				if (!Wiederholabstaende.fromString(e.getTextContent())) return false;
				continue;
			}

			if (s.equalsIgnoreCase("Weiterleitungen")) {
				Weiterleitungen.setText(NumberTools.systemNumberToLocalNumber(e.getTextContent()));
				continue;
			}
		}

		return true;
	}

	private boolean saveToFile(File file) {
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {db=dbf.newDocumentBuilder();} catch (ParserConfigurationException e) {return false;}
		Document doc=db.newDocument();

		Element root=doc.createElement("Warteschlangenmodell"); doc.appendChild(root);
		Element e;

		e=doc.createElement("SimulierteKunden"); root.appendChild(e);
		e.setTextContent(simRunCount.getText());

		e=doc.createElement("Zwischenankunftszeiten"); root.appendChild(e);
		e.setTextContent(Zwischenankunftszeiten.toString());

		e=doc.createElement("Gruppenankuenfte"); root.appendChild(e);
		e.setTextContent(NumberTools.localNumberToSystemNumber(batchAnkuenfte.getText()));

		e=doc.createElement("Warteraum"); root.appendChild(e);
		if (UnendlicheWarteraumGroesse.isSelected()) e.setTextContent("unendlich"); else e.setTextContent(NumberTools.localNumberToSystemNumber(WarteraumGroesse.getText()));

		e=doc.createElement("Bediener"); root.appendChild(e);
		e.setTextContent(NumberTools.localNumberToSystemNumber(Bediener.getText()));

		e=doc.createElement("Bedienzeiten"); root.appendChild(e);
		e.setTextContent(Bedienzeiten.toString());

		e=doc.createElement("Gruppenbedienungen"); root.appendChild(e);
		e.setTextContent(NumberTools.localNumberToSystemNumber(batchBedienung.getText()));

		e=doc.createElement("Wartezeittoleranz"); root.appendChild(e);
		if (UnendlicheWartezeittoleranz.isSelected()) e.setTextContent("unendlich"); else e.setTextContent(Wartezeittoleranz.toString());

		e=doc.createElement("Wiederholwahrscheinlichkeit"); root.appendChild(e);
		e.setTextContent(NumberTools.localNumberToSystemNumber(Wiederholwahrscheinlichkeit.getText()));

		e=doc.createElement("Wiederholabstaende"); root.appendChild(e);
		e.setTextContent(Wiederholabstaende.toString());

		e=doc.createElement("Weiterleitungen"); root.appendChild(e);
		e.setTextContent(NumberTools.localNumberToSystemNumber(Weiterleitungen.getText()));

		Transformer transformer;
		try {
			transformer=TransformerFactory.newInstance().newTransformer();
		} catch (TransformerConfigurationException e1) {return false;} catch (TransformerFactoryConfigurationError e1) {return false;}
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","2");
		try {
			transformer.transform(new DOMSource(doc),new StreamResult(file));
		} catch (TransformerException e1) {return false;}

		return true;
	}

	private void setMenuEnabledState(Component menu, boolean enabled) {
		menu.setEnabled(enabled);
		if (menu instanceof JMenu)
			for (int i=0;i<((JMenu)menu).getMenuComponentCount();i++) setMenuEnabledState(((JMenu)menu).getMenuComponent(i),enabled);
	}

	private void setGUIEnabledState(boolean enabled) {
		listbox.setEnabled(enabled);
		simRunCount.setEnabled(enabled);
		simButton.setVisible(enabled);
		simCancelButton.setVisible(!enabled);

		if (menuBar!=null) {
			for (int i=0;i<menuBar.getMenuCount();i++) setMenuEnabledState(menuBar.getMenu(i),enabled);
			menuBar.setEnabled(enabled);
		}
	}

	private class SimButtonActionEvent implements ActionListener {
		private void cancelSimulation() {
			abortRun=true;
		}

		private void runSimulation() {
			/* Falls �ber Men� aufgerufen */
			listbox.setSelectedIndex(simResultsPageIndex);
			((CardLayout)main.getLayout()).show(main,listbox.getSelectedValue().getText());

			results.setText("");
			String error=CheckModell();	if (!error.isEmpty()) {results.setText("Fehler: "+error); return;}

			final CallcenterSimulator simulator=new CallcenterSimulator(buildModell());
			simulator.start(false);
			results.setText("Die Simulation l�uft, bitte warten.");

			setGUIEnabledState(false);
			abortRun=false;
			simulationTimer=new Timer("SimProgressBar");
			simulationTimer.scheduleAtFixedRate(new TimerTask() {
				@Override
				public void run() {
					if (abortRun) {
						simulationTimer.cancel();
						simulator.cancel();
						simulator.finalizeRun();
						results.setText("Die Simulation wurde abgebrochen.\n");
						setGUIEnabledState(true);
					}

					if  (simulator.isRunning()) {
						results.setText(String.format("Die Simulation l�uft, bitte warten.\n%,dM Ereignisse simuliert.",simulator.getEventCount()/1000/1000));
					} else {
						simulationTimer.cancel();
						simulator.finalizeRun();
						if (!abortRun) {
							results.setText(new CallcenterStatisticOutput(simulator).getAllData());
						}
						setGUIEnabledState(true);
					}

				}
			},200,200);
		}

		@Override
		public void actionPerformed(ActionEvent event) {
			if (event.getSource()==simCancelButton) {cancelSimulation(); return;}
			runSimulation();
		}
	}

	private static String[] DefaultModels = {"M/M/c/infty","M/M/c/K","M/M/c/K+M","M/M/c/K+M+M+Weiterleitungen","M/G/c/K+G+G+Weiterleitungen"};

	private class SetDataEvent implements ActionListener {
		private final int resetType;
		public SetDataEvent(int resetType) {this.resetType=resetType;}
		@Override
		public void actionPerformed(ActionEvent event) {
			if (resetType>=0) loadDefaultValues(); else performOperation();
		}

		private void loadDefaultValues() {
			lastFile=null;
			simRunCount.setText("1000000");
			switch (resetType) {
			case 0:
				/* M/M/c/infty */
				Zwischenankunftszeiten.setDistribution(60);
				batchAnkuenfte.setText("1");
				Bediener.setText("4"); Bedienzeiten.setDistribution(180);
				batchBedienung.setText("1");
				UnendlicheWartezeittoleranz.setSelected(true); Wartezeittoleranz.setDistribution(300);
				Wiederholwahrscheinlichkeit.setText("0"); Wiederholabstaende.setDistribution(1800);
				UnendlicheWarteraumGroesse.setSelected(true); WarteraumGroesse.setText("10");
				Weiterleitungen.setText("0");
				break;
			case 1:
				/* M/M/c/K */
				Zwischenankunftszeiten.setDistribution(60);
				batchAnkuenfte.setText("1");
				Bediener.setText("4"); Bedienzeiten.setDistribution(180);
				batchBedienung.setText("1");
				UnendlicheWartezeittoleranz.setSelected(true); Wartezeittoleranz.setDistribution(300);
				Wiederholwahrscheinlichkeit.setText("0"); Wiederholabstaende.setDistribution(1800);
				EndlicheWarteraumGroesse.setSelected(true); WarteraumGroesse.setText("5");
				Weiterleitungen.setText("0");
				break;
			case 2:
				/* M/M/c/K+M */
				Zwischenankunftszeiten.setDistribution(60);
				batchAnkuenfte.setText("1");
				Bediener.setText("4"); Bedienzeiten.setDistribution(180);
				batchBedienung.setText("1");
				EndlicheWartezeittoleranz.setSelected(true); Wartezeittoleranz.setDistribution(120);
				Wiederholwahrscheinlichkeit.setText("0"); Wiederholabstaende.setDistribution(1800);
				EndlicheWarteraumGroesse.setSelected(true); WarteraumGroesse.setText("15");
				Weiterleitungen.setText("0");
				break;
			case 3:
				/* M/M/c/inf+M+M+Weiterleitungen */
				Zwischenankunftszeiten.setDistribution(60);
				batchAnkuenfte.setText("1");
				Bediener.setText("4"); Bedienzeiten.setDistribution(180);
				batchBedienung.setText("1");
				EndlicheWartezeittoleranz.setSelected(true); Wartezeittoleranz.setDistribution(120);
				Wiederholwahrscheinlichkeit.setText(NumberTools.formatNumberMax(0.75)); Wiederholabstaende.setDistribution(1800);
				EndlicheWarteraumGroesse.setSelected(true); WarteraumGroesse.setText("15");
				Weiterleitungen.setText(NumberTools.formatNumberMax(0.2));
				break;
			case 4:
				/* M/G/c/inf+G+G+Weiterleitungen */
				Zwischenankunftszeiten.setDistribution(60);
				batchAnkuenfte.setText("1");
				Bediener.setText("4"); Bedienzeiten.setDistribution(new LogNormalDistributionImpl(180,30));
				batchBedienung.setText("1");
				EndlicheWartezeittoleranz.setSelected(true); Wartezeittoleranz.setDistribution(new LogNormalDistributionImpl(120,60));
				Wiederholwahrscheinlichkeit.setText(NumberTools.formatNumberMax(0.75)); Wiederholabstaende.setDistribution(new LogNormalDistributionImpl(1800,600));
				EndlicheWarteraumGroesse.setSelected(true); WarteraumGroesse.setText("15");
				Weiterleitungen.setText(NumberTools.formatNumberMax(0.2));
				break;
			}
		}

		private boolean performLoadFromFile() {
			Container c=getParent(); while ((c!=null) && (!(c instanceof Frame))) c=c.getParent();
			JFileChooser fc=new JFileChooser();
			CommonVariables.initialDirectoryToJFileChooser(fc);
			fc.setDialogTitle("Modell laden");
			FileFilter xml=new FileNameExtensionFilter("xml-Dateien (*.xml)","xml");
			fc.addChoosableFileFilter(xml);
			fc.setFileFilter(xml);
			if (fc.showOpenDialog(c)!=JFileChooser.APPROVE_OPTION) return false;
			CommonVariables.initialDirectoryFromJFileChooser(fc);
			File file=fc.getSelectedFile();
			if (file.getName().indexOf('.')<0 && fc.getFileFilter()==xml) file=new File(file.getAbsoluteFile()+".xml");
			if (loadFromFile(file)) {
				lastFile=file;
				return true;
			} else {
				errorDialog("Laden eines Modells","Aus der angegebenen Datei konnte kein Warteschlangenmodell geladen werden.");
				return false;
			}
		}

		private boolean performSaveToFile(boolean forceSelectFile) {
			if (lastFile==null || forceSelectFile) {
				Container c=getParent(); while ((c!=null) && (!(c instanceof Frame))) c=c.getParent();
				JFileChooser fc=new JFileChooser();
				CommonVariables.initialDirectoryToJFileChooser(fc);
				fc.setDialogTitle("Modell speichern");
				FileFilter xml=new FileNameExtensionFilter("xml-Dateien (*.xml)","xml");
				fc.addChoosableFileFilter(xml);
				fc.setFileFilter(xml);
				if (fc.showSaveDialog(c)!=JFileChooser.APPROVE_OPTION) return false;
				CommonVariables.initialDirectoryFromJFileChooser(fc);
				File file=fc.getSelectedFile();
				if (file.getName().indexOf('.')<0 && fc.getFileFilter()==xml) file=new File(file.getAbsoluteFile()+".xml");
				if (file.exists()) {if (!JOptionPane2.showConfirmOverwriteDialog(CallcenterEditorPanel.this,file)) return false;}
				if (saveToFile(file)) {
					lastFile=file;
					return true;
				} else {
					errorDialog("Speichern des Modells","Das Modell konnte in der Datei\n"+file.toString()+"\nnicht gespeichert werden.");
					return false;
				}
			} else {
				if (saveToFile(lastFile)) {
					return true;
				} else {
					errorDialog("Speichern des Modells","Das Modell konnte in der Datei\n"+lastFile.toString()+"\nnicht gespeichert werden.");
					return false;
				}
			}
		}

		private void performOperation() {
			switch (resetType) {
			case -1: performLoadFromFile(); break;
			case -2: performSaveToFile(false); break;
			case -3:
				for (int i=0;i<OwnerWindowListener.length;i++) OwnerWindowListener[i].windowClosing(null);
				break;
			case -4:
				try {
					Desktop.getDesktop().browse(new URI(HOME_URL));
				} catch (IOException e) {} catch (URISyntaxException e) {}
				break;
			case -5:
				Container c=getParent(); while ((c!=null) && (!(c instanceof Frame))) c=c.getParent();
				InfoDialog info=new InfoDialog((Frame)c,version);
				info.setVisible(true);
				break;
			case -6: performSaveToFile(true); break;
			}
		}

		private void errorDialog(String text, String text2) {
			JOptionPane2.showErrorDialog(CallcenterEditorPanel.this,text,text2);
		}
	}

	private class ListRenderer extends DefaultListCellRenderer {
		private static final long serialVersionUID = 6246581092762257134L;

		/* (non-Javadoc)
		 * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
		 */
		@Override
		public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		{
			JLabel k=(JLabel)super.getListCellRendererComponent(list,value,index,isSelected,cellHasFocus);
			JLabel c=(JLabel)value;
			k.setText(c.getText());
			k.setIcon(c.getIcon());
			k.setBorder(BorderFactory.createEmptyBorder(2,5,2,5));
			return k;
		}
	}
}
