package callcenter.editor;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.net.URL;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Diese Klasse stellt ein Fenster dar, welches ein <code>CallcenterEditorPanel</code>-Panel enth�lt.
 * @author Alexander Herzog
 * @version 1.0
 * @see CallcenterEditorPanel
 */
public class CallcenterEditorFrame extends JFrame {
	private static final long serialVersionUID = 3732558985904447341L;

	/**
	 * Konstruktor der Klasse <code>CallcenterEditorFrame</code>
	 * @param version Anzuzeigende Programmversion
	 */
	public CallcenterEditorFrame(String version, DropTargetRegister dropTargetRegister) {
		super("Mini Callcenter Simulator");
		addWindowListener(new WindowAdapter() {@Override
			public void windowClosing(WindowEvent event) {setVisible(false); System.exit(0);}});
		setLayout(new BorderLayout());
		setSize(750,600);
		setLocationRelativeTo(null);

		/* Fensterinhakt */
		JPanel panel;
		add(panel=new CallcenterEditorPanel(this,version,dropTargetRegister),BorderLayout.CENTER);
		if (dropTargetRegister!=null) dropTargetRegister.registerJComponent(panel);

		/* Programmicon */
		URL imgURL;
		imgURL=CallcenterEditorFrame.class.getResource("res/Symbol.png");
		if (imgURL!=null) setIconImage(getToolkit().getImage(imgURL));

		setVisible(true);
	}

	public interface DropTargetRegister {
		public void registerJComponent(JComponent component);
		public void addLoadCallback(LoadCallback callback);
	}

	public interface LoadCallback {
		public boolean loadFile(File file);
	}
}
