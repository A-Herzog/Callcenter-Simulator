package callcenter.editor;

import java.awt.Component;
import java.awt.Window;
import java.io.File;
import java.net.URL;
import java.util.Locale;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import com.ezware.dialog.task.CommandLink;
import com.ezware.dialog.task.TaskDialog;
import com.ezware.dialog.task.TaskDialogs;

/**
 * Diese Klasse stellt Dialoge, die h�bscher aussehen als die <code>JOptionPane</code>-Dialoge zur Verf�gung.
 * @author Alexander Herzog
 * @version 1.0
 */
public class JOptionPane2 {
	public static String TitleInformation="Information";
	public static String TitleWarning="Warnung";
	public static String TitleError="Fehler";
	public static String TitleConfirmation="Frage";
	public static String OverwriteTitle="Vorhendene Datei �berschreiben?";
	public static String OverwriteInfo="Die Datei\n%s\nexistiert bereits.\nSoll die Datei jetzt �berschrieben werden?";
	public static String OverwriteYes="Datei �berschreiben";
	public static String OverwriteYesInfo="L�scht die bisher unter diesem Namen existierende Datei und speichert die neuen Daten unter diesem Dateinamen.";
	public static String OverwriteNo="Datei nicht �berschreiben";
	public static String OverwriteNoInfo="Beh�lt die bestehende Datei unver�ndert bei. Die neuen Daten werden nicht gespeichert.";

	public static Locale ActiveLocale=Locale.getDefault();

	/**
	 * Neue Dialoge verwenden.
	 * Wird diese statische Variable auf <code>false</code> gesetzt, werden die klassischen <code>JOption Pane</code>-Dialoge verwendet.
	 */
	public static boolean newDialogs=true;

	private JOptionPane2() {
	}

	private static Window getWindow(Component component) {
		while (component!=null && !(component instanceof Window)) component=component.getParent();
		return (Window)component;
	}

	/**
	 * Zeigt einen Info-Dialog an.
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 */
	public static void showInfoDialog(Component parentComponent, String message, String subTitle) {
		if (newDialogs) {
			TaskDialog dialog=new TaskDialog(getWindow(parentComponent),TitleInformation);
			dialog.setInstruction(message);
			dialog.setText(subTitle);
			dialog.setCommands(TaskDialog.StandardCommand.OK);
			dialog.setIcon(TaskDialog.StandardIcon.INFO);
			dialog.setLocale(ActiveLocale);
			dialog.show();
		} else {
			JOptionPane.showMessageDialog(parentComponent,message,TitleInformation,JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/**
	 * Zeigt einen Warnung-Dialog an.
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 */
	public static void showWarningDialog(Component parentComponent, String message, String subTitle) {
		if (newDialogs) {
			TaskDialog dialog=new TaskDialog(getWindow(parentComponent),TitleWarning);
			dialog.setInstruction(message);
			dialog.setText(subTitle);
			dialog.setCommands(TaskDialog.StandardCommand.OK);
			dialog.setIcon(TaskDialog.StandardIcon.WARNING);
			dialog.setLocale(ActiveLocale);
			dialog.show();
		} else {
			JOptionPane.showMessageDialog(parentComponent,message+":\n"+subTitle,TitleWarning,JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Zeigt eine Fehlermeldung an.
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 */
	public static void showErrorDialog(Component parentComponent, String message, String subTitle) {
		if (newDialogs) {
			TaskDialog dialog=new TaskDialog(getWindow(parentComponent),TitleError);
			dialog.setInstruction(message);
			dialog.setText(subTitle);
			dialog.setCommands(TaskDialog.StandardCommand.OK);
			dialog.setIcon(TaskDialog.StandardIcon.ERROR);
			dialog.setLocale(ActiveLocale);
			dialog.show();
		} else {
			JOptionPane.showMessageDialog(parentComponent,message+":\n"+subTitle,TitleError,JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Zeigt einen Ja/Nein/Abbrechen-Dialog an.
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 * @param option1	�berschrift f�r die erste Option
	 * @param option1sub	Untertitel der ersten Option
	 * @param option2	�berschrift f�r die zweite Option
	 * @param option2sub	Untertitel der zweiten Option
	 * @param option3	�berschrift f�r die dritte Option
	 * @param option3sub	Untertitel der dritten Option
	 * @return	Liefert einen der Werte <code>JOptionPane.YES_OPTION</code>, <code>JOptionPane.NO_OPTION</code> oder <code>JOptionPane.CANCEL_OPTION</code> zur�ck.
	 */
	public static int showConfirmDialog(Component parentComponent, String message, String subTitle, String option1, String option1sub, String option2, String option2sub, String option3, String option3sub) {
		if (newDialogs) {
			URL urlYes=JOptionPane2.class.getResource("res/tick.png");
			URL urlNo=JOptionPane2.class.getResource("res/cancel.png");
			URL urlCancel=JOptionPane2.class.getResource("res/arrow_redo2.png");
			int wahl=TaskDialogs.choice(getWindow(parentComponent),message,subTitle,0,
					new CommandLink(new ImageIcon(urlYes),option1,option1sub),
					new CommandLink(new ImageIcon(urlNo),option2,option2sub),
					new CommandLink(new ImageIcon(urlCancel),option3,option3sub));
			switch (wahl) {
			case 0: return JOptionPane.YES_OPTION;
			case 1: return JOptionPane.NO_OPTION;
			case 2: return JOptionPane.CANCEL_OPTION;
			default: return JOptionPane.CANCEL_OPTION;
			}
		} else {
			return JOptionPane.showConfirmDialog(parentComponent,message+":\n"+subTitle,TitleConfirmation,JOptionPane.YES_NO_CANCEL_OPTION);
		}
	}

	/**
	 * Zeigt einen Ja/Nein/Abbrechen-Dialog an.
	 * Verwendet im Unterschied zuz <code>showConfirmDialog</code> ein Disketten-Symbol f�r die "Ja"-Option.
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 * @param option1	�berschrift f�r die erste Option
	 * @param option1sub	Untertitel der ersten Option
	 * @param option2	�berschrift f�r die zweite Option
	 * @param option2sub	Untertitel der zweiten Option
	 * @param option3	�berschrift f�r die dritte Option
	 * @param option3sub	Untertitel der dritten Option
	 * @return	Liefert einen der Werte <code>JOptionPane.YES_OPTION</code>, <code>JOptionPane.NO_OPTION</code> oder <code>JOptionPane.CANCEL_OPTION</code> zur�ck.
	 */
	public static int showConfirmSaveDialog(Component parentComponent, String message, String subTitle, String option1, String option1sub, String option2, String option2sub, String option3, String option3sub) {
		if (newDialogs) {
			URL urlYes=JOptionPane2.class.getResource("res/disk.png");
			URL urlNo=JOptionPane2.class.getResource("res/cancel.png");
			URL urlCancel=JOptionPane2.class.getResource("res/arrow_redo2.png");
			int wahl=TaskDialogs.choice(getWindow(parentComponent),message,subTitle,0,
					new CommandLink(new ImageIcon(urlYes),option1,option1sub),
					new CommandLink(new ImageIcon(urlNo),option2,option2sub),
					new CommandLink(new ImageIcon(urlCancel),option3,option3sub));
			switch (wahl) {
			case 0: return JOptionPane.YES_OPTION;
			case 1: return JOptionPane.NO_OPTION;
			case 2: return JOptionPane.CANCEL_OPTION;
			default: return JOptionPane.CANCEL_OPTION;
			}
		} else {
			return JOptionPane.showConfirmDialog(parentComponent,message+":\n"+subTitle,TitleConfirmation,JOptionPane.YES_NO_CANCEL_OPTION);
		}
	}

	/**
	 * Zeigt einen Dialog an, in dem abgefragt wird, ob die angegebene Datei �berschrieben werden soll.
	 * @param parentComponent	�bergeordnetes Element
	 * @param file	Datei, deren Pfad und Name angezeigt werden sollen.
	 * @return	Gibt <code>true</code> zur�ck, wenn ausgew�hlt wurde, dass die Datei �berschrieben werden soll.
	 */
	public static boolean showConfirmOverwriteDialog(Component parentComponent, File file) {
		if (newDialogs) {
			URL urlYes=JOptionPane2.class.getResource("res/disk.png");
			URL urlNo=JOptionPane2.class.getResource("res/cancel.png");
			int wahl=TaskDialogs.choice(getWindow(parentComponent),OverwriteTitle,String.format(OverwriteInfo,file.toString()),0,
					new CommandLink(new ImageIcon(urlYes),OverwriteYes,OverwriteYesInfo),
					new CommandLink(new ImageIcon(urlNo),OverwriteNo,OverwriteNoInfo));
			return (wahl==0);
		} else {
			return (JOptionPane.showConfirmDialog(parentComponent,String.format(OverwriteInfo,file.toString()),TitleWarning,JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION);
		}
	}

	/**
	 * Zeigt einen Ja/Nein-Dialog an
	 * @param parentComponent	�bergeordnetes Element
	 * @param message	�berschrift der Nachricht
	 * @param subTitle	Nachrichten-Haupttext
	 * @param option1	�berschrift f�r die erste Option
	 * @param option1sub	Untertitel der ersten Option
	 * @param option2	�berschrift f�r die zweite Option
	 * @param option2sub	Untertitel der zweiten Option
	 * @return	Liefert <code>true</code> zur�ck, wenn die erste Option gew�hlt wurde.
	 */

	public static boolean showYesNoDialog(Component parentComponent, String message, String subTitle, String option1, String option1sub, String option2, String option2sub) {
		if (newDialogs) {
			URL urlYes=JOptionPane2.class.getResource("res/tick.png");
			URL urlNo=JOptionPane2.class.getResource("res/cancel.png");
			int wahl=TaskDialogs.choice(getWindow(parentComponent),message,subTitle,0,
					new CommandLink(new ImageIcon(urlYes),option1,option1sub),
					new CommandLink(new ImageIcon(urlNo),option2,option2sub));
			switch (wahl) {
			case 0: return true;
			case 1: return false;
			default: return false;
			}
		} else {
			return JOptionPane.showConfirmDialog(parentComponent,message+":\n"+subTitle,TitleConfirmation,JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION;
		}
	}
}