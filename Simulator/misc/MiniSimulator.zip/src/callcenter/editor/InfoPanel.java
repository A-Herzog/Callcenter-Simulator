package callcenter.editor;

import java.awt.Color;
import java.awt.FlowLayout;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Versionsinfo-Dialog
 * @author Alexander Herzog
 * @version 1.0
 */
public class InfoPanel extends JPanel {
	private static final long serialVersionUID = 7703815170749299834L;

	public InfoPanel(String version) {
		JPanel p,p2,p3;
		JLabel image;

		setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

		/* Bild anzeigen */
		add(p=new JPanel(new FlowLayout(FlowLayout.CENTER))); p.add(image=new JLabel());
		URL imgURL=InfoDialog.class.getResource("res/CCS.png");
		if (imgURL!=null) image.setIcon(new ImageIcon(imgURL));
		image.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		/* Text anzeigen */
		add(p=new JPanel(new FlowLayout(FlowLayout.LEFT))); p.add(p2=new JPanel());
		p2.setLayout(new BoxLayout(p2,BoxLayout.Y_AXIS));

		String[] text={
				"Mini Callcenter-Simulator "+version,
				"geschrieben von "+CallcenterEditorPanel.AUTHOR_LONG,
				"verwendete Mathematik-Bibliothek: Apache Commons Math (commons.apache.org/math/)",
				"verwendete Datenexport-Bibliothek: Apache POI (poi.apache.org)",
				"verwendete SQLite-Bibliothek: SQLite JDBC Driver (bitbucket.org/xerial/sqlite-jdbc)",
				/* "verwendete Datenexport-Bibliothek: jOpenDocument (www.jopendocument.org)", */
				"verwendete Dialog-Bibliothek: Oxbow (code.google.com/p/oxbow/)",
				"verwendete Icon-Sammung: famfamfam (www.famfamfam.com)",
				"Java-Version: "+System.getProperty("java.version")+" ("+System.getProperty("java.vm.name")+")"
		};

		StringBuilder s=new StringBuilder();
		s.append("<html><p style=\"font-weight: bold; font-size: larger;\">"+text[0]+"</p><p style=\"margin-top: 5px; margin-bottom: 5px;\">"+text[1]+"</p><p style=\"font-size: 9pt;\">");
		for (int i=2;i<text.length;i++) {if (i>2) s.append("<br>");	s.append(text[i]);}
		s.append("</p></html>");

		p2.add(p3=new JPanel(new FlowLayout(FlowLayout.LEFT)));
		p3.add(new JLabel(s.toString()));

		add(Box.createVerticalGlue());
	}

}
