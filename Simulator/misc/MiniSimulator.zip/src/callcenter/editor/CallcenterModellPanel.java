package callcenter.editor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JPanel;

/**
 * Zeigt eine �bersicht zu dem Callcenter-Modell als Warteschlangenmodell in einem Panel an.
 * @author Alexander Herzog
 * @version 1.0
 */
public class CallcenterModellPanel extends JPanel {
	private static final long serialVersionUID = 8045548555129632452L;

	private String version="";

	public CallcenterModellPanel(String version) {
		super();
		this.version=version;
	}

	private void pfeil(Graphics g, int x, int y, int width, String s1, String s2) {
		g.drawLine(x,y,x+width,y);
		g.drawLine(x+width,y,x+width-width/4,y-width/4);
		g.drawLine(x+width,y,x+width-width/4,y+width/4);
		if (!s1.isEmpty()) g.drawString(s1,x,y-g.getFontMetrics().getDescent());
		if (!s2.isEmpty()) g.drawString(s2,x,y+g.getFontMetrics().getAscent()-g.getFontMetrics().getDescent());
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		String s;
		Rectangle r=getBounds(); int x=r.width;	int y=r.height;

		g.setFont(new Font(g.getFont().getName(),Font.BOLD,18));
		g.drawString("Simuliertes Warteschlangenmodell",x/40,y/20);

		g.setFont(new Font(g.getFont().getName(),Font.PLAIN,11));

		/* Ankunftsstrom-Pfeil */
		pfeil(g,1*x/10,y/2,1*x/10,"Ankunfts-","strom");

		/* Kasten */
		g.drawRect(9*x/40,4*y/10,2*x/10,2*y/10);
		for (int i=1;i<=3;i++) g.drawLine(9*x/40+2*x/10*i/4,4*y/10,9*x/40+2*x/10*i/4,6*y/10);
		g.drawString("Warteraum der Gr��e K",9*x/40,4*y/10-g.getFontMetrics().getDescent());

		/* Bediener */
		g.drawOval(17*x/40,7*y/20,6*x/20,6*y/20);
		s="c Bediener";
		g.drawString(s,23*x/40-g.getFontMetrics().stringWidth(s)/2,y/2+g.getFontMetrics().getAscent()/2);

		/* Ende */
		pfeil(g,15*x/20,y/2,2*x/10,"Bediente Kunden","verlassen das System");

		/* Weiterleitungen */

		g.drawLine(15*x/20,4*y/10,17*x/20,4*y/10);
		g.drawLine(17*x/20,4*y/10,17*x/20,2*y/10);
		g.drawLine(17*x/20,2*y/10,1*x/10,2*y/10);
		g.drawLine(1*x/10,2*y/10,1*x/10,17*y/40);
		pfeil(g,1*x/10,17*y/40,1*x/10,"","");
		s="Weiterleitungen";
		g.drawString(s,19*x/40-g.getFontMetrics().stringWidth(s)/2,2*y/10-g.getFontMetrics().getDescent());

		/* Wiederholer */
		g.drawLine(13*x/40,25*y/40,13*x/40,8*y/10);
		g.drawLine(13*x/40,8*y/10,1*x/10,8*y/10);
		g.drawLine(1*x/10,8*y/10,1*x/10,23*y/40);
		pfeil(g,1*x/10,23*y/40,1*x/10,"","");
		g.drawString("Ungeduldige Kunden",27*x/80,14*y/20);
		g.drawString("geben das Warten vorzeitig auf",27*x/80,14*y/20+g.getFontMetrics().getHeight());
		g.drawString("und starten sp�ter evtl. einen",27*x/80,14*y/20+g.getFontMetrics().getHeight()*2);
		g.drawString("zweiten Versuch",27*x/80,14*y/20+g.getFontMetrics().getHeight()*3);

		/* Copyright */
		g.setFont(new Font(g.getFont().getName(),Font.PLAIN,11));
		g.drawString("Mini Callcenter Simulator Version "+version+" geschrieben von "+CallcenterEditorPanel.AUTHOR_LONG,x/40,y-g.getFontMetrics().getDescent());
	}
}
