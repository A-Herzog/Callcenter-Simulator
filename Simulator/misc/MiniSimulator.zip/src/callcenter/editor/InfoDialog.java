package callcenter.editor;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;

/**
 * Versionsinfo-Dialog
 * @author Alexander Herzog
 * @version 1.0
 */
public class InfoDialog extends JDialog {
	private static final long serialVersionUID = -4544783238672067726L;

	private JButton okButton;

	public InfoDialog(Window owner, String version) {
		super(owner,"Programminformationen",Dialog.ModalityType.APPLICATION_MODAL);
		setLayout(new BorderLayout());

		/* Info-Panel */
		add(new InfoPanel(version),BorderLayout.CENTER);

		/* Ok-Button */
		JPanel p;
		add(p=new JPanel(new FlowLayout(FlowLayout.LEFT)),BorderLayout.SOUTH);
		p.add(okButton=new JButton("Ok"));
		okButton.addActionListener(new ActionListener() {@Override public void actionPerformed(ActionEvent e) {setVisible(false); dispose();}});
		URL imgURL=InfoDialog.class.getResource("res/accept.png");
		if (imgURL!=null) okButton.setIcon(new ImageIcon(imgURL));
		getRootPane().setDefaultButton(okButton);

		addWindowListener(new WindowAdapter() {@Override public void windowClosing(WindowEvent event) {setVisible(false); dispose();}});
		setResizable(false);
		pack();
		setLocationRelativeTo(owner);
	}

	@Override
	protected JRootPane createRootPane() {
		JRootPane rootPane=new JRootPane();
		KeyStroke stroke=KeyStroke.getKeyStroke("ESCAPE");
		InputMap inputMap=rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
		inputMap.put(stroke,"ESCAPE");
		rootPane.getActionMap().put("ESCAPE",new CloseListener());
		return rootPane;
	}

	private class CloseListener extends AbstractAction {
		private static final long serialVersionUID = -485008309903554823L;
		@Override
		public void actionPerformed(ActionEvent actionEvent) {setVisible(false); dispose();}
	}

}
