package callcenter;

import java.util.ArrayDeque;
import java.util.Queue;

import callcenter.events.CallCancelEvent;

/**
 * Dieses Objekt speichert die variablen Simulationsdaten bei der Callcenter-Simulation.
 * Jeder Rechenthread erh�lt eine unabh�ngige Instanz eines solchen Objektes.
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallcenterDynamicSimData {
	/**
	 * Anzahl an momentan verf�gbaren Agenten
	 */
	public int freeAgents;

	/**
	 * Letzter Zeitpunkt, an dem sich die Anzahl der verf�gbaren Agenten, die Warteschlangenl�nge
	 * oder die Anzahl an Kunden im System ge�ndert hat.
	 * (Mit Hilfe dieser Variable kann eine Statistik erstellt werden, wie lange jeweils
	 * wie viele Agenten frei waren und wie lange wie viele Kunden in der Warteschlange und im System waren.)
	 */
	public long lastDataLogTime=0;

	/**
	 * Liste der wartenden Anrufer (repr�sentiert durch ihre Warteabbruch-Events.
	 */
	public final Queue<CallCancelEvent> waitingCalls;

	/**
	 * Gibt an, ob sich das System noch in der Einschwingphase befindet.
	 */
	public boolean isWarmUpPeriod=true;

	/**
	 * Konstruktor der Klasse <code>CallcenterDynamicSimData</code>
	 * @param agents	Die Variable <code>freeAgents</code> wird auf diesen Wert vorbelegt.
	 */
	public CallcenterDynamicSimData(int agents) {
		freeAgents=agents;
		waitingCalls=new ArrayDeque<CallCancelEvent>(10000);
	}
}
