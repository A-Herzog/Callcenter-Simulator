package callcenter;

/**
 * @author Alexander Herzog
 * @version 1.0
 */
public final class VersionConst {
	public static final String version="5.3.221";

	public static boolean isNewerVersion(String currentVersion, String dataVersion) {
		if (dataVersion==null || dataVersion.isEmpty()) return false;
		if (currentVersion==null || currentVersion.isEmpty()) return false;
		String[] newVer=dataVersion.split("\\.");
		String[] curVer=currentVersion.split("\\.");
		if (newVer.length<3 || curVer.length<3) return false;

		try {
			int new1=Integer.parseInt(newVer[0]);
			int new2=Integer.parseInt(newVer[1]);
			int cur1=Integer.parseInt(curVer[0]);
			int cur2=Integer.parseInt(curVer[1]);
			return (new1>cur1 || (new1==cur1 && new2>cur2));
		} catch (NumberFormatException e) {return false;}
	}

	public static boolean isNewerVersion(String dataVersion) {
		return isNewerVersion(version,dataVersion);
	}

	public static boolean isOlderVersion(String dataVersion) {
		return isNewerVersion(dataVersion,version);
	}

	public static boolean isNewerVersionFull(String currentVersion, String dataVersion) {
		if (dataVersion==null || dataVersion.isEmpty()) return false;
		if (currentVersion==null || currentVersion.isEmpty()) return false;
		String[] newVer=dataVersion.trim().split("\\.");
		String[] curVer=currentVersion.trim().split("\\.");
		if (newVer.length<3 || curVer.length<3) return false;

		try {
			int new1=Integer.parseInt(newVer[0]);
			int new2=Integer.parseInt(newVer[1]);
			int new3=Integer.parseInt(newVer[2]);
			int cur1=Integer.parseInt(curVer[0]);
			int cur2=Integer.parseInt(curVer[1]);
			int cur3=Integer.parseInt(curVer[2]);
			return (new1>cur1 || (new1==cur1 && new2>cur2) || (new1==cur1 && new2==cur2 && new3>cur3));
		} catch (NumberFormatException e) {return false;}
	}

	public static boolean isNewerVersionFull(String dataVersion) {
		return isNewerVersionFull(version,dataVersion);
	}
}
