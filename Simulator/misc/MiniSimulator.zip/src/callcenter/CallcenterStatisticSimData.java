package callcenter;

/**
 * Diese Klasse speichert die w�hrend der Simulation anfallenden Statistikdaten.
 * Jeder Rechenthread erh�lt eine unabh�ngige Instanz eines solchen Objektes.
 * @author Alexander Herzog
 * @version 1.0
 */
public final class CallcenterStatisticSimData {
	/**
	 * Gesamtzahl an Anrufen;
	 */
	public int calls=0;

	/**
	 * Anzahl an Erstanrufern
	 */
	public int  freshCalls=0;

	/**
	 * Anzahl an erfolgreichen Anrufen
	 */
	public int successful=0;

	/**
	 * Anzahl an Wiederholungsanrufen
	 */
	public int retrys=0;

	/**
	 * Anzahl an per Besetztzeichen abgewiesenen Anrufen
	 */
	public int rejectedCalls=0;

	/**
	 * Anzahl an Anrufen, die warten mussten
	 */
	public int callsNeededToWait=0;

	/**
	 * Aufsummierte Wartezeit �ber alle Zwischenankunftszeiten
	 */
	public double interarrivalTimeSum=0;

	/**
	 * Quadriert aufsummierte Zwischenankunftszeiten (zur Berechnung des zweiten Moments)
	 */
	public double interarrivalTimeSumSqr=0;

	/**
	 * Aufsummierte Wartezeit �ber alle Anrufe
	 */
	public double waitingTimeSum=0;

	/**
	 * Quadriert aufsummierte Wartezeit �ber alle Anrufe (zur Berechnung des zweiten Moments)
	 */
	public double waitingTimeSqrSum=0;

	/**
	 * Aufsummierte Abbruchzeit �ber alle Anrufe
	 */
	public double  abortTimeSum=0;

	/**
	 * Quadriert aufsummierte Abbruchzeit �ber alle Anrufe (zur Berechnung des zweiten Moments)
	 */
	public double abortTimeSqrSum=0;

	/**
	 * Aufsummierte Bedienzeit �ber alle Anrufe
	 */
	public double serviceTimeSum=0;

	/**
	 * Quadriert aufsummierte Bedienzeit �ber alle Anrufe (zur Berechnung des zweiten Moments)
	 */
	public double serviceTimeSqrSum=0;

	/**
	 * Aufsummierte Verweilzeit �ber alle Anrufe
	 */
	public double systemTimeSum=0;

	/**
	 * Quadriert aufsummierte Verweilzeit �ber alle Anrufe (zur Berechnung des zweiten Moments)
	 */
	public double systemTimeSqrSum=0;

	/**
	 * Z�hldichte, wie viel Zeit jeweils wie viele Agenten im Leerlauf waren
	 */
	public double[] freeAgentTimes;

	/**
	 * Z�hldichte, wie lange Zeit die Warteschlange jeweils welche L�nge hatte
	 */
	public double[] queueLengthTimes;

	/**
	 * Z�hldichte, wie lange Zeit die Anzahl an Kunden im System jeweils wie hoch war
	 */
	public double[] systemLengthTimes;

	/**
	 * Konstruktor der Klasse <code>CallcenterStatisticSimData</code>
	 * @param agents	Anzahl an Agenten (bestimmt die L�nge des Arrays <code>freeAgentTimes</code>)
	 * @param batchWorking	Anzahl an Kunden die ein Agent jeweils gleichzeitig bedient (bestimmt die L�nge des Arrays <code>freeAgentTimes</code>)
	 * @param maxQueueLength	Maximal zu erfassende Warteschlangenl�nge (bestimmt die L�nge des Arrays <code>systemLengthTimes</code>)
	 */
	public CallcenterStatisticSimData(int agents, int batchWorking, int maxQueueLength) {
		freeAgentTimes=new double[agents+1];
		queueLengthTimes=new double[maxQueueLength+1];
		systemLengthTimes=new double[maxQueueLength+agents*batchWorking+1];
	}

	/**
	 * F�gt die Daten eines anderen Statistik-Objekt zu dem aktuellen Objekt hinzu.
	 * Auf diese Weise k�nnen die Statistik-Objekte mehrerer Rechenthreads zusammengefasst werden.
	 * @param statisticSimData	Statstik-Objekt, dessen Daten zu dem aktuellen Objekt hinzugef�gt werden sollen.
	 */
	public final void addData(CallcenterStatisticSimData statisticSimData) {
		calls+=statisticSimData.calls;
		freshCalls+=statisticSimData.freshCalls;
		successful+=statisticSimData.successful;
		retrys+=statisticSimData.retrys;
		rejectedCalls+=statisticSimData.rejectedCalls;
		callsNeededToWait+=statisticSimData.callsNeededToWait;
		interarrivalTimeSum+=statisticSimData.interarrivalTimeSum;
		interarrivalTimeSumSqr+=statisticSimData.interarrivalTimeSumSqr;
		waitingTimeSum+=statisticSimData.waitingTimeSum;
		abortTimeSum+=statisticSimData.abortTimeSum;
		waitingTimeSqrSum+=statisticSimData.waitingTimeSqrSum;
		abortTimeSqrSum+=statisticSimData.abortTimeSqrSum;
		serviceTimeSum+=statisticSimData.serviceTimeSum;
		serviceTimeSqrSum+=statisticSimData.serviceTimeSqrSum;
		systemTimeSum+=statisticSimData.systemTimeSum;
		systemTimeSqrSum+=statisticSimData.systemTimeSqrSum;
		for (int i=0;i<freeAgentTimes.length;i++) freeAgentTimes[i]+=statisticSimData.freeAgentTimes[i];
		for (int i=0;i<queueLengthTimes.length;i++) queueLengthTimes[i]+=statisticSimData.queueLengthTimes[i];
		for (int i=0;i<systemLengthTimes.length;i++) systemLengthTimes[i]+=statisticSimData.systemLengthTimes[i];
	}
}
